# My Game My Story

The premium platform for student athletes to build their personal brand, control their narrative, and own what the world finds when they search their name.

Built with **Next.js 16**, **React 19**, **Supabase** (auth, database, storage), and **Tailwind CSS 4**.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your Supabase credentials

# 3. Run the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

The app runs in **demo/mock mode** when Supabase credentials are not configured — all pages load and the UI is fully functional without a database connection.

---

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | Your Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Yes | Supabase anon/public API key |
| `SUPABASE_SERVICE_ROLE_KEY` | No | Service role key (server-only, admin scripts) |
| `NEXT_PUBLIC_APP_URL` | Yes (prod) | Canonical app URL — set to your live domain in production |
| `NEXT_PUBLIC_MEDIA_BUCKET` | No | Supabase Storage bucket name (default: `highlights`) |

See `.env.example` for details and `docs/supabase-setup.md` for Supabase project setup.

---

## Build & start commands

```bash
npm run dev      # Development server with hot reload
npm run build    # Production build (outputs to .next/)
npm run start    # Start the production server (requires a build first)
npm run lint     # Run ESLint
```

Node.js **20 LTS or later** is required.

---

## Project structure

```
src/
  app/
    (marketing)/     # Public marketing pages (/, /about, /athletes, etc.)
    (auth)/          # Auth pages (login, signup, onboarding, forgot-password)
    app/             # Protected dashboard (/app/*, requires auth)
    auth/callback/   # Supabase email confirmation handler
  components/
    app/             # Dashboard components (SessionGuard, MediaVault, etc.)
    auth/            # Auth form components
  lib/
    supabase/        # Supabase clients, types, barrel export
    actions/         # Server actions (auth, profile, media, analytics)
    env.ts           # Env var helpers and startup validation
    session.ts       # Mock session (demo mode, no Supabase required)
    mock-data.ts     # Demo athlete data
  proxy.ts           # Edge proxy: session refresh + route protection
supabase/
  migrations/        # SQL migrations (apply in order to your Supabase project)
  config.toml        # Supabase CLI config (local dev)
docs/
  supabase-setup.md           # Supabase project setup guide
  hostinger-deployment.md     # Hostinger production deployment guide
```

---

## Deployment

This app is designed to run on **Hostinger Node.js hosting** with **Supabase** as the backend.

See **[docs/hostinger-deployment.md](docs/hostinger-deployment.md)** for the full step-by-step deployment guide, including:
- Hostinger environment variable setup
- Supabase project configuration
- Domain and auth callback URL setup
- Storage bucket verification
- Pre-launch checklist

For Supabase project setup (schema, RLS, storage) see **[docs/supabase-setup.md](docs/supabase-setup.md)**.
