# Hostinger Deployment Guide — My Game My Story

This guide walks through deploying My Game My Story to **Hostinger Node.js hosting** with **Supabase** as the backend. Follow the checklist at the end before going live.

---

## Prerequisites

- A Supabase project with migrations applied (see [supabase-setup.md](supabase-setup.md))
- A domain configured in Hostinger (or their free subdomain)
- Node.js 20 LTS or later on the Hostinger instance

---

## 1. Supabase setup (do this first)

Before configuring Hostinger, make sure Supabase is fully set up:

### 1a. Apply migrations

In the **Supabase Dashboard → SQL Editor**, paste and run these files in order:

1. `supabase/migrations/20260418000001_initial_schema.sql`
2. `supabase/migrations/20260418000002_rls_policies.sql`
3. `supabase/migrations/20260419000001_add_profile_fields.sql`
4. `supabase/migrations/20260420000001_storage_bucket.sql`

Alternatively, with the Supabase CLI:

```bash
supabase login
supabase link --project-ref <your-project-ref>
supabase db push
```

### 1b. Verify the storage bucket

Go to **Supabase Dashboard → Storage** and confirm the `highlights` bucket exists. The last migration creates it automatically, but double-check:

- Name: `highlights`
- Public: **OFF** (private — files are served via signed URLs)
- File size limit: 500 MB
- Allowed types: video (mp4, mov, mpeg, webm) + image (jpg, png, gif, webp)

If it's missing, create it manually with those settings and re-run the storage policies from `20260418000002_rls_policies.sql`.

### 1c. Configure Auth settings

In **Supabase Dashboard → Authentication → URL Configuration**:

**Site URL:**
```
https://yourdomain.com
```

**Redirect URLs** (add both — dev and prod):
```
http://localhost:3000/auth/callback
https://yourdomain.com/auth/callback
```

> Replace `yourdomain.com` with your actual domain. Without the production redirect URL, email confirmation links will fail.

### 1d. Get your credentials

From **Supabase Dashboard → Project Settings → API**:

- **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
- **anon public** key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- **service_role** key → `SUPABASE_SERVICE_ROLE_KEY` (keep this secret)

---

## 2. Hostinger: Node.js app setup

### 2a. Create a Node.js app

1. Log in to Hostinger hPanel.
2. Go to **Hosting → Manage → Node.js**.
3. Click **Create application**.
4. Set:
   - **Node.js version:** 20.x (LTS) or later
   - **Application root:** your project directory (e.g. `/public_html/mygamemystory`)
   - **Application startup file:** `node_modules/.bin/next` (or use a custom start script — see below)
   - **Application mode:** Production

> **Tip:** If Hostinger asks for a startup command rather than a file, use:
> ```
> npm start
> ```
> which runs `next start` via the `scripts.start` in `package.json`.

### 2b. Set environment variables

In **Hosting Panel → Node.js → Environment Variables** (or `.env` panel), add:

| Variable | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Your Supabase service role key |
| `NEXT_PUBLIC_APP_URL` | `https://yourdomain.com` (no trailing slash) |
| `NEXT_PUBLIC_MEDIA_BUCKET` | `highlights` |
| `NODE_ENV` | `production` |

> **NEXT_PUBLIC_APP_URL is critical.** Password reset and email confirmation redirect URLs are built from this value on the server. If it's missing or still set to `localhost`, auth emails will redirect users to the wrong place.

### 2c. Deploy your code

**Option A — Git deployment (recommended)**

If Hostinger supports Git auto-deployment:
1. Connect your repo in hPanel → Git.
2. Set the branch to `main`.
3. Configure the build command: `npm install && npm run build`
4. Hostinger will pull and rebuild on each push.

**Option B — SFTP / file manager upload**

Upload the entire project directory excluding:
- `node_modules/` (too large; install on server)
- `.next/` (rebuild on server)
- `.env.local` (use Hostinger's env panel instead)

Then SSH in and run:

```bash
npm install
npm run build
```

### 2d. Start the app

After building, start the app from the Hostinger hPanel, or via SSH:

```bash
npm start
# which runs: next start
```

Hostinger's Node.js manager should auto-restart the app on crashes and after deployments.

---

## 3. Domain and SSL

1. Point your domain's nameservers to Hostinger (or add an A record pointing to your Hostinger server IP).
2. In hPanel → **Domains → SSL**, enable the free **Let's Encrypt** certificate.
3. Enable **Force HTTPS** so all HTTP traffic redirects to HTTPS.

After SSL is active, verify your Supabase **Site URL** and **Redirect URLs** use `https://` (step 1c above).

---

## 4. Node.js version

This app requires **Node.js 20 LTS or later** (declared in `package.json` → `engines`).

To check the version Hostinger is using:

```bash
node --version
```

If Hostinger offers multiple Node versions, select **20.x** or higher in the Node.js app settings.

---

## 5. Build and start reference

```bash
# Install dependencies
npm install

# Build for production (generates .next/ directory)
npm run build

# Start the production server (default port 3000)
npm start

# To use a custom port (if Hostinger assigns one):
PORT=8080 npm start
```

The build output goes into `.next/`. No standalone bundling is used — `npm start` runs `next start` which serves from `.next/` directly. Make sure `.next/` is present before starting.

---

## 6. Pre-launch checklist

Work through this checklist before pointing traffic to the live domain.

### Supabase
- [ ] All 4 migrations applied (check SQL Editor → Table Editor for all expected tables)
- [ ] `highlights` storage bucket exists (Storage → Buckets)
- [ ] Site URL set to `https://yourdomain.com` (Auth → URL Configuration)
- [ ] `https://yourdomain.com/auth/callback` added to Redirect URLs
- [ ] Email confirmation enabled or intentionally disabled (Auth → Settings → Email Auth)

### Hostinger environment variables
- [ ] `NEXT_PUBLIC_SUPABASE_URL` — set to your Supabase project URL
- [ ] `NEXT_PUBLIC_SUPABASE_ANON_KEY` — set to your anon/public key
- [ ] `SUPABASE_SERVICE_ROLE_KEY` — set (server-side only, never exposed to browser)
- [ ] `NEXT_PUBLIC_APP_URL` — set to `https://yourdomain.com` (not localhost)
- [ ] `NEXT_PUBLIC_MEDIA_BUCKET` — set to `highlights`
- [ ] `NODE_ENV` — set to `production`

### Build
- [ ] `npm install` completed without errors
- [ ] `npm run build` completed without errors
- [ ] App starts successfully (`npm start`)

### Domain & SSL
- [ ] Domain DNS points to Hostinger
- [ ] SSL certificate issued and active
- [ ] Force HTTPS enabled

### Smoke tests (after go-live)
- [ ] Home page loads at `https://yourdomain.com`
- [ ] Signup flow works: account creation → confirmation email → callback redirect → onboarding
- [ ] Login and logout work
- [ ] Dashboard (`/app`) loads after login
- [ ] Profile editor saves data
- [ ] Media upload works (file goes to Supabase Storage `highlights` bucket)
- [ ] Public athlete profile page (`/athlete/[slug]`) loads
- [ ] Password reset email arrives and redirect URL is correct (not localhost)

---

## 7. Troubleshooting

### "Supabase not configured" banner appears

The app detected placeholder or missing env vars. Verify all `NEXT_PUBLIC_SUPABASE_*` vars are set correctly in the Hostinger environment panel and that the app was restarted after saving them.

### Auth callback fails / email link doesn't work

Check that:
1. `NEXT_PUBLIC_APP_URL` is set to your live domain (not localhost).
2. `https://yourdomain.com/auth/callback` is in Supabase's Redirect URLs list.
3. The `auth/callback` route handler is deployed (file: `src/app/auth/callback/route.ts`).

### Media upload fails

Check that:
1. The `highlights` bucket exists in Supabase Storage.
2. The storage RLS policies were applied (from `20260418000002_rls_policies.sql`).
3. The user is authenticated when uploading.

### 404 on `/athlete/[slug]`

Check that:
1. The athlete profile has `is_public = true` in the database.
2. The RLS `SELECT` policy on `athlete_profiles` allows public reads for `is_public = true` rows.

### Build fails with TypeScript errors

Run `npm run build` locally first and fix any errors before deploying. TypeScript errors are caught at build time — they will not appear in the browser.

### Port mismatch

If Hostinger assigns a specific port, set it before starting:

```bash
PORT=<assigned-port> npm start
```

---

## 8. What Hostinger does NOT need to configure

- **Supabase storage CDN** — Media files are served from Supabase's CDN, not Hostinger storage. No additional configuration needed on the Hostinger side.
- **Database** — Supabase hosts Postgres. Hostinger only runs the Next.js Node.js server.
- **Auth emails** — Supabase sends all transactional emails. Hostinger email is not involved.
