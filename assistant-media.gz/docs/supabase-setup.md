# Supabase Setup Guide — My Game My Story

This guide covers everything needed to connect My Game My Story to a real
Supabase project. Without this wiring the app runs in **demo/mock mode** (auth
is simulated, no data is persisted, but all pages load and the UI is fully
functional for development).

---

## 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) and create a new project.
2. Pick a region close to your users (`us-east-1` is a safe default).
3. Set a strong database password and save it somewhere safe.

---

## 2. Environment variables

Copy `.env.example` to `.env.local` and fill in real values:

```bash
cp .env.example .env.local
```

| Variable | Where to find it |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Project Settings → API → Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Project Settings → API → Project API keys → `anon public` |
| `SUPABASE_SERVICE_ROLE_KEY` | Project Settings → API → Project API keys → `service_role` (server-only) |
| `NEXT_PUBLIC_APP_URL` | `http://localhost:3000` for local dev, your production URL in prod |

> **Never commit `.env.local`** — it is in `.gitignore`.

---

## 3. Database schema

### Option A — Supabase Dashboard (quickest)

1. Go to **SQL Editor → New query** in the Supabase Dashboard.
2. Paste and run each migration file in order:
   - [`supabase/migrations/20260418000001_initial_schema.sql`](../supabase/migrations/20260418000001_initial_schema.sql) — Tables, triggers, indexes
   - [`supabase/migrations/20260418000002_rls_policies.sql`](../supabase/migrations/20260418000002_rls_policies.sql) — Row Level Security + storage policies

### Option B — Supabase CLI (recommended for teams)

```bash
# Install the Supabase CLI
npm install -g supabase

# Link to your cloud project (run once per machine)
supabase login
supabase link --project-ref <your-project-ref>

# Push all migrations to the cloud project
supabase db push
```

### Option C — Local development stack

```bash
# Start the full local Supabase stack (Postgres + Auth + Storage + Studio)
supabase start

# Apply migrations and seed data
supabase db reset
```

Local credentials will be printed by `supabase start`. Copy them into `.env.local`.

---

## 4. Schema overview

### Tables

| Table | Description |
|---|---|
| `athlete_profiles` | Core profile, 1:1 with `auth.users`. Created at onboarding completion. |
| `social_links` | Social and recruiting URLs per athlete (Instagram, Hudl, MaxPreps, etc.). |
| `athlete_stats` | Flexible key-value performance stats (e.g. "40-Yard Dash": "4.52s"). |
| `athlete_media` | Highlight video and photo metadata. Files live in the `highlights` Storage bucket. |
| `profile_views` | Append-only log of public profile page visits. |
| `analytics_events` | General-purpose event log (media views, search impressions, contact clicks). |

### Key design decisions

- **`is_public`** on `athlete_profiles` controls whether `/athlete/[slug]` is publicly accessible. Defaults to `true`.
- **`featured`** on `athlete_media` controls what appears on the public profile vs. private vault.
- **`profile_strength`** (0–100) is computed server-side by tallying filled fields; clients never write it directly.
- **Social links** have a `UNIQUE(user_id, platform)` constraint — one URL per platform per athlete; use `upsert` to update.
- **Analytics tables** (`profile_views`, `analytics_events`) are append-only. No update or delete policies exist.
- **Cascade deletes** — all child tables have `ON DELETE CASCADE` back to `auth.users`, so deleting a user cleans up all their data automatically.

### Optional character sections

`athlete_profiles` includes three nullable text columns for athlete identity content:

| Column | Purpose |
|---|---|
| `faith_statement` | Athlete's faith or values statement |
| `family_values` | How family influences their athletic journey |
| `community_involvement` | Community service, mentorship, local impact |

These are free-text and entirely optional.

---

## 5. Row Level Security summary

| Table | Owner | Public |
|---|---|---|
| `athlete_profiles` | Read + write own row | Read rows where `is_public = true` |
| `social_links` | Full CRUD own rows | Read if athlete profile is public |
| `athlete_stats` | Full CRUD own rows | Read if athlete profile is public |
| `athlete_media` | Full CRUD own rows | Read `featured = true` rows |
| `profile_views` | Read own rows | Insert (anonymous tracking) |
| `analytics_events` | Read own rows | Insert (server-side tracking) |

---

## 6. Storage bucket setup

1. Supabase Dashboard → **Storage** → **New Bucket**
2. Name: `highlights`
3. Toggle **Public bucket** OFF (files are served via signed URLs)
4. Run the storage policies in `20260418000002_rls_policies.sql` (the `storage.objects` section at the bottom)

### File path conventions

```
highlights/
  {user_id}/           ← private files (vault clips, drafts)
    clip-uuid.mp4
  public/              ← publicly readable subfolder
    {user_id}/
      featured-uuid.mp4
      thumb-uuid.jpg
```

Use the `public/` subfolder for files that need to be served without a signed URL (thumbnails, featured clip previews visible on the public profile page).

---

## 7. Auth configuration

In **Supabase Dashboard → Authentication → Settings**:

### Site URL
```
http://localhost:3000
```
*(set to your production domain before going live)*

### Redirect URLs
```
http://localhost:3000/auth/callback
https://yourdomain.com/auth/callback
```

### Email confirmation
- **Enabled** (production default): users confirm email before accessing the app.
- **Disabled** (easier local dev): users are auto-signed-in after signup.

To disable: **Authentication → Settings → Email Auth → Confirm email → OFF**

---

## 8. Generating TypeScript types from your live schema

After applying migrations, regenerate `types.ts` from your actual schema:

```bash
npx supabase gen types typescript \
  --project-id <your-project-ref> \
  --schema public \
  > src/lib/supabase/types.ts
```

Commit the result. The hand-authored types in `src/lib/supabase/types.ts` are
kept in sync manually until then.

---

## 9. Demo mode (no Supabase configured)

When `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_ANON_KEY` are absent
or still set to the placeholder values in `.env.example`, the app falls back
to **demo mode**:

| Feature | Demo mode behaviour |
|---|---|
| Sign up | Creates a localStorage session, no DB record |
| Log in | Accepts any credentials, restores mock session |
| Onboarding | Saves to localStorage; server action returns a warning |
| Password reset | Shows success UI, no email sent |
| `/app` routes | Guarded by mock localStorage session check |
| Proxy (route guard) | Skipped — no server-side auth enforcement |
| Auth pages | Show an amber "Supabase not configured" banner |

---

## 10. File map

| File | Purpose |
|---|---|
| `supabase/migrations/20260418000001_initial_schema.sql` | All tables, triggers, and indexes |
| `supabase/migrations/20260418000002_rls_policies.sql` | RLS policies + storage bucket policies |
| `supabase/seed.sql` | Example seed data for local development |
| `supabase/config.toml` | Supabase CLI project configuration |
| `src/lib/supabase/client.ts` | Browser Supabase client (`createBrowserClient`) |
| `src/lib/supabase/server.ts` | Server Supabase client (`createServerClient` + cookies) |
| `src/lib/supabase/types.ts` | TypeScript DB schema types (hand-authored) |
| `src/lib/supabase/index.ts` | Barrel export |
| `src/lib/actions/auth.ts` | Server actions: signOut, resetPassword, updatePassword |
| `src/lib/actions/profile.ts` | Server actions: saveOnboarding, getAthleteProfile, updateProfile |
| `src/proxy.ts` | Edge proxy: session refresh + route protection |
| `src/app/auth/callback/route.ts` | Handles Supabase auth redirect after email confirmation |
| `.env.example` | Environment variable template |

---

## 11. Hostinger deployment notes

My Game My Story targets Hostinger for production hosting (Node.js app).
Supabase remains the backend database and auth layer regardless of where
the Next.js app is hosted.

- Set all env vars in Hostinger's **Environment Variables** panel (equivalent to `.env.local`).
- Set `NEXT_PUBLIC_APP_URL` to your live domain.
- Add your live domain's `/auth/callback` URL to the Supabase redirect allow-list.
- The `highlights` Storage bucket is served from Supabase's CDN — no Hostinger
  Storage configuration needed.
