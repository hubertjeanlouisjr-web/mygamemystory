import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Security headers applied to every response.
  // These are a lightweight, zero-configuration hardening baseline.
  // A reverse proxy (nginx, Hostinger's load balancer) can add more.
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          // Prevent the app from being embedded in iframes on other domains.
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          // Stop browsers from MIME-sniffing the content type.
          { key: "X-Content-Type-Options", value: "nosniff" },
          // Send full origin on same-origin requests; only origin on cross-origin.
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
          // Allow DNS prefetching for performance.
          { key: "X-DNS-Prefetch-Control", value: "on" },
        ],
      },
    ];
  },
};

export default nextConfig;
