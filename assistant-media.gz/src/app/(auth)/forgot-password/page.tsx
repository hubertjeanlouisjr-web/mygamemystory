"use client";

import Link from "next/link";
import { useState } from "react";
import AuthCard from "@/components/auth/AuthCard";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20";

const labelClass =
  "block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "sent" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;

    setStatus("loading");
    setErrorMsg("");

    if (isSupabaseConfigured) {
      // ── Supabase password reset ────────────────────────────────────────
      const supabase = createClient();
      // Use window.location.origin so the redirect URL always reflects
      // the actual domain at runtime, regardless of env var state.
      const redirectTo = window.location.origin + "/auth/update-password";

      const { error } = await supabase.auth.resetPasswordForEmail(
        email.trim().toLowerCase(),
        { redirectTo }
      );

      if (error) {
        setErrorMsg(error.message);
        setStatus("error");
        return;
      }
    } else {
      // ── Mock mode — simulate network delay ─────────────────────────────
      await new Promise((r) => setTimeout(r, 800));
    }

    setStatus("sent");
  }

  if (status === "sent") {
    return (
      <div className="w-full max-w-md text-center">
        {/* Success icon */}
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full border border-emerald-500/20 bg-emerald-500/[0.06]">
          <svg
            className="h-7 w-7 text-emerald-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.8}
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25H4.5a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
            />
          </svg>
        </div>

        <h1 className="font-display text-2xl font-bold text-white">
          Check your inbox
        </h1>
        <p className="mt-3 text-sm text-zinc-500 leading-relaxed">
          {isSupabaseConfigured ? (
            <>
              We sent a reset link to{" "}
              <span className="text-zinc-300">{email}</span>. It may take a
              minute to arrive. Check your spam folder if you don&apos;t see it.
            </>
          ) : (
            <>
              Demo mode: no email was sent. In production, a reset link would be
              delivered to <span className="text-zinc-300">{email}</span>.
            </>
          )}
        </p>

        <div className="mt-8 space-y-3">
          <button
            onClick={() => setStatus("idle")}
            className="w-full rounded-full border border-white/[0.08] py-2.5 text-[13px] text-zinc-400 hover:border-white/[0.15] hover:text-white transition-all"
          >
            Try a different email
          </button>
          <Link
            href="/login"
            className="block w-full rounded-full bg-amber-400 py-2.5 text-center text-[13px] font-bold text-zinc-950 hover:bg-amber-300 transition-colors"
          >
            Back to login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <AuthCard
      eyebrow="Account recovery"
      title="Reset your password"
      subtitle="Enter the email you signed up with and we'll send a reset link."
    >
      {/* Setup banner */}
      {!isSupabaseConfigured && (
        <div className="mb-5 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-4 py-3 text-[12px] text-amber-400/80">
          <span className="font-semibold">Demo mode:</span> No email will be
          sent. The success screen is simulated.
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div>
          <label htmlFor="email" className={labelClass}>
            Email address
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className={inputClass}
          />
        </div>

        {status === "error" && (
          <p className="rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-2.5 text-[12px] text-red-400">
            {errorMsg}
          </p>
        )}

        <button
          type="submit"
          disabled={status === "loading" || !email}
          className="w-full rounded-full bg-amber-400 py-3 text-[14px] font-bold text-zinc-950 transition-all hover:bg-amber-300 hover:scale-[1.02] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none"
        >
          {status === "loading" ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
              Sending…
            </span>
          ) : (
            "Send Reset Link"
          )}
        </button>

        <p className="text-center text-[13px] text-zinc-500">
          Remember it?{" "}
          <Link
            href="/login"
            className="font-semibold text-amber-400 hover:text-amber-300 transition-colors"
          >
            Back to login →
          </Link>
        </p>
      </form>
    </AuthCard>
  );
}
