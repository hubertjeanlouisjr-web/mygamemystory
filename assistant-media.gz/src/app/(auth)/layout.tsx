import Link from "next/link";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="relative min-h-screen bg-zinc-950 flex flex-col">
      {/* Ambient glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 overflow-hidden"
      >
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 h-[500px] w-[700px] rounded-full bg-amber-600/[0.04] blur-[120px]" />
      </div>

      {/* Dot grid */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(255,255,255,0.018) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Top bar */}
      <header className="relative z-10 flex items-center justify-between px-6 py-5">
        <Link href="/" className="flex items-center gap-2 group">
          <span className="font-display text-[14px] font-bold tracking-tight text-white">
            My Game{" "}
            <span className="text-amber-400">My Story</span>
          </span>
        </Link>
        <Link
          href="/"
          className="text-[12px] text-zinc-500 hover:text-zinc-300 transition-colors"
        >
          ← Back to site
        </Link>
      </header>

      {/* Page content */}
      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 py-12">
        {children}
      </main>

      {/* Footer strip */}
      <footer className="relative z-10 border-t border-white/[0.04] px-6 py-4 text-center">
        <p className="text-[11px] text-zinc-700">
          © {new Date().getFullYear()} My Game My Story · Free for athletes ·{" "}
          <Link href="/" className="hover:text-zinc-500 transition-colors">
            Privacy
          </Link>{" "}
          ·{" "}
          <Link href="/" className="hover:text-zinc-500 transition-colors">
            Terms
          </Link>
        </p>
      </footer>
    </div>
  );
}
