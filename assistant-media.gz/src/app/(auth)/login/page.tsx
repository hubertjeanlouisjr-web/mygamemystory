"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import AuthCard from "@/components/auth/AuthCard";
import { mockSignIn } from "@/lib/session";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20";

const labelClass = "block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg("Please enter your email and password.");
      setStatus("error");
      return;
    }

    setStatus("loading");
    setErrorMsg("");

    if (isSupabaseConfigured) {
      // ── Supabase auth ──────────────────────────────────────────────────
      const supabase = createClient();
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (error) {
        setErrorMsg(error.message);
        setStatus("error");
        return;
      }

      const onboardingComplete =
        data.user?.user_metadata?.onboarding_complete === true;

      router.push(onboardingComplete ? "/app" : "/onboarding");
    } else {
      // ── Mock auth (no Supabase keys configured) ────────────────────────
      const result = await mockSignIn(email, password);

      if (!result.ok) {
        setErrorMsg(result.error ?? "Something went wrong. Please try again.");
        setStatus("error");
        return;
      }

      const onboardingComplete = result.user?.onboardingComplete ?? false;
      router.push(onboardingComplete ? "/app" : "/onboarding");
    }
  }

  return (
    <AuthCard
      eyebrow="Welcome back"
      title="Log in to your account"
      subtitle="Don't have one? Sign up free — no credit card required."
    >
      {/* Setup-required banner */}
      {!isSupabaseConfigured && (
        <div className="mb-5 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-4 py-3 text-[12px] text-amber-400/80 leading-relaxed">
          <span className="font-semibold">Supabase not configured.</span> Running
          in demo mode — credentials are not verified.{" "}
          <Link
            href="/docs/supabase-setup"
            className="underline hover:text-amber-300"
          >
            Setup guide →
          </Link>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        {/* Email */}
        <div>
          <label htmlFor="email" className={labelClass}>
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className={inputClass}
          />
        </div>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="password" className={labelClass.replace("mb-2", "")}>
              Password
            </label>
            <Link
              href="/forgot-password"
              className="text-[11px] text-zinc-600 hover:text-amber-400 transition-colors"
            >
              Forgot password?
            </Link>
          </div>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className={inputClass}
          />
        </div>

        {/* Error */}
        {status === "error" && (
          <p className="rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-2.5 text-[12px] text-red-400">
            {errorMsg}
          </p>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={status === "loading"}
          className="mt-2 w-full rounded-full bg-amber-400 py-3 text-[14px] font-bold text-zinc-950 transition-all hover:bg-amber-300 hover:scale-[1.02] active:scale-[0.99] disabled:opacity-60 disabled:pointer-events-none"
        >
          {status === "loading" ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
              Signing in…
            </span>
          ) : (
            "Log In"
          )}
        </button>

        {/* Divider */}
        <div className="relative flex items-center gap-3 py-1">
          <span className="flex-1 h-px bg-white/[0.06]" />
          <span className="text-[11px] text-zinc-700">or</span>
          <span className="flex-1 h-px bg-white/[0.06]" />
        </div>

        {/* Sign up link */}
        <p className="text-center text-[13px] text-zinc-500">
          New to My Game My Story?{" "}
          <Link
            href="/signup"
            className="font-semibold text-amber-400 hover:text-amber-300 transition-colors"
          >
            Create your free profile →
          </Link>
        </p>
      </form>
    </AuthCard>
  );
}
