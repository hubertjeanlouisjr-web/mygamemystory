"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  getSession,
  updateSession,
  type MockUser,
} from "@/lib/session";
import {
  SPORTS,
  SPORT_POSITIONS,
  CLASS_YEARS,
  US_STATES,
  RECRUIT_GOALS,
} from "@/lib/mock-data";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";
import { saveOnboardingAction } from "@/lib/actions/profile";

// ─── Types ────────────────────────────────────────────────────────────────────

interface OnboardingFormData {
  sport: string;
  position: string;
  classYear: string;
  school: string;
  city: string;
  state: string;
  goals: string[];
}

/** Minimal user context needed to render the flow */
interface UserContext {
  firstName: string;
  lastName: string;
}

const TOTAL_STEPS = 3;

// ─── Shared field styles ──────────────────────────────────────────────────────

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20";

const selectClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20 appearance-none cursor-pointer";

const labelClass =
  "block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2";

// ─── Step indicator ───────────────────────────────────────────────────────────

function StepDots({
  current,
  total,
}: {
  current: number;
  total: number;
}) {
  return (
    <div className="flex items-center gap-2 mb-10" aria-label={`Step ${current} of ${total}`}>
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-1 rounded-full transition-all duration-300 ${
            i < current
              ? "bg-amber-400 w-8"
              : i === current - 1
              ? "bg-amber-400 w-8"
              : "bg-zinc-800 w-5"
          }`}
        />
      ))}
      <span className="ml-2 text-[11px] text-zinc-600 font-medium">
        {current} / {total}
      </span>
    </div>
  );
}

// ─── Step 1: Sport & Position ─────────────────────────────────────────────────

function Step1({
  data,
  onChange,
}: {
  data: OnboardingFormData;
  onChange: (patch: Partial<OnboardingFormData>) => void;
}) {
  const positions = data.sport ? (SPORT_POSITIONS[data.sport] ?? []) : [];

  function handleSportChange(sport: string) {
    onChange({ sport, position: "" });
  }

  return (
    <div className="space-y-5">
      <div>
        <label htmlFor="sport" className={labelClass}>
          Your sport
        </label>
        <div className="relative">
          <select
            id="sport"
            value={data.sport}
            onChange={(e) => handleSportChange(e.target.value)}
            className={selectClass}
          >
            <option value="" disabled>
              Select your sport…
            </option>
            {SPORTS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <ChevronIcon />
        </div>
      </div>

      {positions.length > 0 && (
        <div>
          <label htmlFor="position" className={labelClass}>
            Position
          </label>
          <div className="relative">
            <select
              id="position"
              value={data.position}
              onChange={(e) => onChange({ position: e.target.value })}
              className={selectClass}
            >
              <option value="" disabled>
                Select your position…
              </option>
              {positions.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            <ChevronIcon />
          </div>
        </div>
      )}

      <div>
        <label htmlFor="classYear" className={labelClass}>
          Class year
        </label>
        <div className="relative">
          <select
            id="classYear"
            value={data.classYear}
            onChange={(e) => onChange({ classYear: e.target.value })}
            className={selectClass}
          >
            <option value="" disabled>
              Graduation year…
            </option>
            {CLASS_YEARS.map((y) => (
              <option key={y} value={y}>
                Class of {y}
              </option>
            ))}
          </select>
          <ChevronIcon />
        </div>
      </div>
    </div>
  );
}

// ─── Step 2: School & Location ────────────────────────────────────────────────

function Step2({
  data,
  onChange,
}: {
  data: OnboardingFormData;
  onChange: (patch: Partial<OnboardingFormData>) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <label htmlFor="school" className={labelClass}>
          High school / club
        </label>
        <input
          id="school"
          type="text"
          value={data.school}
          onChange={(e) => onChange({ school: e.target.value })}
          placeholder="Westlake Academy"
          className={inputClass}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label htmlFor="city" className={labelClass}>
            City
          </label>
          <input
            id="city"
            type="text"
            value={data.city}
            onChange={(e) => onChange({ city: e.target.value })}
            placeholder="Atlanta"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="state" className={labelClass}>
            State
          </label>
          <div className="relative">
            <select
              id="state"
              value={data.state}
              onChange={(e) => onChange({ state: e.target.value })}
              className={selectClass}
            >
              <option value="" disabled>
                State…
              </option>
              {US_STATES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <ChevronIcon />
          </div>
        </div>
      </div>

      <p className="text-[12px] text-zinc-700 leading-relaxed">
        Your location helps coaches narrow searches by region. It&apos;s shown
        on your public profile but never shared without your consent.
      </p>
    </div>
  );
}

// ─── Step 3: Goals ────────────────────────────────────────────────────────────

function Step3({
  data,
  onChange,
}: {
  data: OnboardingFormData;
  onChange: (patch: Partial<OnboardingFormData>) => void;
}) {
  function toggle(goal: string) {
    const updated = data.goals.includes(goal)
      ? data.goals.filter((g) => g !== goal)
      : [...data.goals, goal];
    onChange({ goals: updated });
  }

  return (
    <div className="space-y-3">
      <p className="text-[12px] text-zinc-600 mb-1">
        Select everything that applies — you can always update these later.
      </p>
      {RECRUIT_GOALS.map((goal) => {
        const selected = data.goals.includes(goal);
        return (
          <button
            key={goal}
            type="button"
            onClick={() => toggle(goal)}
            className={`w-full flex items-center gap-3 rounded-xl border px-4 py-3.5 text-left text-[13px] transition-all duration-150 ${
              selected
                ? "border-amber-400/40 bg-amber-400/[0.06] text-white"
                : "border-white/[0.06] bg-zinc-800/50 text-zinc-400 hover:border-white/[0.1] hover:text-zinc-200"
            }`}
          >
            <span
              className={`flex-shrink-0 h-4 w-4 rounded border transition-colors ${
                selected
                  ? "border-amber-400 bg-amber-400"
                  : "border-white/[0.15] bg-transparent"
              }`}
              aria-hidden="true"
            >
              {selected && (
                <svg
                  viewBox="0 0 10 8"
                  fill="none"
                  className="w-full h-full p-[2px]"
                >
                  <path
                    d="M1 4L3.5 6.5L9 1"
                    stroke="#09090b"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              )}
            </span>
            {goal}
          </button>
        );
      })}
    </div>
  );
}

// ─── Success screen ───────────────────────────────────────────────────────────

function SuccessScreen({ name }: { name: string }) {
  return (
    <div className="w-full max-w-lg text-center">
      <div className="mx-auto mb-8 relative h-20 w-20">
        <div className="absolute inset-0 rounded-full border border-amber-400/20 animate-ping" />
        <div className="relative flex h-full w-full items-center justify-center rounded-full border border-amber-400/30 bg-amber-400/[0.06]">
          <svg
            className="h-9 w-9 text-amber-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4.5 12.75l6 6 9-13.5"
            />
          </svg>
        </div>
      </div>

      <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-400/80 mb-3">
        Profile created
      </p>
      <h1 className="font-display text-3xl font-bold text-white">
        You&apos;re in, {name}.
      </h1>
      <p className="mt-3 text-sm text-zinc-500 leading-relaxed max-w-sm mx-auto">
        Your athlete profile is live and coaches can already find you in search.
        Let&apos;s build out your full story.
      </p>

      <div className="mt-8 grid grid-cols-3 gap-3 text-center">
        {[
          { label: "Profile views today", value: "0" },
          { label: "Coach searches / week", value: "—" },
          { label: "Profile strength", value: "12%" },
        ].map((s) => (
          <div
            key={s.label}
            className="rounded-xl border border-white/[0.05] bg-zinc-900 py-4 px-2"
          >
            <p className="font-display text-2xl font-bold text-white">
              {s.value}
            </p>
            <p className="mt-0.5 text-[10px] text-zinc-600 leading-tight">
              {s.label}
            </p>
          </div>
        ))}
      </div>

      <a
        href="/app"
        className="mt-8 inline-flex w-full items-center justify-center rounded-full bg-amber-400 py-3.5 text-[14px] font-bold text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.02]"
      >
        Go to my dashboard →
      </a>
    </div>
  );
}

// ─── Chevron helper ───────────────────────────────────────────────────────────

function ChevronIcon() {
  return (
    <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center">
      <svg
        className="h-4 w-4 text-zinc-600"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
        aria-hidden="true"
      >
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
      </svg>
    </span>
  );
}

// ─── Step meta ────────────────────────────────────────────────────────────────

const STEP_META = [
  {
    step: 1,
    title: "What sport do you play?",
    subtitle: "We'll personalize your profile and search visibility.",
  },
  {
    step: 2,
    title: "Where do you play?",
    subtitle: "Coaches filter by region — make sure you show up.",
  },
  {
    step: 3,
    title: "What are your goals?",
    subtitle: "We use this to surface the right opportunities for you.",
  },
];

// ─── Main page ────────────────────────────────────────────────────────────────

export default function OnboardingPage() {
  const router = useRouter();
  const [userCtx, setUserCtx] = useState<UserContext | null>(null);
  const [step, setStep] = useState(1);
  const [done, setDone] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [data, setData] = useState<OnboardingFormData>({
    sport: "",
    position: "",
    classYear: "",
    school: "",
    city: "",
    state: "",
    goals: [],
  });

  // ── Resolve user context (Supabase or mock) ────────────────────────────
  useEffect(() => {
    async function resolveUser() {
      if (isSupabaseConfigured) {
        const supabase = createClient();
        const {
          data: { user },
          error,
        } = await supabase.auth.getUser();

        if (error || !user) {
          router.replace("/signup");
          return;
        }

        if (user.user_metadata?.onboarding_complete) {
          router.replace("/app");
          return;
        }

        setUserCtx({
          firstName: user.user_metadata?.first_name ?? "Athlete",
          lastName: user.user_metadata?.last_name ?? "",
        });
      } else {
        // Mock mode
        const s = getSession();
        if (!s) {
          router.replace("/signup");
          return;
        }
        if (s.onboardingComplete) {
          router.replace("/app");
          return;
        }
        setUserCtx({ firstName: s.firstName, lastName: s.lastName });
      }
    }

    resolveUser();
  }, [router]);

  function patch(update: Partial<OnboardingFormData>) {
    setData((d) => ({ ...d, ...update }));
  }

  function canAdvance(): boolean {
    if (step === 1) return !!(data.sport && data.classYear);
    if (step === 2) return !!(data.school && data.city && data.state);
    if (step === 3) return data.goals.length > 0;
    return false;
  }

  async function handleComplete(goalsOverride?: string[]) {
    if (!userCtx) return;
    setSaving(true);
    setSaveError(null);

    const goals = goalsOverride ?? data.goals;

    if (isSupabaseConfigured) {
      // ── Persist to Supabase via server action ───────────────────────
      const result = await saveOnboardingAction({
        first_name: userCtx.firstName,
        last_name: userCtx.lastName,
        sport: data.sport,
        position: data.position,
        class_year: data.classYear,
        school: data.school,
        city: data.city,
        state: data.state,
        goals,
      });

      if (!result.ok) {
        // Non-fatal: show warning but still let the user proceed
        setSaveError(result.error ?? "Profile data could not be saved to the database.");
      }
    } else {
      // ── Mock mode: persist to localStorage ─────────────────────────
      await new Promise((r) => setTimeout(r, 700));
      const mockSession = getSession() as MockUser;
      if (mockSession) {
        updateSession({
          sport: data.sport || null,
          position: data.position || null,
          classYear: data.classYear || null,
          school: data.school || null,
          city: data.city || null,
          state: data.state || null,
          goals,
          onboardingComplete: true,
        });
      }
    }

    setSaving(false);
    setDone(true);
  }

  async function handleNext() {
    if (step < TOTAL_STEPS) {
      setStep((s) => s + 1);
      return;
    }
    await handleComplete();
  }

  if (!userCtx) return null; // loading / redirect in progress

  if (done) {
    return (
      <>
        {saveError && (
          <div className="w-full max-w-lg mb-6 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-4 py-3 text-[12px] text-amber-400/80 leading-relaxed">
            <span className="font-semibold">Note:</span> {saveError} Your
            session is active but profile data was not persisted to the
            database.
          </div>
        )}
        <SuccessScreen name={userCtx.firstName || "Athlete"} />
      </>
    );
  }

  const meta = STEP_META[step - 1];

  return (
    <div className="w-full max-w-lg">
      {/* Step dots */}
      <StepDots current={step} total={TOTAL_STEPS} />

      {/* Header */}
      <div className="mb-8">
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-400/80 mb-3">
          Set up your profile
        </p>
        <h1 className="font-display text-3xl font-bold text-white">
          {meta.title}
        </h1>
        <p className="mt-2 text-sm text-zinc-500">{meta.subtitle}</p>
      </div>

      {/* Step card */}
      <div className="rounded-2xl border border-white/[0.06] bg-zinc-900/80 p-8 shadow-2xl shadow-black/40 backdrop-blur-sm">
        {step === 1 && <Step1 data={data} onChange={patch} />}
        {step === 2 && <Step2 data={data} onChange={patch} />}
        {step === 3 && <Step3 data={data} onChange={patch} />}

        {/* Navigation */}
        <div className="mt-8 flex items-center justify-between gap-4">
          {step > 1 ? (
            <button
              type="button"
              onClick={() => setStep((s) => s - 1)}
              className="rounded-full border border-white/[0.08] px-5 py-2.5 text-[13px] text-zinc-400 hover:border-white/[0.15] hover:text-white transition-all"
            >
              ← Back
            </button>
          ) : (
            <div />
          )}

          <button
            type="button"
            onClick={handleNext}
            disabled={!canAdvance() || saving}
            className="flex-1 rounded-full bg-amber-400 py-2.5 text-[14px] font-bold text-zinc-950 transition-all hover:bg-amber-300 hover:scale-[1.02] active:scale-[0.99] disabled:opacity-40 disabled:pointer-events-none"
          >
            {saving ? (
              <span className="flex items-center justify-center gap-2">
                <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
                Saving…
              </span>
            ) : step < TOTAL_STEPS ? (
              "Continue →"
            ) : (
              "Finish Setup →"
            )}
          </button>
        </div>

        {/* Skip goals */}
        {step === 3 && (
          <p className="mt-4 text-center text-[12px] text-zinc-700">
            <button
              type="button"
              onClick={() => handleComplete([])}
              className="hover:text-zinc-500 transition-colors"
            >
              Skip for now — I&apos;ll set goals later
            </button>
          </p>
        )}
      </div>

      {/* Social proof nudge */}
      <p className="mt-6 text-center text-[12px] text-zinc-700 leading-relaxed">
        Profiles with complete info get{" "}
        <span className="text-zinc-500">3× more coach views.</span>
      </p>
    </div>
  );
}
