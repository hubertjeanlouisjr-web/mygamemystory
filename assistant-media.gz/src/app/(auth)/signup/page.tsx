"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import AuthCard from "@/components/auth/AuthCard";
import { mockSignUp } from "@/lib/session";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20";

const labelClass =
  "block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2";

export default function SignupPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
  });
  const [status, setStatus] = useState<"idle" | "loading" | "error" | "confirm">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  function set(field: keyof typeof form) {
    return (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!form.firstName || !form.lastName || !form.email || !form.password) {
      setErrorMsg("Please fill in all fields.");
      setStatus("error");
      return;
    }
    if (form.password.length < 6) {
      setErrorMsg("Password must be at least 6 characters.");
      setStatus("error");
      return;
    }

    setStatus("loading");
    setErrorMsg("");

    if (isSupabaseConfigured) {
      // ── Supabase auth ──────────────────────────────────────────────────
      const supabase = createClient();
      const { data, error } = await supabase.auth.signUp({
        email: form.email.trim().toLowerCase(),
        password: form.password,
        options: {
          data: {
            first_name: form.firstName.trim(),
            last_name: form.lastName.trim(),
            onboarding_complete: false,
          },
          // Redirect back to the app after email confirmation
          // Use window.location.origin so the redirect URL always reflects
          // the actual domain at runtime, regardless of env var state.
          emailRedirectTo: window.location.origin + "/auth/callback",
        },
      });

      if (error) {
        setErrorMsg(error.message);
        setStatus("error");
        return;
      }

      // If email confirmation is required, show a "check your inbox" state
      if (data.user && !data.session) {
        setStatus("confirm");
        return;
      }

      // Auto-confirmed (e.g., email confirmation disabled in Supabase settings)
      router.push("/onboarding");
    } else {
      // ── Mock auth (no Supabase keys configured) ────────────────────────
      const result = await mockSignUp(
        form.email,
        form.password,
        form.firstName,
        form.lastName
      );

      if (!result.ok) {
        setErrorMsg(result.error ?? "Something went wrong. Please try again.");
        setStatus("error");
        return;
      }

      router.push("/onboarding");
    }
  }

  // ── Email confirmation pending state ──────────────────────────────────────
  if (status === "confirm") {
    return (
      <div className="w-full max-w-md text-center">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full border border-emerald-500/20 bg-emerald-500/[0.06]">
          <svg
            className="h-7 w-7 text-emerald-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.8}
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25H4.5a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
            />
          </svg>
        </div>
        <h1 className="font-display text-2xl font-bold text-white">
          Check your inbox
        </h1>
        <p className="mt-3 text-sm text-zinc-500 leading-relaxed">
          We sent a confirmation link to{" "}
          <span className="text-zinc-300">{form.email}</span>. Click the link
          to activate your account, then come back here to log in.
        </p>
        <div className="mt-8">
          <Link
            href="/login"
            className="inline-flex w-full items-center justify-center rounded-full bg-amber-400 py-3 text-[14px] font-bold text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.02]"
          >
            Back to login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <AuthCard
      eyebrow="Join free"
      title="Build your athlete profile"
      subtitle="It takes 5 minutes. Coaches and scouts are already searching."
    >
      {/* Setup-required banner */}
      {!isSupabaseConfigured && (
        <div className="mb-5 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-4 py-3 text-[12px] text-amber-400/80 leading-relaxed">
          <span className="font-semibold">Supabase not configured.</span> Running
          in demo mode — no account will be created.{" "}
          <Link
            href="/docs/supabase-setup"
            className="underline hover:text-amber-300"
          >
            Setup guide →
          </Link>
        </div>
      )}

      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        {/* Name row */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="firstName" className={labelClass}>
              First name
            </label>
            <input
              id="firstName"
              type="text"
              autoComplete="given-name"
              value={form.firstName}
              onChange={set("firstName")}
              placeholder="Marcus"
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="lastName" className={labelClass}>
              Last name
            </label>
            <input
              id="lastName"
              type="text"
              autoComplete="family-name"
              value={form.lastName}
              onChange={set("lastName")}
              placeholder="Thompson"
              className={inputClass}
            />
          </div>
        </div>

        {/* Email */}
        <div>
          <label htmlFor="email" className={labelClass}>
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={set("email")}
            placeholder="you@example.com"
            className={inputClass}
          />
        </div>

        {/* Password */}
        <div>
          <label htmlFor="password" className={labelClass}>
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="new-password"
            value={form.password}
            onChange={set("password")}
            placeholder="Min. 6 characters"
            className={inputClass}
          />
        </div>

        {/* Error */}
        {status === "error" && (
          <p className="rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-2.5 text-[12px] text-red-400">
            {errorMsg}
          </p>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={status === "loading"}
          className="mt-2 w-full rounded-full bg-amber-400 py-3 text-[14px] font-bold text-zinc-950 transition-all hover:bg-amber-300 hover:scale-[1.02] active:scale-[0.99] disabled:opacity-60 disabled:pointer-events-none"
        >
          {status === "loading" ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
              Creating account…
            </span>
          ) : (
            "Create My Profile →"
          )}
        </button>

        {/* Terms note */}
        <p className="text-center text-[11px] text-zinc-700 leading-relaxed">
          By signing up you agree to our{" "}
          <Link href="/" className="underline hover:text-zinc-500">
            Terms of Service
          </Link>{" "}
          and{" "}
          <Link href="/" className="underline hover:text-zinc-500">
            Privacy Policy
          </Link>
          .
        </p>

        {/* Divider */}
        <div className="relative flex items-center gap-3 py-1">
          <span className="flex-1 h-px bg-white/[0.06]" />
          <span className="text-[11px] text-zinc-700">already have an account?</span>
          <span className="flex-1 h-px bg-white/[0.06]" />
        </div>

        <p className="text-center text-[13px] text-zinc-500">
          <Link
            href="/login"
            className="font-semibold text-amber-400 hover:text-amber-300 transition-colors"
          >
            Log in here →
          </Link>
        </p>
      </form>
    </AuthCard>
  );
}
