import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About",
  description:
    "Learn how My Game My Story is building the definitive identity platform for student athletes — and why we exist.",
};

const values = [
  {
    icon: "◈",
    title: "Athlete First",
    desc: "Every decision starts with what's best for the athlete. We build tools that serve you, not algorithms designed to extract your data.",
  },
  {
    icon: "◉",
    title: "Radical Ownership",
    desc: "Your story belongs to you. We reject the idea that athletes should be passive participants in platforms that profit off their identity without their control.",
  },
  {
    icon: "◆",
    title: "Long-Game Thinking",
    desc: "We measure success in careers built and doors opened — not clicks. Your brand today is infrastructure for your future.",
  },
  {
    icon: "◇",
    title: "Trust by Design",
    desc: "Parents, coaches, and schools need to trust the platform their athletes are on. We hold that trust seriously and build accordingly.",
  },
];

const milestones = [
  { year: "2022", event: "Founded by former D1 athletes and sports media veterans with one mission: make every athlete findable." },
  { year: "2023", event: "Launched beta program. First athletes claimed profiles, first coaches discovered talent through the platform." },
  { year: "2024", event: "Expanded to high school and collegiate programs. Refined NIL tools based on athlete feedback." },
  { year: "2025", event: "Crossed a meaningful milestone in athlete profiles. Added analytics and enhanced coach discovery features." },
  { year: "2026", event: "Expanding partnerships nationally. Building infrastructure for the next phase of athlete identity." },
];

export default function AboutPage() {
  return (
    <div className="overflow-x-hidden">
      {/* ── Page Hero ─────────────────────────────────────── */}
      <section className="relative pt-44 pb-28 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-zinc-950" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/25 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-amber-600/[0.06] blur-[120px] pointer-events-none" />
        <div
          className="absolute inset-0 opacity-[0.015] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        />
        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-6 h-px bg-amber-500/50" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
              Our Story
            </span>
            <div className="w-6 h-px bg-amber-500/50" />
          </div>
          <h1 className="font-display text-5xl sm:text-6xl font-extrabold leading-[0.92] tracking-tight text-white mb-7">
            Built by athletes.
            <br />
            <span className="bg-gradient-to-r from-amber-400 to-amber-500 bg-clip-text text-transparent">
              For athletes.
            </span>
          </h1>
          <p className="text-zinc-400 text-base leading-relaxed max-w-lg mx-auto font-light">
            We started My Game My Story because we lived the problem. After years
            in competitive sports, we watched talented athletes get overlooked —
            not because they weren&apos;t good enough, but because no one could
            find their story.
          </p>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Mission ──────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-20 items-center">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Our Mission
              </span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold leading-[1.0] tracking-tight text-white mb-7">
              Every athlete
              <br />
              deserves to be
              <br />
              <span className="text-zinc-600">seen.</span>
            </h2>
            <p className="text-zinc-400 text-base leading-relaxed mb-5 font-light">
              The recruiting world is opaque and unfair. Coaches find athletes
              through networks, word-of-mouth, and expensive scouting services.
              The best player in the room is often invisible.
            </p>
            <p className="text-zinc-400 text-base leading-relaxed font-light">
              My Game My Story is the infrastructure for athlete identity. We give
              every student athlete the tools to build a professional digital
              presence — for free — and connect them with the people who can
              change their trajectory.
            </p>
          </div>

          <div className="space-y-3">
            {[
              [
                "The Problem",
                "Talented athletes remain invisible online while coaches rely on expensive and exclusionary scouting networks.",
              ],
              [
                "Our Approach",
                "A free, premium profile platform that makes athlete identity discoverable, verifiable, and narrative-rich.",
              ],
              [
                "The Result",
                "Athletes get recruited on merit. Coaches find the right fit. Programs build genuine brand equity.",
              ],
            ].map(([title, text]) => (
              <div
                key={title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 hover:border-white/10 hover:bg-zinc-900 transition-all duration-300"
              >
                <h3 className="font-display text-white font-bold mb-2 text-sm tracking-tight">{title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Values ───────────────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                What We Stand For
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Our values.
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {values.map((v) => (
              <div
                key={v.title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-8 hover:border-amber-500/15 hover:bg-zinc-900 transition-all duration-300"
              >
                <div className="text-amber-400/70 text-xl mb-6">{v.icon}</div>
                <h3 className="font-display text-white font-bold text-base mb-3 tracking-tight">{v.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Timeline ─────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-3xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Timeline
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              How we got here.
            </h2>
          </div>
          <div className="relative">
            <div className="absolute left-6 top-0 bottom-0 w-px bg-white/[0.04]" />
            <div className="space-y-10 pl-16">
              {milestones.map((m) => (
                <div key={m.year} className="relative">
                  <div className="absolute -left-10 top-1 w-3 h-3 rounded-full bg-amber-400 ring-4 ring-zinc-950 ring-offset-0" />
                  <span className="font-display text-xs font-bold uppercase tracking-[0.18em] text-amber-400">
                    {m.year}
                  </span>
                  <p className="mt-1.5 text-zinc-400 text-sm leading-relaxed font-light">
                    {m.event}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Team ─────────────────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="grid md:grid-cols-2 gap-20 items-center">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-6 h-px bg-amber-500/50" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                  The Team
                </span>
              </div>
              <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white mb-7 leading-tight tracking-tight">
                People who
                <br />
                get it.
              </h2>
              <p className="text-zinc-400 text-base leading-relaxed mb-5 font-light">
                We&apos;re a small founding team of former athletes, coaches,
                brand builders, and technologists united by one belief: every
                student athlete deserves a platform as powerful as their game.
              </p>
              <p className="text-zinc-600 text-sm leading-relaxed font-light">
                We&apos;re hiring athletes who turned builders. If that&apos;s
                you, reach out.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                ["J.R.", "Co-Founder & CEO", "Former D1 Track"],
                ["Aisha M.", "Co-Founder & CPO", "Former D2 Soccer"],
                ["Devon S.", "CTO", "Sports tech veteran"],
                ["Maria L.", "Head of Partnerships", "NCAA compliance"],
              ].map(([name, role, bg]) => (
                <div
                  key={name}
                  className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 text-center hover:border-white/10 transition-colors"
                >
                  <div className="w-11 h-11 rounded-full bg-amber-400/[0.08] border border-amber-400/20 mx-auto mb-4 flex items-center justify-center text-amber-400 font-display font-bold text-sm">
                    {(name as string).charAt(0)}
                  </div>
                  <p className="font-display text-white font-bold text-sm tracking-tight">{name}</p>
                  <p className="text-zinc-500 text-xs mt-0.5">{role}</p>
                  <p className="text-zinc-700 text-xs mt-1 font-light">{bg}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-display text-4xl font-extrabold text-white mb-4 leading-tight tracking-tight">
            Ready to own your story?
          </h2>
          <p className="text-zinc-500 text-base mb-10 leading-relaxed font-light">
            Join the growing community of athletes building their identity on My
            Game My Story.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/athletes"
              className="rounded-full bg-amber-400 px-8 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
            >
              Get Started Free
            </Link>
            <Link
              href="/contact"
              className="rounded-full border border-white/10 px-8 py-4 text-sm font-medium text-zinc-400 hover:text-white hover:bg-white/[0.04] hover:border-white/20 transition-all"
            >
              Get in Touch
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
