/**
 * Public athlete profile page — /athlete/[slug]
 *
 * Data strategy (in order):
 *  1. If Supabase is configured, query athlete_profiles by slug where is_public = true.
 *     Also fetch related social_links, athlete_stats, and featured athlete_media.
 *  2. If no DB record is found (or Supabase is not configured), fall back to mock data
 *     from @/lib/mock-data. This keeps the marketing demo site working with no DB.
 *  3. If neither source has the slug, call notFound().
 *
 * dynamicParams = true so DB-backed slugs (not in generateStaticParams) are SSR'd.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { mockAthletes } from "@/lib/mock-data";
import { getPublicAthleteBySlugAction } from "@/lib/actions/profile";
import {
  trackProfileViewAction,
  getPublicProfileAnalyticsAction,
} from "@/lib/actions/analytics";
import type { AthleteProfile, SocialLink, AthleteStat, AthleteMedia } from "@/lib/supabase/types";

// Allow DB-backed slugs beyond the statically pre-rendered mock set
export const dynamicParams = true;

interface Props {
  params: Promise<{ slug: string }>;
}

// ── Unified view model ─────────────────────────────────────────────────────
// Both mock data and DB data are normalized into this shape before rendering.

interface AthleteViewModel {
  firstName: string;
  lastName: string;
  sport: string;
  position: string;
  classYear: string;
  school: string;
  city: string;
  state: string;
  bio: string;
  story: string;
  verified: boolean;
  stats: { label: string; value: string }[];
  academics: {
    gpa: string;
    sat?: string;
    act?: string;
    major?: string;
    honors?: string[];
  };
  achievements: string[];
  socials: {
    instagram?: string;
    twitter?: string;
    hudl?: string;
    maxpreps?: string;
    youtube?: string;
  };
  highlights: {
    id: string;
    title: string;
    type: "video" | "photo";
    views: number;
    date: string;
    duration?: string;
    description?: string;
  }[];
  faith?: string;
  community?: string;
  family?: string;
  analytics: {
    profileViews: number;
    weeklyViews: number;
    coachViews: number;
    searchImpressions: number;
  };
}

// ── Adapters ───────────────────────────────────────────────────────────────

function dbToViewModel(
  profile: AthleteProfile,
  links: SocialLink[],
  stats: AthleteStat[],
  media: AthleteMedia[],
  analyticsData?: {
    profileViews: number;
    weeklyViews: number;
    coachViews: number;
    searchImpressions: number;
  } | null
): AthleteViewModel {
  const link = (platform: string) =>
    links.find((l) => l.platform === platform)?.url;

  return {
    firstName: profile.first_name,
    lastName: profile.last_name,
    sport: profile.sport,
    position: profile.position ?? "",
    classYear: profile.class_year,
    school: profile.school,
    city: profile.city,
    state: profile.state,
    bio: profile.bio ?? "",
    story: profile.story ?? "",
    verified: false, // verification is a future feature
    stats: stats.map((s) => ({
      label: s.stat_label ?? s.stat_key,
      value: s.stat_value,
    })),
    academics: {
      gpa: profile.gpa != null ? String(profile.gpa) : "",
      sat: profile.sat_score != null ? String(profile.sat_score) : undefined,
      act: profile.act_score != null ? String(profile.act_score) : undefined,
      major: profile.major ?? undefined,
      honors: profile.honors?.length ? profile.honors : undefined,
    },
    achievements: profile.achievements ?? [],
    socials: {
      instagram: link("instagram"),
      twitter: link("twitter"),
      hudl: link("hudl"),
      maxpreps: link("maxpreps"),
      youtube: link("youtube"),
    },
    highlights: media.map((m) => ({
      id: m.id,
      title: m.title,
      type: m.type === "video" ? "video" : "photo",
      views: m.view_count,
      date: m.created_at,
      duration:
        m.duration_seconds != null
          ? `${Math.floor(m.duration_seconds / 60)}:${String(
              m.duration_seconds % 60
            ).padStart(2, "0")}`
          : undefined,
      description: m.description ?? undefined,
    })),
    faith: profile.faith_statement ?? undefined,
    community: profile.community_involvement ?? undefined,
    family: profile.family_values ?? undefined,
    analytics: {
      profileViews: analyticsData?.profileViews ?? 0,
      weeklyViews: analyticsData?.weeklyViews ?? 0,
      coachViews: analyticsData?.coachViews ?? 0,
      searchImpressions: analyticsData?.searchImpressions ?? 0,
    },
  };
}

// ── Metadata ───────────────────────────────────────────────────────────────

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;

  // Try DB first
  const dbData = await getPublicAthleteBySlugAction(slug);
  if (dbData) {
    const { first_name, last_name, position, sport, bio } = dbData.profile;
    return {
      title: `${first_name} ${last_name} | ${position ?? sport}`,
      description: bio ?? undefined,
    };
  }

  // Fall back to mock
  const mock = mockAthletes.find((a) => a.slug === slug);
  if (!mock) return { title: "Athlete Not Found" };
  return {
    title: `${mock.name} | ${mock.position}, ${mock.sport}`,
    description: mock.bio,
  };
}

// Pre-render the demo/mock slugs at build time
export async function generateStaticParams() {
  return mockAthletes.map((a) => ({ slug: a.slug }));
}

// ── Helpers ────────────────────────────────────────────────────────────────

function formatViews(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return n.toString();
}

function SocialIcon({ type }: { type: string }) {
  if (type === "instagram") return <span className="font-mono text-[10px]">IG</span>;
  if (type === "twitter") return <span className="font-mono text-[10px]">X</span>;
  if (type === "hudl") return <span className="font-mono text-[10px]">HD</span>;
  if (type === "youtube") return <span className="font-mono text-[10px]">YT</span>;
  return <span className="font-mono text-[10px]">↗</span>;
}

// ── Page ───────────────────────────────────────────────────────────────────

export default async function AthletePage({ params }: Props) {
  const { slug } = await params;

  // 1. Try DB — also track the view and fetch analytics counts in parallel
  let a: AthleteViewModel | null = null;
  const dbData = await getPublicAthleteBySlugAction(slug);
  if (dbData) {
    const athleteUserId = dbData.profile.user_id;

    // Track + fetch analytics concurrently so neither blocks the other
    const [, analyticsData] = await Promise.all([
      trackProfileViewAction(athleteUserId).catch(() => undefined),
      getPublicProfileAnalyticsAction(athleteUserId).catch(() => null),
    ]);

    a = dbToViewModel(
      dbData.profile,
      dbData.links,
      dbData.stats,
      dbData.media,
      analyticsData
    );
  }

  // 2. Fall back to mock
  if (!a) {
    const mock = mockAthletes.find((m) => m.slug === slug);
    if (mock) {
      a = {
        firstName: mock.firstName,
        lastName: mock.lastName,
        sport: mock.sport,
        position: mock.position,
        classYear: mock.classYear,
        school: mock.school,
        city: mock.city,
        state: mock.state,
        bio: mock.bio,
        story: mock.story,
        verified: mock.verified,
        stats: mock.stats,
        academics: mock.academics,
        achievements: mock.achievements,
        socials: mock.socials,
        highlights: mock.highlights.map((h) => ({
          ...h,
          type: h.type === "video" ? "video" : "photo",
        })),
        faith: mock.faith,
        community: mock.community,
        family: mock.family,
        analytics: {
          profileViews: mock.analytics.profileViews,
          weeklyViews: mock.analytics.weeklyViews,
          coachViews: mock.analytics.coachViews,
          searchImpressions: mock.analytics.searchImpressions,
        },
      };
    }
  }

  // 3. Neither source has the slug
  if (!a) notFound();

  const totalHighlightViews = a.highlights.reduce((sum, h) => sum + h.views, 0);

  return (
    <div className="min-h-screen pt-[60px]">

      {/* ─── Hero ─────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-zinc-950 px-6 pb-0 pt-16 lg:pt-24">
        {/* Background atmosphere */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 h-96 w-96 bg-amber-600/[0.06] blur-[120px] rounded-full" />
          <div className="absolute bottom-0 right-1/3 h-64 w-64 bg-amber-400/[0.04] blur-[80px] rounded-full" />
          <div
            className="absolute inset-0 opacity-[0.035]"
            style={{
              backgroundImage:
                "radial-gradient(circle, #a1a1aa 1px, transparent 1px)",
              backgroundSize: "28px 28px",
            }}
          />
          <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-bl from-amber-400/[0.03] to-transparent" />
        </div>

        <div className="relative mx-auto max-w-5xl">
          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-12 pb-12 border-b border-white/[0.06]">

            {/* Avatar block */}
            <div className="shrink-0">
              <div className="relative">
                <div className="flex h-28 w-28 lg:h-36 lg:w-36 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400/20 to-amber-600/10 border border-amber-400/20 text-3xl lg:text-4xl font-display font-black text-amber-400">
                  {a.firstName[0]}{a.lastName[0]}
                </div>
                {a.verified && (
                  <div className="absolute -bottom-2 -right-2 flex items-center gap-1.5 rounded-full bg-emerald-400/15 border border-emerald-400/30 px-2.5 py-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    <span className="text-[10px] font-bold text-emerald-400">
                      Verified
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Name & details */}
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="inline-flex items-center rounded-full border border-amber-400/20 bg-amber-400/[0.08] px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-amber-400">
                  {a.sport}
                </span>
                <span className="text-[12px] text-zinc-500">{a.position}</span>
                <span className="text-zinc-700 text-[10px]">·</span>
                <span className="text-[12px] text-zinc-500">
                  Class of {a.classYear}
                </span>
              </div>

              <h1 className="font-display text-4xl lg:text-6xl font-black text-white tracking-tight leading-none">
                {a.firstName}{" "}
                <span className="text-amber-400">{a.lastName}</span>
              </h1>

              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-zinc-400">
                <span>{a.school}</span>
                <span className="text-zinc-700">·</span>
                <span>
                  {a.city}, {a.state}
                </span>
              </div>

              {a.bio && (
                <p className="mt-4 max-w-xl text-[15px] text-zinc-400 leading-relaxed">
                  {a.bio}
                </p>
              )}

              {a.stats.length > 0 && (
                <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2">
                  {a.stats.slice(0, 4).map((stat) => (
                    <div key={stat.label} className="text-center">
                      <p className="font-display text-xl font-bold text-white">
                        {stat.value}
                      </p>
                      <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                        {stat.label}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Right panel: analytics */}
            <div className="shrink-0 lg:self-center">
              <div className="rounded-xl border border-white/[0.08] bg-zinc-900/70 p-5 space-y-4 min-w-[160px]">
                <div className="text-center">
                  <p className="font-display text-2xl font-bold text-amber-400">
                    {a.analytics.profileViews.toLocaleString()}
                  </p>
                  <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                    Profile Views
                  </p>
                </div>
                <div className="h-px bg-white/[0.06]" />
                <div className="text-center">
                  <p className="font-display text-2xl font-bold text-white">
                    {a.analytics.coachViews}
                  </p>
                  <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                    Coach Views
                  </p>
                </div>
                <div className="h-px bg-white/[0.06]" />
                <div className="text-center">
                  <p className="font-display text-2xl font-bold text-white">
                    {formatViews(totalHighlightViews)}
                  </p>
                  <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                    Highlight Views
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Main content ─────────────────────────────────────── */}
      <section className="mx-auto max-w-5xl px-6 py-12 grid lg:grid-cols-3 gap-10">

        {/* Left: main bio column */}
        <div className="lg:col-span-2 space-y-12">

          {/* Story */}
          {a.story && (
            <div>
              <h2 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                My Story
              </h2>
              <p className="text-[15px] text-zinc-300 leading-relaxed whitespace-pre-line">
                {a.story}
              </p>
            </div>
          )}

          {/* Full stats */}
          {a.stats.length > 0 && (
            <div>
              <h2 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                Stats &amp; Measurables
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {a.stats.map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-lg border border-white/[0.06] bg-zinc-900 px-4 py-3 text-center"
                  >
                    <p className="font-display text-xl font-bold text-white">
                      {stat.value}
                    </p>
                    <p className="mt-0.5 text-[10px] uppercase tracking-wider text-zinc-600">
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Achievements */}
          {a.achievements.length > 0 && (
            <div>
              <h2 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                Achievements &amp; Honors
              </h2>
              <ul className="space-y-2.5">
                {a.achievements.map((ach, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-3 text-[14px] text-zinc-300"
                  >
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400" />
                    {ach}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Highlights */}
          {a.highlights.length > 0 && (
            <div>
              <h2 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                Highlights
              </h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {a.highlights.map((h) => (
                  <div
                    key={h.id}
                    className="group relative flex flex-col rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden hover:border-amber-400/20 transition-all"
                  >
                    <div className="relative aspect-video bg-zinc-800">
                      <div
                        className="absolute inset-0 opacity-20"
                        style={{
                          backgroundImage:
                            "linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)",
                          backgroundSize: "20px 20px",
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400/80 group-hover:bg-amber-400/20 transition-colors">
                          {h.type === "video" ? (
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                              <path d="M4 3l7 4-7 4V3z" fill="currentColor" />
                            </svg>
                          ) : (
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                              <rect
                                x="1" y="2" width="12" height="9" rx="1.5"
                                stroke="currentColor" strokeWidth="1.2"
                              />
                              <circle cx="4.5" cy="5.5" r="1" fill="currentColor" />
                              <path
                                d="M1 9l3-2.5 2.5 2 2-2L13 9"
                                stroke="currentColor" strokeWidth="1.1" strokeLinejoin="round"
                              />
                            </svg>
                          )}
                        </div>
                      </div>
                      {h.duration && (
                        <span className="absolute bottom-2 right-2 rounded bg-zinc-950/80 px-1.5 py-0.5 text-[10px] font-mono text-zinc-400">
                          {h.duration}
                        </span>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-display text-[13px] font-bold text-white">
                        {h.title}
                      </h3>
                      {h.description && (
                        <p className="mt-1 text-[11px] text-zinc-500 line-clamp-2">
                          {h.description}
                        </p>
                      )}
                      <p className="mt-2 text-[11px] font-semibold text-amber-400">
                        {formatViews(h.views)} views
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Optional: Faith / Community / Family */}
          {(a.faith || a.community || a.family) && (
            <div className="rounded-xl border border-white/[0.06] bg-zinc-900 p-6 space-y-5">
              <h2 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600">
                Character &amp; Values
              </h2>
              {a.faith && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-amber-400/60 mb-1.5">
                    Faith
                  </p>
                  <p className="text-[14px] text-zinc-300 leading-relaxed">
                    {a.faith}
                  </p>
                </div>
              )}
              {a.community && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-amber-400/60 mb-1.5">
                    Community
                  </p>
                  <p className="text-[14px] text-zinc-300 leading-relaxed">
                    {a.community}
                  </p>
                </div>
              )}
              {a.family && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-amber-400/60 mb-1.5">
                    Family
                  </p>
                  <p className="text-[14px] text-zinc-300 leading-relaxed">
                    {a.family}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: sidebar info */}
        <div className="space-y-6">

          {/* Academics */}
          {(a.academics.gpa || a.academics.major) && (
            <div className="rounded-xl border border-white/[0.06] bg-zinc-900 p-5">
              <h3 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                Academic Profile
              </h3>
              <div className="space-y-3">
                {a.academics.gpa && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                      GPA
                    </p>
                    <p className="font-display text-2xl font-bold text-white">
                      {a.academics.gpa}
                    </p>
                  </div>
                )}
                {a.academics.sat && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                      SAT
                    </p>
                    <p className="text-[15px] font-semibold text-zinc-200">
                      {a.academics.sat}
                    </p>
                  </div>
                )}
                {a.academics.act && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                      ACT
                    </p>
                    <p className="text-[15px] font-semibold text-zinc-200">
                      {a.academics.act}
                    </p>
                  </div>
                )}
                {a.academics.major && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                      Academic Interest
                    </p>
                    <p className="text-[13px] text-zinc-300 leading-snug">
                      {a.academics.major}
                    </p>
                  </div>
                )}
                {a.academics.honors && a.academics.honors.length > 0 && (
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1.5">
                      Honors
                    </p>
                    <ul className="space-y-1">
                      {a.academics.honors.map((h, i) => (
                        <li
                          key={i}
                          className="flex items-center gap-2 text-[12px] text-zinc-400"
                        >
                          <span className="h-1 w-1 rounded-full bg-amber-400/60" />
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Social links */}
          {Object.values(a.socials).some(Boolean) && (
            <div className="rounded-xl border border-white/[0.06] bg-zinc-900 p-5">
              <h3 className="font-display text-[11px] font-bold uppercase tracking-widest text-zinc-600 mb-4">
                Find Me Online
              </h3>
              <div className="space-y-2">
                {Object.entries(a.socials)
                  .filter(([, v]) => !!v)
                  .map(([key, val]) => (
                    <div
                      key={key}
                      className="flex items-center gap-3 rounded-lg border border-white/[0.06] px-3 py-2.5 hover:border-amber-400/20 hover:bg-amber-400/[0.03] transition-all cursor-pointer"
                    >
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-zinc-800 text-zinc-400">
                        <SocialIcon type={key} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[10px] uppercase tracking-wider text-zinc-600 capitalize">
                          {key}
                        </p>
                        <p className="text-[12px] text-zinc-300 truncate">{val}</p>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Recruit CTA */}
          <div className="relative overflow-hidden rounded-xl border border-amber-400/20 bg-amber-400/[0.05] p-5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-400/[0.08] rounded-bl-full" />
            <div className="relative">
              <p className="font-display text-[11px] font-bold uppercase tracking-widest text-amber-400/70 mb-2">
                For Coaches &amp; Scouts
              </p>
              <h3 className="font-display text-[15px] font-bold text-white leading-snug">
                Interested in {a.firstName}?
              </h3>
              <p className="mt-1.5 text-[12px] text-zinc-400">
                Connect directly via My Game My Story.
              </p>
              <Link
                href="/contact"
                className="mt-4 inline-flex rounded-full bg-amber-400 px-4 py-2 text-[12px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors"
              >
                Get in Touch
              </Link>
            </div>
          </div>

          {/* Platform badge */}
          <div className="flex items-center justify-center gap-2 text-[11px] text-zinc-700">
            <span>Powered by</span>
            <Link
              href="/"
              className="font-display font-bold text-zinc-500 hover:text-amber-400 transition-colors"
            >
              My<span className="text-amber-400/70">Game</span>MyStory
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
