import type { Metadata } from "next";
import Link from "next/link";
import FAQAccordion from "@/components/FAQAccordion";

export const metadata: Metadata = {
  title: "For Athletes",
  description:
    "Build your personal brand, control your narrative, and get discovered by coaches and sponsors — all in one place.",
};

const benefits = [
  {
    icon: "◈",
    title: "Your Verified Identity",
    desc: "One professional profile that confirms who you are — sport, stats, school, highlights, and story — all in one verified place.",
  },
  {
    icon: "◉",
    title: "Own Your Search Results",
    desc: "When a coach Googles your name, your profile is what they find. Not a random tweet. Not nothing. Your narrative, optimized.",
  },
  {
    icon: "◆",
    title: "Highlight Vault",
    desc: "Upload game film, photos, and clips in one organized hub. Every big moment — preserved, shareable, and forever yours.",
  },
  {
    icon: "◇",
    title: "NIL & Sponsorship Ready",
    desc: "A professional profile built for the NIL era. When sponsors come looking, your brand is ready to make the ask easy.",
  },
  {
    icon: "◎",
    title: "Coach & Scout Visibility",
    desc: "Get in front of the right people. Our verified network actively connects athletes with coaches and decision-makers who are looking.",
  },
  {
    icon: "◌",
    title: "Profile Analytics",
    desc: "See who's viewing your profile, what they're looking at, and where they're from. Know your audience, grow your brand.",
  },
];

const steps = [
  {
    num: "01",
    title: "Claim Your Profile",
    desc: "Sign up free in minutes. Add your sport, school, position, stats, and personal story. This is your foundation.",
  },
  {
    num: "02",
    title: "Build Your Brand",
    desc: "Upload your highlights, craft your bio, and showcase your achievements. Your profile becomes your most powerful asset.",
  },
  {
    num: "03",
    title: "Get Discovered",
    desc: "Coaches, scouts, and sponsors find you on your terms. You control every impression — no middleman required.",
  },
];

const faqs = [
  {
    q: "Is My Game My Story free for athletes?",
    a: "Yes — completely free for student athletes. We believe every athlete deserves a professional digital presence, regardless of their program's budget. Premium features for enhanced visibility and analytics are available as an optional upgrade.",
  },
  {
    q: "Can I use this for NIL deals?",
    a: "Absolutely. Your profile is designed to showcase your brand to potential sponsors. Many of our athletes have used their profile to land NIL partnerships. We don't take a cut of any deals you close.",
  },
  {
    q: "What sports are supported?",
    a: "All sports. Whether you play football, soccer, track, swimming, esports, or anything else — your profile works for your sport. Stat fields and profile formats adapt based on what you select.",
  },
  {
    q: "Who can see my profile?",
    a: "You control your visibility settings. By default, your profile is discoverable by coaches, scouts, and sponsors in our verified network. You can restrict visibility at any time.",
  },
  {
    q: "What happens after high school?",
    a: "Your profile stays with you. Many athletes use My Game My Story through college and beyond — transitioning from recruiting tool to professional identity hub and alumni network presence.",
  },
  {
    q: "Do I own my content?",
    a: "Yes, always. You own everything you post. We never sell your data or content. If you close your account, all your content is yours to export.",
  },
];

export default function AthletesPage() {
  return (
    <div className="overflow-x-hidden">
      {/* ── Page Hero ─────────────────────────────────────── */}
      <section className="relative pt-44 pb-28 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-zinc-950" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/25 to-transparent" />
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-amber-600/[0.055] blur-[120px] pointer-events-none" />
        <div
          className="absolute inset-0 opacity-[0.015] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        />
        <div className="relative z-10 mx-auto max-w-7xl grid md:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                For Athletes
              </span>
            </div>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-[0.9] tracking-tight text-white mb-7">
              Your game
              <br />
              deserves to
              <br />
              <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-orange-400 bg-clip-text text-transparent">
                be found.
              </span>
            </h1>
            <p className="text-zinc-400 text-base leading-relaxed mb-10 font-light max-w-md">
              You&apos;ve put in the work. Every rep, every early morning, every
              game-day sacrifice. My Game My Story makes sure the world — coaches,
              scouts, sponsors — can actually see it.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                href="/contact"
                className="rounded-full bg-amber-400 px-8 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
              >
                Claim Your Profile — Free
              </Link>
              <a
                href="#how-it-works"
                className="rounded-full border border-white/10 px-8 py-4 text-sm font-medium text-zinc-400 hover:text-white hover:border-white/20 hover:bg-white/[0.04] transition-all"
              >
                See How It Works
              </a>
            </div>
            <div className="flex items-center gap-3 mt-6">
              <div className="w-6 h-px bg-white/10" />
              <p className="text-[11px] text-zinc-600 tracking-wider">
                Free forever for student athletes · No credit card
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {[
              ["92%", "of college coaches search athletes online before reaching out to recruit"],
              ["67%", "of student athletes have no professional digital presence for coaches to find"],
              ["$18B+", "in NIL value goes unclaimed annually by under-represented athletes"],
            ].map(([stat, text]) => (
              <div
                key={stat}
                className="group flex items-start gap-6 rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 hover:border-amber-500/20 hover:bg-zinc-900 transition-all duration-300"
              >
                <span className="font-display text-3xl font-extrabold text-amber-400 shrink-0 leading-none tabular-nums mt-0.5 group-hover:text-amber-300 transition-colors">
                  {stat}
                </span>
                <p className="text-zinc-500 text-sm leading-relaxed pt-0.5 font-light">{text}</p>
              </div>
            ))}
            <p className="text-zinc-700 text-xs px-1 pt-1">
              Industry research · NCSA recruiting surveys · NIL market analysis
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Benefits ─────────────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                What You Get
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Everything your brand needs.
            </h2>
            <p className="mt-4 text-zinc-500 max-w-lg mx-auto text-base font-light">
              Built from the ground up for athletes who take their identity as
              seriously as their training.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b) => (
              <div
                key={b.title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-8 hover:border-amber-400/20 hover:bg-zinc-900 transition-all duration-300"
              >
                <div className="text-amber-400/70 text-xl mb-6">{b.icon}</div>
                <h3 className="font-display text-base font-bold text-white mb-3 tracking-tight">{b.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ─────────────────────────────────── */}
      <section id="how-it-works" className="py-28 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Getting Started
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Up in minutes.
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-16">
            {steps.map((step, i) => (
              <div key={step.num} className="relative">
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-full w-full h-px bg-gradient-to-r from-amber-500/25 to-transparent -translate-x-8 z-0" />
                )}
                <div className="relative z-10">
                  <div className="font-display text-[96px] font-extrabold text-white/[0.03] mb-0 select-none leading-none">
                    {step.num}
                  </div>
                  <div className="w-8 h-px bg-amber-500/60 -mt-4 mb-6" />
                  <h3 className="font-display text-xl font-bold text-white mb-3 tracking-tight">
                    {step.title}
                  </h3>
                  <p className="text-zinc-500 text-sm leading-relaxed font-light">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonial ──────────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-4xl">
          <div className="relative rounded-2xl border border-amber-500/10 bg-zinc-900/60 p-12 sm:p-16 text-center overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-px bg-gradient-to-r from-transparent via-amber-500/35 to-transparent" />
            <div className="absolute top-4 left-4 w-4 h-4 border-t border-l border-amber-500/15 rounded-tl" />
            <div className="absolute top-4 right-4 w-4 h-4 border-t border-r border-amber-500/15 rounded-tr" />
            <div className="font-display text-6xl font-extrabold text-amber-500/20 leading-none mb-6 select-none">
              &ldquo;
            </div>
            <p className="text-zinc-300 text-lg leading-relaxed mb-8 max-w-2xl mx-auto font-light">
              Before My Game My Story, a Google search of my name showed nothing.
              Now it shows everything that matters about who I am as an athlete.
            </p>
            <div className="w-6 h-px bg-amber-500/30 mx-auto mb-4" />
            <p className="font-display text-white font-bold text-sm tracking-tight">Marcus T.</p>
            <p className="text-zinc-600 text-xs mt-0.5">
              D1 Wide Receiver · Class of 2025
            </p>
            <p className="text-zinc-700 text-xs mt-2">Beta participant</p>
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-3xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                FAQ
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Questions answered.
            </h2>
          </div>
          <FAQAccordion items={faqs} />
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-4xl">
          <div className="relative rounded-2xl border border-white/[0.07] bg-zinc-900/60 p-12 sm:p-20 text-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-600/[0.04] via-transparent to-transparent pointer-events-none" />
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent" />
            <div className="absolute top-4 left-4 w-4 h-4 border-t border-l border-amber-500/15 rounded-tl" />
            <div className="absolute top-4 right-4 w-4 h-4 border-t border-r border-amber-500/15 rounded-tr" />
            <div className="relative z-10">
              <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white mb-4 leading-tight tracking-tight">
                Your story starts here.
              </h2>
              <p className="text-zinc-500 text-base max-w-md mx-auto mb-10 font-light">
                Free for student athletes. Takes minutes to set up. Lasts a career.
              </p>
              <Link
                href="/contact"
                className="inline-flex rounded-full bg-amber-400 px-10 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
              >
                Claim Your Profile Free
              </Link>
              <p className="mt-5 text-[11px] text-zinc-700 tracking-wider">
                No credit card · No spam
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
