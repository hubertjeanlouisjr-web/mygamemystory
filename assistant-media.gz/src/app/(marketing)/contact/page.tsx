import type { Metadata } from "next";
import Link from "next/link";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Get in touch with the My Game My Story team — whether you're an athlete, school, brand, or press.",
};

export default function ContactPage() {
  return (
    <div className="overflow-x-hidden">
      {/* ── Page Hero ─────────────────────────────────────── */}
      <section className="relative pt-44 pb-16 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-zinc-950" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/25 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-amber-600/[0.055] blur-[120px] pointer-events-none" />
        <div className="relative z-10 max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-6 h-px bg-amber-500/50" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
              Get in Touch
            </span>
            <div className="w-6 h-px bg-amber-500/50" />
          </div>
          <h1 className="font-display text-5xl sm:text-6xl font-extrabold leading-tight tracking-tight text-white mb-5">
            Let&apos;s talk.
          </h1>
          <p className="text-zinc-400 text-base leading-relaxed font-light">
            Whether you&apos;re an athlete ready to claim your profile, a school
            looking to partner, or a brand wanting to connect — we want to hear
            from you.
          </p>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-20 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Form + Info ──────────────────────────────────── */}
      <section className="py-16 px-6 pb-32">
        <div className="mx-auto max-w-7xl grid lg:grid-cols-5 gap-16 items-start">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-6 h-px bg-amber-500/50" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                  Quick Paths
                </span>
              </div>
              <div className="space-y-3">
                {[
                  {
                    label: "Athletes",
                    desc: "Claim your free profile",
                    href: "/athletes",
                  },
                  {
                    label: "Schools & Programs",
                    desc: "Start a school partnership",
                    href: "/schools",
                  },
                  {
                    label: "Brands & Sponsors",
                    desc: "Explore sponsorship options",
                    href: "/partners",
                  },
                ].map((item) => (
                  <Link
                    key={item.label}
                    href={item.href}
                    className="flex items-center justify-between rounded-xl border border-white/[0.05] bg-zinc-900/60 p-4 hover:border-amber-400/20 hover:bg-zinc-900 transition-all group"
                  >
                    <div>
                      <p className="font-display text-white font-semibold text-sm tracking-tight">
                        {item.label}
                      </p>
                      <p className="text-zinc-600 text-xs mt-0.5 font-light">{item.desc}</p>
                    </div>
                    <span className="text-amber-500/50 group-hover:text-amber-400 group-hover:translate-x-1 transition-all text-sm">
                      →
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 space-y-5">
              <div className="flex items-center gap-3 mb-1">
                <div className="w-4 h-px bg-amber-500/40" />
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-600">
                  Direct Contact
                </p>
              </div>
              <div>
                <p className="text-zinc-700 text-[10px] uppercase tracking-widest mb-1">
                  General
                </p>
                <a
                  href="mailto:hello@mygamemystory.com"
                  className="text-zinc-400 text-sm hover:text-amber-400 transition-colors font-light"
                >
                  hello@mygamemystory.com
                </a>
              </div>
              <div>
                <p className="text-zinc-700 text-[10px] uppercase tracking-widest mb-1">
                  Partnerships
                </p>
                <a
                  href="mailto:partners@mygamemystory.com"
                  className="text-zinc-400 text-sm hover:text-amber-400 transition-colors font-light"
                >
                  partners@mygamemystory.com
                </a>
              </div>
              <div>
                <p className="text-zinc-700 text-[10px] uppercase tracking-widest mb-1">
                  Press
                </p>
                <a
                  href="mailto:press@mygamemystory.com"
                  className="text-zinc-400 text-sm hover:text-amber-400 transition-colors font-light"
                >
                  press@mygamemystory.com
                </a>
              </div>
            </div>
          </div>

          {/* Client-side contact form */}
          <div className="lg:col-span-3">
            <ContactForm />
          </div>
        </div>
      </section>
    </div>
  );
}
