import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "My Game My Story | Own Your Athlete Identity",
  description:
    "The platform for student athletes to build their personal brand, control their narrative, and own what the world finds when they search your name.",
  openGraph: {
    title: "My Game My Story — Own Your Athlete Identity",
    description:
      "Build your brand. Control your narrative. Own your search results.",
    type: "website",
  },
};

const features = [
  {
    num: "01",
    title: "Your Identity Hub",
    desc: "One verified profile that represents everything you are — stats, highlights, achievements, and your story.",
  },
  {
    num: "02",
    title: "Search Ownership",
    desc: "Control what coaches and scouts find when they search your name. Your narrative, not someone else's.",
  },
  {
    num: "03",
    title: "Brand Builder",
    desc: "Professional tools to craft your personal brand — from bio to visual identity — built for athletes.",
  },
  {
    num: "04",
    title: "Highlight Vault",
    desc: "Upload, organize, and showcase your game film and photos. Every big moment, preserved and shareable.",
  },
  {
    num: "05",
    title: "Coach & Scout Network",
    desc: "Get discovered by the right people. Our verified network connects athletes with decision-makers who matter.",
  },
  {
    num: "06",
    title: "Analytics Dashboard",
    desc: "See who's viewing your profile, where they're from, and what's resonating. Data-driven brand growth.",
  },
];

const steps = [
  {
    num: "01",
    title: "Claim Your Profile",
    desc: "Set up your athlete identity in minutes. Add your sport, school, stats, and personal story.",
  },
  {
    num: "02",
    title: "Build Your Story",
    desc: "Upload highlights, craft your bio, link your achievements. Your profile becomes your brand.",
  },
  {
    num: "03",
    title: "Get Discovered",
    desc: "Coaches, scouts, and sponsors find you on your terms. You control every impression.",
  },
];

const schoolPerks = [
  ["Recruit Smarter", "Access verified athlete profiles with real stats and highlights."],
  ["Parent Trust", "Families see a safe, professional platform built with care."],
  ["Program Visibility", "Showcase your program to recruits who are actively looking."],
  ["NIL Ready", "Athletes and programs prepared for the modern sponsorship era."],
];

const testimonials = [
  {
    quote:
      "Before My Game My Story, a Google search of my name showed nothing. Now it shows everything that matters about who I am as an athlete.",
    name: "Marcus T.",
    detail: "D1 Wide Receiver · Class of 2025",
  },
  {
    quote:
      "I use it to find talent I would never have found otherwise. The profiles are professional, detailed, and tell a real story.",
    name: "Coach Sandra R.",
    detail: "Head Volleyball Coach",
  },
  {
    quote:
      "My daughter had three offers before her senior season. This platform changed what recruiters saw when they searched her name.",
    name: "David K.",
    detail: "Parent · Track & Field",
  },
];

export default function Home() {
  return (
    <div className="overflow-x-hidden">

      {/* ── Hero ────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex flex-col justify-center px-6 pt-28 pb-20 overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0 bg-zinc-950" />
        {/* Asymmetric side panel */}
        <div className="absolute top-0 right-0 w-[55%] h-full bg-gradient-to-l from-zinc-900/60 to-transparent pointer-events-none" />
        {/* Cinematic glow — offset to the right quadrant */}
        <div className="absolute top-1/4 right-1/3 w-[800px] h-[800px] rounded-full bg-amber-600/[0.055] blur-[160px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-amber-500/[0.03] blur-[120px] pointer-events-none" />
        {/* Fine dot grid */}
        <div
          className="absolute inset-0 opacity-[0.018] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        />
        {/* Top framing line */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent pointer-events-none" />
        {/* Vertical rail — cinematic side detail */}
        <div className="absolute top-0 right-8 bottom-0 w-px bg-gradient-to-b from-transparent via-white/[0.04] to-transparent pointer-events-none hidden xl:block" />
        <div
          className="absolute right-[18px] top-1/2 -translate-y-1/2 text-[9px] font-mono tracking-[0.3em] text-zinc-700 pointer-events-none hidden xl:block"
          style={{ writingMode: "vertical-rl" }}
        >
          ATHLETE IDENTITY PLATFORM
        </div>

        <div className="relative z-10 mx-auto max-w-7xl w-full grid lg:grid-cols-[1fr,440px] gap-16 items-center">
          {/* LEFT: Editorial headline */}
          <div>
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-10">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Early Access Open
              </span>
            </div>

            <h1 className="font-display text-6xl sm:text-7xl lg:text-[88px] font-extrabold leading-[0.88] tracking-tight text-white mb-8">
              Your Game.
              <br />
              <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 bg-clip-text text-transparent">
                Your Story.
              </span>
              <br />
              <span className="text-zinc-500">Your Brand.</span>
            </h1>

            <p className="max-w-md text-base text-zinc-400 leading-relaxed mb-10 font-light">
              Student athletes spend years building their skills. We make sure
              the world sees it. Own your identity, control your narrative, and
              get found by the coaches and sponsors who matter.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center rounded-full bg-amber-400 px-8 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
              >
                Claim Your Profile
              </Link>
              <Link
                href="/athletes"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-white/10 px-8 py-4 text-sm font-medium text-zinc-400 hover:text-white hover:border-white/20 hover:bg-white/[0.04] transition-all"
              >
                Learn More
                <span className="text-zinc-600 text-xs">→</span>
              </Link>
            </div>

            <div className="flex items-center gap-4 mt-7">
              <div className="w-6 h-px bg-white/10" />
              <p className="text-[11px] text-zinc-600 tracking-wider">
                Free for student athletes&nbsp;·&nbsp;All sports&nbsp;·&nbsp;No credit card
              </p>
            </div>
          </div>

          {/* RIGHT: Profile card */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Ambient glow */}
              <div className="absolute -inset-8 bg-gradient-to-br from-amber-400/[0.05] to-transparent rounded-3xl blur-2xl pointer-events-none" />

              {/* Card shell */}
              <div className="relative rounded-2xl overflow-hidden border border-white/[0.07] bg-zinc-900 shadow-2xl shadow-black/60">
                {/* Top accent */}
                <div className="h-px bg-gradient-to-r from-transparent via-amber-500/60 to-transparent" />

                {/* Corner framing marks */}
                <div className="absolute top-3 left-3 w-4 h-4 border-t border-l border-amber-500/20 rounded-tl" />
                <div className="absolute top-3 right-3 w-4 h-4 border-t border-r border-amber-500/20 rounded-tr" />
                <div className="absolute bottom-3 left-3 w-4 h-4 border-b border-l border-amber-500/20 rounded-bl" />
                <div className="absolute bottom-3 right-3 w-4 h-4 border-b border-r border-amber-500/20 rounded-br" />

                <div className="p-6">
                  {/* Card header */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-amber-500/25 to-amber-700/10 border border-amber-400/25 flex items-center justify-center text-amber-400 font-display font-bold text-sm select-none">
                        MT
                      </div>
                      <div>
                        <p className="text-white font-semibold text-sm leading-tight">
                          Marcus Thompson
                        </p>
                        <p className="text-zinc-500 text-xs mt-0.5">
                          Wide Receiver · #17 · Sr.
                        </p>
                      </div>
                    </div>
                    <span className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-semibold bg-emerald-400/[0.08] border border-emerald-400/20 rounded-full px-2.5 py-1 uppercase tracking-widest">
                      <span className="w-1 h-1 rounded-full bg-emerald-400" />
                      Verified
                    </span>
                  </div>

                  <div className="h-px bg-white/[0.05] mb-5" />

                  {/* Athlete stats */}
                  <div className="grid grid-cols-3 gap-2 mb-5">
                    {[
                      ["6′2″", "Height"],
                      ["185", "lbs"],
                      ["4.38s", "40-Yd"],
                    ].map(([v, l]) => (
                      <div
                        key={l}
                        className="rounded-lg bg-zinc-800/50 border border-white/[0.05] p-3 text-center"
                      >
                        <p className="text-white font-display font-bold text-sm tabular-nums">
                          {v}
                        </p>
                        <p className="text-zinc-600 text-[10px] mt-0.5 uppercase tracking-wider">
                          {l}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Profile strength */}
                  <div className="mb-5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] text-zinc-600 uppercase tracking-widest">
                        Profile Strength
                      </span>
                      <span className="text-[10px] font-bold text-amber-400 font-display">
                        91 / 100
                      </span>
                    </div>
                    <div className="h-0.5 rounded-full bg-zinc-800 overflow-hidden">
                      <div
                        className="h-0.5 rounded-full bg-gradient-to-r from-amber-600 to-amber-300"
                        style={{ width: "91%" }}
                      />
                    </div>
                  </div>

                  {/* Weekly views */}
                  <div className="flex items-center justify-between rounded-xl bg-zinc-800/30 border border-white/[0.04] px-4 py-3 mb-5">
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      <span className="text-xs text-zinc-500">
                        Profile views this week
                      </span>
                    </div>
                    <span className="text-sm font-display font-bold text-white tabular-nums">
                      2,140 ↗
                    </span>
                  </div>

                  {/* Highlights */}
                  <div>
                    <p className="text-[10px] text-zinc-700 uppercase tracking-widest mb-2">
                      Highlights
                    </p>
                    <div className="flex gap-2">
                      {["vs. Lincoln", "State Finals", "Senior Day"].map((label) => (
                        <div
                          key={label}
                          className="flex-1 h-14 rounded-lg bg-zinc-800/60 border border-white/[0.04] flex items-end p-1.5 relative overflow-hidden"
                        >
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/60 to-transparent" />
                          <span className="relative text-zinc-600 text-[9px] leading-tight">{label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating notification */}
              <div className="absolute -bottom-4 -right-4 flex items-center gap-2 rounded-full bg-zinc-800/95 border border-white/[0.08] px-3.5 py-2 shadow-2xl shadow-black/50 backdrop-blur-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                <span className="text-white text-xs font-medium">
                  Coach viewed your profile
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Credibility Bar ──────────────────────────────────── */}
      <section className="relative border-y border-white/[0.05]">
        <div className="absolute inset-0 bg-zinc-900/30" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/15 to-transparent" />
        <div className="relative mx-auto max-w-7xl px-6 py-5">
          <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-600">
            {[
              "Free for Athletes",
              "All Sports",
              "Privacy-First",
              "NIL-Ready",
              "Founded 2022",
            ].map((item, i, arr) => (
              <span key={item} className="flex items-center gap-10">
                {item}
                {i < arr.length - 1 && (
                  <span className="w-px h-3 bg-zinc-800 shrink-0" />
                )}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why It Matters ──────────────────────────────────── */}
      <section id="why" className="py-32 px-6">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-20 items-center">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                The Problem
              </span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold leading-[1.0] tracking-tight text-white mb-7">
              You work harder
              <br />
              than anyone.
              <br />
              <span className="text-zinc-600">Does the world know?</span>
            </h2>
            <p className="text-zinc-400 text-base leading-relaxed mb-4 font-light">
              When coaches, scouts, and sponsors search your name, what do they
              find? A blank page. An old article. A social profile that
              doesn&apos;t do you justice.
            </p>
            <p className="text-zinc-400 text-base leading-relaxed font-light">
              Your athletic identity is one of the most valuable assets
              you&apos;ll ever build. My Game My Story gives you the tools to
              shape it — on your terms.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {[
              ["92%", "of college coaches search athletes online before reaching out to recruit"],
              ["67%", "of student athletes have no professional digital presence to show their work"],
              ["$18B+", "in NIL value goes unclaimed each year by under-represented athletes"],
            ].map(([stat, text]) => (
              <div
                key={stat}
                className="group flex items-start gap-6 rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 hover:border-amber-500/20 hover:bg-zinc-900 transition-all duration-300"
              >
                <span className="font-display text-3xl font-extrabold text-amber-400 shrink-0 leading-none tabular-nums mt-0.5 group-hover:text-amber-300 transition-colors">
                  {stat}
                </span>
                <p className="text-zinc-500 text-sm leading-relaxed pt-0.5">{text}</p>
              </div>
            ))}
            <p className="text-zinc-700 text-xs px-1 pt-1">
              Industry research · NCSA recruiting surveys · NIL market analysis
            </p>
          </div>
        </div>
      </section>

      {/* ── Features ────────────────────────────────────────── */}
      <section id="features" className="py-32 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-6 h-px bg-amber-500/50" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                  The Platform
                </span>
              </div>
              <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white leading-tight tracking-tight">
                Everything your
                <br />
                brand needs.
              </h2>
            </div>
            <p className="text-zinc-600 max-w-xs text-sm leading-relaxed md:text-right font-light">
              Built from the ground up for athletes who take their identity as
              seriously as their training.
            </p>
          </div>

          {/* Feature grid — gap-px divider approach with amber left-border hover */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/[0.04] rounded-2xl overflow-hidden">
            {features.map((f) => (
              <div
                key={f.title}
                className="bg-zinc-950 p-9 hover:bg-zinc-900/70 transition-colors duration-300 group relative"
              >
                {/* Amber left-border reveal on hover */}
                <div className="absolute left-0 top-8 bottom-8 w-px bg-amber-500/0 group-hover:bg-amber-500/40 transition-colors duration-300" />
                <div className="font-display text-[11px] font-bold text-zinc-700 tracking-[0.2em] mb-6 group-hover:text-amber-500/60 transition-colors">
                  {f.num}
                </div>
                <h3 className="font-display text-base font-bold text-white mb-3 tracking-tight">{f.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ────────────────────────────────────── */}
      <section className="py-32 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="mb-20">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Getting Started
              </span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Up in minutes.
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-16">
            {steps.map((step, i) => (
              <div key={step.num} className="relative">
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-full w-full h-px bg-gradient-to-r from-amber-500/20 to-transparent -translate-x-8 z-0" />
                )}
                <div className="relative z-10">
                  <div className="font-display text-[96px] font-extrabold text-white/[0.03] select-none leading-none -ml-2 mb-0">
                    {step.num}
                  </div>
                  <div className="w-8 h-px bg-amber-500/60 -mt-4 mb-6" />
                  <h3 className="font-display text-xl font-bold text-white mb-3 tracking-tight">
                    {step.title}
                  </h3>
                  <p className="text-zinc-500 text-sm leading-relaxed font-light">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Schools & Programs ──────────────────────────────── */}
      <section id="schools" className="py-32 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-20 items-center">
          <div className="order-2 md:order-1 grid grid-cols-2 gap-3">
            {schoolPerks.map(([title, desc]) => (
              <div
                key={title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-5 hover:border-amber-500/15 hover:bg-zinc-900 transition-all duration-300"
              >
                <h4 className="font-display text-white font-bold text-sm mb-2 tracking-tight">{title}</h4>
                <p className="text-zinc-600 text-xs leading-relaxed font-light">{desc}</p>
              </div>
            ))}
          </div>

          <div className="order-1 md:order-2">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                For Schools &amp; Programs
              </span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold leading-[1.0] tracking-tight text-white mb-7">
              Built for every
              <br />
              stakeholder in
              <br />
              <span className="bg-gradient-to-r from-amber-400 to-amber-500 bg-clip-text text-transparent">
                athletics.
              </span>
            </h2>
            <p className="text-zinc-400 text-base leading-relaxed mb-8 font-light">
              Whether you&apos;re a coach looking to recruit, a school building
              its athletics brand, or a sponsor identifying the next generation
              of talent — My Game My Story is your platform too.
            </p>
            <Link
              href="/schools"
              className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 px-6 py-3 text-sm font-medium text-amber-400 hover:bg-amber-400/[0.07] hover:border-amber-400/50 transition-all"
            >
              Explore for Schools
              <span className="text-amber-600 text-xs">→</span>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Testimonials ────────────────────────────────────── */}
      <section className="py-32 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-20">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-6 h-px bg-amber-500/50" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                  Early Access Voices
                </span>
              </div>
              <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
                Stories that matter.
              </h2>
            </div>
            <p className="text-zinc-700 text-xs max-w-xs md:text-right leading-relaxed uppercase tracking-widest">
              From our beta community of athletes,<br />coaches, and families.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {testimonials.map((t) => (
              <div
                key={t.name}
                className="rounded-2xl border border-white/[0.05] bg-zinc-900/60 p-8 flex flex-col justify-between hover:border-white/10 hover:bg-zinc-900 transition-all duration-300 group"
              >
                <div>
                  {/* Large editorial quote mark */}
                  <div className="font-display text-6xl font-extrabold text-amber-500/20 leading-none mb-5 select-none group-hover:text-amber-500/30 transition-colors">
                    &ldquo;
                  </div>
                  <p className="text-zinc-300 text-sm leading-relaxed mb-8 font-light">
                    {t.quote}
                  </p>
                </div>
                <div>
                  <div className="w-6 h-px bg-amber-500/30 mb-4" />
                  <p className="text-white font-semibold text-sm">{t.name}</p>
                  <p className="text-zinc-600 text-xs mt-0.5">{t.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ───────────────────────────────────────── */}
      <section id="cta" className="py-32 px-6 pb-36">
        <div className="mx-auto max-w-4xl">
          <div className="relative rounded-2xl border border-white/[0.07] bg-zinc-900/70 p-12 sm:p-20 overflow-hidden">
            {/* Layered atmosphere */}
            <div className="absolute inset-0 bg-gradient-to-br from-amber-600/[0.04] via-transparent to-zinc-950/50 pointer-events-none" />
            {/* Framing lines */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent" />
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/3 h-px bg-gradient-to-r from-transparent via-amber-500/20 to-transparent" />
            <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1/2 w-px bg-gradient-to-b from-transparent via-white/[0.04] to-transparent" />
            <div className="absolute right-0 top-1/2 -translate-y-1/2 h-1/2 w-px bg-gradient-to-b from-transparent via-white/[0.04] to-transparent" />
            {/* Corner marks */}
            <div className="absolute top-4 left-4 w-5 h-5 border-t border-l border-amber-500/15 rounded-tl" />
            <div className="absolute top-4 right-4 w-5 h-5 border-t border-r border-amber-500/15 rounded-tr" />
            <div className="absolute bottom-4 left-4 w-5 h-5 border-b border-l border-amber-500/15 rounded-bl" />
            <div className="absolute bottom-4 right-4 w-5 h-5 border-b border-r border-amber-500/15 rounded-br" />

            <div className="relative z-10 text-center">
              <div className="flex items-center justify-center gap-3 mb-7">
                <div className="w-8 h-px bg-amber-500/40" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                  Your Identity Awaits
                </span>
                <div className="w-8 h-px bg-amber-500/40" />
              </div>
              <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-white mb-6 leading-[0.92] tracking-tight">
                Own your story.
                <br />
                <span className="bg-gradient-to-r from-amber-400 to-amber-500 bg-clip-text text-transparent">
                  Start today.
                </span>
              </h2>
              <p className="text-zinc-500 text-base max-w-md mx-auto mb-10 leading-relaxed font-light">
                Take control of your athlete identity. Get found by the coaches,
                scouts, and sponsors who are looking for exactly what you bring.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link
                  href="/contact"
                  className="rounded-full bg-amber-400 px-10 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
                >
                  Claim Your Profile Free
                </Link>
                <Link
                  href="/about"
                  className="rounded-full border border-white/10 px-10 py-4 text-sm font-medium text-zinc-400 hover:text-white hover:bg-white/[0.04] hover:border-white/20 transition-all"
                >
                  Our Story
                </Link>
              </div>
              <p className="mt-6 text-[11px] text-zinc-700 tracking-wider">
                Free for student athletes &nbsp;·&nbsp; No credit card required
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
