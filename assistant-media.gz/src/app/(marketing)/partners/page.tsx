import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "For Partners & Sponsors",
  description:
    "Connect with the next generation of student athletes. Build authentic brand partnerships through My Game My Story.",
};

const partnerTypes = [
  {
    icon: "◈",
    title: "Brands & Sponsors",
    desc: "Reach verified student athletes who are actively building their brand. Partner on NIL deals, product sponsorships, and ambassador programs — with built-in authenticity.",
  },
  {
    icon: "◉",
    title: "Media & Content",
    desc: "Access rich athlete profiles and compelling stories for editorial, social, documentary, and branded content. Real athletes, real narratives, verified.",
  },
  {
    icon: "◆",
    title: "Recruiting Services",
    desc: "Integrate your recruiting platform with our verified athlete database. Supplement your scouting with rich profile data and direct athlete communication tools.",
  },
  {
    icon: "◇",
    title: "Technology Partners",
    desc: "Build on top of our athlete identity infrastructure. From wearables to performance analytics to training apps — connect where athletes already live.",
  },
];

const whyPartner = [
  ["All Sports", "Verified student athletes across every sport and class year."],
  ["School Partnerships", "Programs in high school and collegiate athletics."],
  ["High Intent", "Athletes actively building their brand are engaged audiences."],
  ["Privacy-First", "A moderated, professional environment brands can trust."],
];

const partnershipTiers = [
  {
    name: "Brand Partner",
    desc: "Ideal for emerging brands looking to enter the athlete space authentically.",
    features: [
      "Sponsored athlete spotlight features",
      "Co-branded campaign tools",
      "Athlete audience targeting",
      "Performance reporting",
    ],
  },
  {
    name: "Strategic Partner",
    desc: "For brands and services looking for deep platform integration.",
    features: [
      "Everything in Brand Partner",
      "Platform integration & API access",
      "Co-marketing campaigns",
      "Dedicated partnership manager",
      "Custom analytics dashboards",
      "Priority placement in athlete discovery",
    ],
    highlighted: true,
  },
  {
    name: "Enterprise",
    desc: "For large organizations building long-term athlete ecosystem presence.",
    features: [
      "Everything in Strategic Partner",
      "White-label athlete experiences",
      "National program sponsorships",
      "Custom data and research reports",
      "Executive-level partnership team",
    ],
  },
];

export default function PartnersPage() {
  return (
    <div className="overflow-x-hidden">
      {/* ── Page Hero ─────────────────────────────────────── */}
      <section className="relative pt-44 pb-28 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-zinc-950" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/25 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-amber-600/[0.055] blur-[120px] pointer-events-none" />
        <div
          className="absolute inset-0 opacity-[0.015] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-6 h-px bg-amber-500/50" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
              For Partners &amp; Sponsors
            </span>
            <div className="w-6 h-px bg-amber-500/50" />
          </div>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-[0.9] tracking-tight text-white mb-7">
            Meet the next
            <br />
            generation of
            <br />
            <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-orange-400 bg-clip-text text-transparent">
              athlete brands.
            </span>
          </h1>
          <p className="text-zinc-400 text-base leading-relaxed mb-10 max-w-2xl mx-auto font-light">
            My Game My Story gives brands, media, and technology companies direct
            access to verified student athletes at the moment they&apos;re
            actively building their identity and influence.
          </p>
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-amber-400 px-10 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
          >
            Explore Partnership Options
          </Link>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Stats bar ────────────────────────────────────── */}
      <section className="relative border-y border-white/[0.05]">
        <div className="absolute inset-0 bg-zinc-900/30" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/15 to-transparent" />
        <div className="relative mx-auto max-w-7xl px-6 py-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {whyPartner.map(([value, label]) => (
            <div key={value} className="text-center">
              <div className="font-display text-3xl sm:text-4xl font-extrabold text-amber-400 mb-2 tracking-tight">
                {value}
              </div>
              <div className="text-xs text-zinc-600 leading-snug font-light uppercase tracking-wider">
                {label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Partner Types ────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Who We Work With
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Built for many kinds of partners.
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            {partnerTypes.map((p) => (
              <div
                key={p.title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-8 hover:border-amber-400/20 hover:bg-zinc-900 transition-all duration-300"
              >
                <div className="text-amber-400/70 text-xl mb-6">{p.icon}</div>
                <h3 className="font-display text-xl font-bold text-white mb-3 tracking-tight">{p.title}</h3>
                <p className="text-zinc-500 leading-relaxed text-sm font-light">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Partnership Tiers ────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Partnership Levels
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Choose your engagement.
            </h2>
            <p className="mt-4 text-zinc-500 max-w-lg mx-auto text-base font-light">
              All partnerships are custom-scoped. These tiers are starting points —
              we&apos;ll build the right structure together.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {partnershipTiers.map((tier) => (
              <div
                key={tier.name}
                className={`rounded-xl border p-8 flex flex-col ${
                  tier.highlighted
                    ? "border-amber-500/35 bg-gradient-to-b from-zinc-800/70 to-zinc-900/80"
                    : "border-white/[0.05] bg-zinc-900/60"
                }`}
              >
                {tier.highlighted && (
                  <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-amber-400 mb-4">
                    Most Common
                  </div>
                )}
                <h3 className="font-display text-xl font-extrabold text-white mb-2 tracking-tight">
                  {tier.name}
                </h3>
                <p className="text-zinc-600 text-sm mb-7 font-light">{tier.desc}</p>
                <ul className="flex flex-col gap-3 flex-1 mb-8">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <span className="text-amber-500/60 mt-0.5 shrink-0 text-xs">◆</span>
                      <span className="text-zinc-400 text-sm font-light">{f}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/contact"
                  className={`rounded-full px-6 py-3 text-sm font-semibold text-center transition-all ${
                    tier.highlighted
                      ? "bg-amber-400 text-zinc-950 hover:bg-amber-300 hover:scale-[1.02] shadow-lg shadow-amber-500/20"
                      : "border border-white/10 text-zinc-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
                >
                  Let&apos;s Talk
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Why Partner ──────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-20 items-center">
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Why It Works
              </span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold leading-tight tracking-tight text-white mb-7">
              Authentic access
              <br />
              at the right moment.
            </h2>
            <p className="text-zinc-400 text-base leading-relaxed mb-5 font-light">
              Athletes on My Game My Story are actively building their brand —
              which means they&apos;re receptive, ambitious, and highly engaged.
              They&apos;re not passive scrollers. They&apos;re future professionals.
            </p>
            <p className="text-zinc-400 text-base leading-relaxed font-light">
              Partnering here isn&apos;t advertising — it&apos;s relationship
              building at the start of careers that will shape sports culture for
              decades.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {[
              ["Verified Profiles", "Every athlete profile is school-verified. No bots, no fake accounts."],
              ["Brand Safety", "A moderated, professional environment that reflects well on partner brands."],
              ["Long-Term ROI", "Early brand relationships with athletes often last entire careers."],
            ].map(([title, text]) => (
              <div
                key={title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-6 hover:border-white/10 hover:bg-zinc-900 transition-all duration-300"
              >
                <h4 className="font-display text-white font-bold mb-2 text-sm tracking-tight">{title}</h4>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-display text-4xl font-extrabold text-white mb-4 tracking-tight">
            Let&apos;s build something together.
          </h2>
          <p className="text-zinc-500 text-base mb-10 font-light">
            Every partnership starts with a conversation. Tell us about your brand
            and goals — we&apos;ll find the right fit.
          </p>
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-amber-400 px-10 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
          >
            Start the Conversation
          </Link>
        </div>
      </section>
    </div>
  );
}
