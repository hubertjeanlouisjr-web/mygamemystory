import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "For Schools & Programs",
  description:
    "Empower your athletes, elevate your program brand, and recruit smarter with My Game My Story for schools.",
};

const benefits = [
  {
    icon: "◈",
    title: "Recruit Smarter",
    desc: "Access a verified pool of athlete profiles with real stats, verified highlights, and complete stories — filtered by sport, position, class year, and region.",
  },
  {
    icon: "◉",
    title: "Program Brand Equity",
    desc: "Your school gets a verified program page that showcases your culture, coaching staff, facilities, and alumni success. It recruits for you 24/7.",
  },
  {
    icon: "◆",
    title: "Parent & Athlete Trust",
    desc: "Families trust professional, verified platforms. Our moderated environment gives parents peace of mind and athletes a safe space to build their brand.",
  },
  {
    icon: "◇",
    title: "NIL Program Support",
    desc: "Help your athletes navigate NIL with tools built for the modern era. Track compliance-ready documentation and connect athletes with vetted sponsor opportunities.",
  },
  {
    icon: "◎",
    title: "Analytics for Coaches",
    desc: "See who's engaging with your program page, track recruit interest, and measure the reach of your athletes' profiles — all in one dashboard.",
  },
  {
    icon: "◌",
    title: "Simple Onboarding",
    desc: "Get your entire roster on the platform in a single session. We handle the tech. Your athletes handle their stories.",
  },
];

const tiers = [
  {
    name: "Starter",
    price: "Free",
    desc: "For small programs getting started.",
    features: [
      "Up to 25 athlete profiles",
      "Basic program page",
      "Verified school badge",
      "Email support",
    ],
  },
  {
    name: "Program",
    price: "Contact us",
    desc: "For full varsity programs.",
    features: [
      "Unlimited athlete profiles",
      "Premium program showcase page",
      "Recruiting analytics dashboard",
      "NIL tools & compliance exports",
      "Dedicated success manager",
      "Parent portal access",
    ],
    highlighted: true,
  },
  {
    name: "District",
    price: "Custom",
    desc: "For athletic departments managing multiple programs.",
    features: [
      "Everything in Program",
      "Multi-sport department dashboard",
      "District-wide reporting",
      "White-label options",
      "SSO integration",
      "Priority support SLA",
    ],
  },
];

const testimonials = [
  {
    quote:
      "I use it to find talent I would never have found otherwise. The profiles are professional, detailed, and tell a real story.",
    name: "Coach Sandra R.",
    detail: "Head Volleyball Coach · State University",
  },
  {
    quote:
      "Our program page does more recruiting work than any brochure we've ever made. Recruits already know our culture before we even call them.",
    name: "Coach David M.",
    detail: "Head Football Coach · Westfield High School",
  },
];

export default function SchoolsPage() {
  return (
    <div className="overflow-x-hidden">
      {/* ── Page Hero ─────────────────────────────────────── */}
      <section className="relative pt-44 pb-28 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-zinc-950" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-amber-500/25 to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-amber-600/[0.055] blur-[120px] pointer-events-none" />
        <div
          className="absolute inset-0 opacity-[0.015] pointer-events-none"
          style={{
            backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px",
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-6 h-px bg-amber-500/50" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
              For Schools &amp; Programs
            </span>
            <div className="w-6 h-px bg-amber-500/50" />
          </div>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-[0.9] tracking-tight text-white mb-7">
            Build the program
            <br />
            <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-orange-400 bg-clip-text text-transparent">
              recruits want to join.
            </span>
          </h1>
          <p className="text-zinc-400 text-base leading-relaxed mb-10 max-w-2xl mx-auto font-light">
            My Game My Story gives coaches the recruiting tools they need and
            programs the brand presence they deserve — all while putting athletes
            first.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/contact"
              className="rounded-full bg-amber-400 px-8 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
            >
              Partner with Us
            </Link>
            <a
              href="#tiers"
              className="rounded-full border border-white/10 px-8 py-4 text-sm font-medium text-zinc-400 hover:text-white hover:border-white/20 hover:bg-white/[0.04] transition-all"
            >
              See Plans
            </a>
          </div>
        </div>
        <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none" />
      </section>

      {/* ── Benefits ─────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Why Programs Choose Us
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Every stakeholder wins.
            </h2>
            <p className="mt-4 text-zinc-500 max-w-xl mx-auto text-base font-light">
              From head coaches to athletic directors to parents — My Game My Story
              is built for everyone in the athletics ecosystem.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b) => (
              <div
                key={b.title}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-8 hover:border-amber-400/20 hover:bg-zinc-900 transition-all duration-300"
              >
                <div className="text-amber-400/70 text-xl mb-6">{b.icon}</div>
                <h3 className="font-display text-base font-bold text-white mb-3 tracking-tight">{b.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed font-light">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ─────────────────────────────────── */}
      <section className="py-28 px-6 bg-zinc-900/20">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                From Coaches
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Coaches who rely on it.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-5 max-w-4xl mx-auto">
            {testimonials.map((t) => (
              <div
                key={t.name}
                className="rounded-xl border border-white/[0.05] bg-zinc-900/60 p-8 flex flex-col justify-between hover:border-white/10 hover:bg-zinc-900 transition-all duration-300"
              >
                <div>
                  <div className="font-display text-5xl font-extrabold text-amber-500/20 leading-none mb-5 select-none">
                    &ldquo;
                  </div>
                  <p className="text-zinc-300 text-sm leading-relaxed mb-8 font-light">
                    {t.quote}
                  </p>
                </div>
                <div>
                  <div className="w-6 h-px bg-amber-500/30 mb-4" />
                  <p className="font-display text-white font-bold text-sm tracking-tight">{t.name}</p>
                  <p className="text-zinc-600 text-xs mt-0.5">{t.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing Tiers ────────────────────────────────── */}
      <section id="tiers" className="py-28 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-18">
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="w-6 h-px bg-amber-500/50" />
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-amber-400">
                Plans
              </span>
              <div className="w-6 h-px bg-amber-500/50" />
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              Find your fit.
            </h2>
            <p className="mt-4 text-zinc-500 max-w-lg mx-auto text-base font-light">
              From single-sport programs to full athletic departments — we scale
              with you.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`rounded-xl border p-8 flex flex-col ${
                  tier.highlighted
                    ? "border-amber-500/35 bg-gradient-to-b from-zinc-800/70 to-zinc-900/80"
                    : "border-white/[0.05] bg-zinc-900/60"
                }`}
              >
                {tier.highlighted && (
                  <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-amber-400 mb-4">
                    Most Popular
                  </div>
                )}
                <h3 className="font-display text-xl font-extrabold text-white mb-1 tracking-tight">
                  {tier.name}
                </h3>
                <p className="font-display text-2xl font-extrabold text-amber-400 mb-2">
                  {tier.price}
                </p>
                <p className="text-zinc-600 text-sm mb-7 font-light">{tier.desc}</p>
                <ul className="flex flex-col gap-3 flex-1 mb-8">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <span className="text-amber-500/60 mt-0.5 shrink-0 text-xs">◆</span>
                      <span className="text-zinc-400 text-sm font-light">{f}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  href="/contact"
                  className={`rounded-full px-6 py-3 text-sm font-semibold text-center transition-all ${
                    tier.highlighted
                      ? "bg-amber-400 text-zinc-950 hover:bg-amber-300 hover:scale-[1.02] shadow-lg shadow-amber-500/20"
                      : "border border-white/10 text-zinc-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="py-28 px-6">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-display text-4xl font-extrabold text-white mb-4 leading-tight tracking-tight">
            Ready to elevate your program?
          </h2>
          <p className="text-zinc-500 text-base mb-10 leading-relaxed font-light">
            Tell us about your program and we&apos;ll get you set up. Onboarding
            takes one session.
          </p>
          <Link
            href="/contact"
            className="inline-flex rounded-full bg-amber-400 px-10 py-4 text-sm font-bold tracking-wide text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.03] shadow-lg shadow-amber-500/20"
          >
            Partner with Us
          </Link>
        </div>
      </section>
    </div>
  );
}
