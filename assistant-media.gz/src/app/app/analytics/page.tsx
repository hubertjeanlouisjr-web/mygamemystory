import type { Metadata } from "next";
import { currentAthlete, mockAnalyticsData } from "@/lib/mock-data";
import { getDashboardAnalyticsAction } from "@/lib/actions/analytics";

export const metadata: Metadata = { title: "Analytics" };

function BarChart({ data }: { data: { week: string; views: number }[] }) {
  const max = Math.max(...data.map((d) => d.views));
  return (
    <div className="flex items-end gap-2 h-28" aria-label="Weekly profile views chart">
      {data.map((d) => {
        const pct = max > 0 ? (d.views / max) * 100 : 0;
        return (
          <div key={d.week} className="flex-1 flex flex-col items-center gap-1.5">
            <span className="text-[10px] font-semibold text-zinc-400">{d.views}</span>
            <div className="w-full rounded-t-sm bg-zinc-800 relative overflow-hidden" style={{ height: "72px" }}>
              <div
                className="absolute bottom-0 left-0 right-0 rounded-t-sm bg-gradient-to-t from-amber-600 to-amber-400 transition-all duration-700"
                style={{ height: `${pct}%` }}
              />
            </div>
            <span className="text-[9px] text-zinc-600 text-center leading-none">{d.week}</span>
          </div>
        );
      })}
    </div>
  );
}

export default async function AnalyticsPage() {
  // Attempt to load real analytics data from Supabase
  const realData = await getDashboardAnalyticsAction();
  const isDemo = !realData;

  // Merge real data with mock shape — demo mode keeps all mock values
  const mockA = currentAthlete.analytics;

  const analytics = {
    profileViews: isDemo ? mockA.profileViews : realData.profileViewsTotal,
    weeklyViews: isDemo ? mockA.weeklyViews : realData.profileViewsWeekly,
    coachViews: isDemo ? mockA.coachViews : realData.coachViews,
    searchImpressions: isDemo ? mockA.searchImpressions : realData.searchImpressions,
    viewsHistory: isDemo ? mockA.viewsHistory : realData.viewsHistory,
  };

  const topSearchTerms =
    isDemo || realData.topSearchTerms.length === 0
      ? mockAnalyticsData.topSearchTerms
      : realData.topSearchTerms;

  const schoolsViewing =
    isDemo || realData.schoolsViewing.length === 0
      ? mockAnalyticsData.schoolsViewing
      : realData.schoolsViewing;

  // Compute week-over-week delta for the weekly views card
  const hist = analytics.viewsHistory;
  const priorWeekViews = hist.length >= 2 ? hist[hist.length - 2].views : null;
  const weeklyDelta =
    !isDemo && priorWeekViews != null && priorWeekViews > 0
      ? `${analytics.weeklyViews >= priorWeekViews ? "+" : ""}${Math.round(
          ((analytics.weeklyViews - priorWeekViews) / priorWeekViews) * 100
        )}% vs prior week`
      : "+12% vs prior week";

  const overviewCards = [
    {
      label: "Profile Views",
      value: analytics.profileViews.toLocaleString(),
      sub: "All time",
      delta: `+${analytics.weeklyViews} this week`,
      positive: true,
    },
    {
      label: "Coach / Scout Views",
      value: analytics.coachViews.toString(),
      sub: "Verified programs",
      delta: isDemo ? "+5 this month" : "all time",
      positive: true,
    },
    {
      label: "Search Impressions",
      value: analytics.searchImpressions.toLocaleString(),
      sub: "Times found in search",
      delta: isDemo ? "+1,200 this month" : "all time",
      positive: true,
    },
    {
      label: "Weekly Views",
      value: analytics.weeklyViews.toString(),
      sub: "Last 7 days",
      delta: weeklyDelta,
      positive: true,
    },
  ];

  return (
    <div className="p-6 lg:p-8 space-y-8 max-w-5xl">

      {/* Demo mode notice */}
      {isDemo && (
        <div className="rounded-lg border border-amber-400/20 bg-amber-400/[0.05] px-4 py-3 text-[12px] text-amber-400/80">
          <span className="font-semibold">Demo mode</span> — connect Supabase to see your real analytics.
        </div>
      )}

      {/* Overview cards */}
      <div>
        <h2 className="font-display text-[11px] font-semibold uppercase tracking-widest text-zinc-600 mb-4">
          Overview
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {overviewCards.map((card) => (
            <div
              key={card.label}
              className="rounded-xl border border-white/[0.06] bg-zinc-900 p-5"
            >
              <p className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider">
                {card.label}
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-white tracking-tight">
                {card.value}
              </p>
              <p className="mt-0.5 text-[11px] text-zinc-600">{card.sub}</p>
              <p className={`mt-1 text-[11px] font-semibold ${card.positive ? "text-emerald-400" : "text-zinc-500"}`}>
                {card.delta}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Profile views chart */}
      <div className="rounded-xl border border-white/[0.06] bg-zinc-900 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-display text-[13px] font-bold text-white">Profile Views</h3>
            <p className="mt-0.5 text-[11px] text-zinc-500">Last 6 weeks</p>
          </div>
          <div className="text-right">
            <p className="font-display text-xl font-bold text-amber-400">
              {analytics.viewsHistory.reduce((s, d) => s + d.views, 0).toLocaleString()}
            </p>
            <p className="text-[10px] text-zinc-600">total in period</p>
          </div>
        </div>
        <BarChart data={analytics.viewsHistory} />
      </div>

      {/* Two-column: search terms + schools */}
      <div className="grid lg:grid-cols-2 gap-6">

        {/* Top search terms */}
        <div className="rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06]">
            <h3 className="font-display text-[13px] font-bold text-white">How People Find You</h3>
            <p className="mt-0.5 text-[11px] text-zinc-500">Top search queries</p>
          </div>
          {topSearchTerms.length > 0 ? (
            <ul className="divide-y divide-white/[0.04]">
              {topSearchTerms.map((term, i) => (
                <li key={i} className="flex items-center gap-4 px-5 py-3.5">
                  <span className="font-display text-[12px] font-bold text-zinc-700 w-5 shrink-0">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <p className="text-[13px] text-zinc-300 flex-1">{term}</p>
                  <span className="text-[10px] text-zinc-600 shrink-0">
                    {isDemo ? ([47, 32, 28, 19, 14][i] ?? 10) : "—"} searches
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-6 text-[12px] text-zinc-600">
              No search data yet. Share your profile link to start appearing in searches.
            </p>
          )}
        </div>

        {/* Schools viewing */}
        <div className="rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/[0.06]">
            <h3 className="font-display text-[13px] font-bold text-white">Programs Watching</h3>
            <p className="mt-0.5 text-[11px] text-zinc-500">
              {schoolsViewing.length} programs in the last 30 days
            </p>
          </div>
          {schoolsViewing.length > 0 ? (
            <ul className="divide-y divide-white/[0.04]">
              {schoolsViewing.map((school, i) => (
                <li key={i} className="flex items-center justify-between px-5 py-3.5">
                  <div className="flex items-center gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-[10px] font-bold text-zinc-500 font-display">
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <div>
                      <p className="text-[13px] text-zinc-300">{school.name}</p>
                      <p className="text-[10px] text-zinc-600">Last seen {school.lastSeen}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-[14px] font-bold text-amber-400">
                      {school.views}×
                    </p>
                    <p className="text-[10px] text-zinc-600">views</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-6 text-[12px] text-zinc-600">
              No program data yet. Views with school context will appear here.
            </p>
          )}
        </div>
      </div>

      {/* Visibility tips */}
      <div className="rounded-xl border border-white/[0.06] bg-zinc-900/60 px-6 py-5">
        <h3 className="font-display text-[13px] font-bold text-white mb-3">
          Grow Your Visibility
        </h3>
        <ul className="grid sm:grid-cols-2 gap-2">
          {[
            "Complete your profile to 100% — fully complete profiles rank higher.",
            "Add your Hudl link — coaches click directly to film.",
            "Share your profile on Instagram with your class year and sport in the caption.",
            "Upload a new highlight clip at least once a month.",
          ].map((tip, i) => (
            <li key={i} className="flex gap-2.5 text-[12px] text-zinc-500">
              <span className="text-amber-400/60 shrink-0 mt-0.5">◆</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
