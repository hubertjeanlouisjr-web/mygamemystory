import type { Metadata } from "next";
import AppShell from "@/components/app/AppShell";
import SessionGuard from "@/components/app/SessionGuard";

export const metadata: Metadata = {
  title: {
    default: "Athlete Hub",
    template: "%s | My Game My Story",
  },
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <SessionGuard>
      <AppShell>{children}</AppShell>
    </SessionGuard>
  );
}
