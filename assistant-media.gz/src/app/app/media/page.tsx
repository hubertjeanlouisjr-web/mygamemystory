/**
 * /app/media — Highlight Vault page
 *
 * Server component: loads media from Supabase (when configured) and passes
 * initial data to the MediaVault client component for interactive CRUD.
 *
 * Data strategy:
 *  - Supabase configured → loads real AthleteMedia rows from the DB.
 *  - Demo mode (no Supabase) → converts mock highlights to AthleteMedia
 *    shape so the UI renders with sample data in read-only mode.
 */

import type { Metadata } from "next";
import { isSupabaseConfiguredServer } from "@/lib/supabase/server";
import { getAthleteMediaAction } from "@/lib/actions/media";
import { currentAthlete } from "@/lib/mock-data";
import type { AthleteMedia } from "@/lib/supabase/types";
import MediaVault from "@/components/app/MediaVault";

export const metadata: Metadata = { title: "Media & Highlights" };

/** Parse "m:ss" duration strings from mock data → seconds. */
function parseMockDuration(duration?: string): number | null {
  if (!duration) return null;
  const parts = duration.split(":");
  if (parts.length !== 2) return null;
  const m = parseInt(parts[0], 10);
  const s = parseInt(parts[1], 10);
  if (isNaN(m) || isNaN(s)) return null;
  return m * 60 + s;
}

/** Convert mock Highlight objects to AthleteMedia shape for demo rendering. */
function mockToAthleteMedia(highlights: typeof currentAthlete.highlights): AthleteMedia[] {
  return highlights.map((h) => ({
    id: h.id,
    user_id: "demo",
    type: h.type === "video" ? "video" : "image",
    title: h.title,
    description: h.description ?? null,
    storage_path: `demo/${h.id}`,
    thumbnail_url: null,
    duration_seconds: parseMockDuration(h.duration),
    view_count: h.views,
    featured: true,
    created_at: h.date,
    updated_at: h.date,
  }));
}

export default async function MediaPage() {
  const isDemo = !isSupabaseConfiguredServer();

  let initialMedia: AthleteMedia[];

  if (isDemo) {
    // Demo mode: show sample highlights in read-only vault
    initialMedia = mockToAthleteMedia(currentAthlete.highlights);
  } else {
    // Supabase mode: load real media from DB
    initialMedia = await getAthleteMediaAction();
  }

  return <MediaVault initialMedia={initialMedia} isDemo={isDemo} />;
}
