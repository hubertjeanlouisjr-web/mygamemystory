import type { Metadata } from "next";
import Link from "next/link";
import { currentAthlete, mockAnalyticsData } from "@/lib/mock-data";

export const metadata: Metadata = { title: "Dashboard" };

const recentActivity = [
  { label: "Coach from University of Georgia viewed your profile", time: "2 hours ago", accent: true },
  { label: "Your highlight reel passed 12,000 views", time: "5 hours ago", accent: false },
  { label: "Coach from Auburn University viewed your profile", time: "2 days ago", accent: true },
  { label: "Your profile appeared in 47 searches this week", time: "3 days ago", accent: false },
  { label: "Florida State viewed your profile", time: "1 week ago", accent: true },
];

export default function DashboardPage() {
  const a = currentAthlete;

  const statCards = [
    {
      label: "Profile Views",
      value: a.analytics.profileViews.toLocaleString(),
      sub: `+${a.analytics.weeklyViews} this week`,
      positive: true,
      href: "/app/analytics",
    },
    {
      label: "Coach Views",
      value: a.analytics.coachViews.toString(),
      sub: "from D1 & D2 programs",
      positive: true,
      href: "/app/analytics",
    },
    {
      label: "Highlight Views",
      value: a.highlights
        .reduce((sum, h) => sum + h.views, 0)
        .toLocaleString(),
      sub: `${a.highlights.length} clips uploaded`,
      positive: true,
      href: "/app/media",
    },
    {
      label: "Search Impressions",
      value: a.analytics.searchImpressions.toLocaleString(),
      sub: "times found in search",
      positive: true,
      href: "/app/analytics",
    },
  ];

  return (
    <div className="p-6 lg:p-8 space-y-8 max-w-5xl">

      {/* Profile strength banner */}
      {a.profileStrength < 100 && (
        <div className="relative overflow-hidden rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] p-6">
          <div className="absolute inset-y-0 right-0 w-64 bg-gradient-to-l from-amber-400/[0.06] to-transparent" />
          <div className="relative flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-amber-400/70 mb-1">
                Profile Strength
              </p>
              <h2 className="font-display text-xl font-bold text-white">
                You&apos;re {a.profileStrength}% complete
              </h2>
              <p className="mt-1 text-sm text-zinc-400">
                Profiles with 100% completion get 3× more coach views. Add your story and social links to close the gap.
              </p>
              {/* Progress bar */}
              <div className="mt-3 h-1.5 w-full max-w-xs rounded-full bg-white/[0.06]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all"
                  style={{ width: `${a.profileStrength}%` }}
                />
              </div>
            </div>
            <Link
              href="/app/profile"
              className="shrink-0 inline-flex rounded-full bg-amber-400 px-5 py-2.5 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors"
            >
              Complete Profile →
            </Link>
          </div>
        </div>
      )}

      {/* Stats grid */}
      <div>
        <h2 className="font-display text-[11px] font-semibold uppercase tracking-widest text-zinc-600 mb-4">
          Performance Overview
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {statCards.map((card) => (
            <Link
              key={card.label}
              href={card.href}
              className="group rounded-xl border border-white/[0.06] bg-zinc-900 p-5 hover:border-white/[0.1] hover:bg-zinc-800/60 transition-all duration-200"
            >
              <p className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider">
                {card.label}
              </p>
              <p className="mt-2 font-display text-3xl font-bold text-white tracking-tight">
                {card.value}
              </p>
              <p className={`mt-1 text-[11px] ${card.positive ? "text-emerald-400" : "text-zinc-500"}`}>
                {card.sub}
              </p>
            </Link>
          ))}
        </div>
      </div>

      {/* Two-column: recent activity + schools viewing */}
      <div className="grid lg:grid-cols-2 gap-6">

        {/* Recent activity */}
        <div className="rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
            <h2 className="font-display text-[13px] font-bold text-white">Recent Activity</h2>
            <Link href="/app/analytics" className="text-[11px] text-zinc-500 hover:text-amber-400 transition-colors">
              View all →
            </Link>
          </div>
          <ul className="divide-y divide-white/[0.04]">
            {recentActivity.map((item, i) => (
              <li key={i} className="flex items-start gap-3 px-5 py-3.5">
                <span
                  className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${item.accent ? "bg-amber-400" : "bg-zinc-700"}`}
                />
                <div>
                  <p className="text-[13px] text-zinc-300 leading-snug">{item.label}</p>
                  <p className="mt-0.5 text-[11px] text-zinc-600">{item.time}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Schools viewing */}
        <div className="rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
            <h2 className="font-display text-[13px] font-bold text-white">Programs Watching</h2>
            <span className="text-[11px] text-zinc-600">Last 30 days</span>
          </div>
          <ul className="divide-y divide-white/[0.04]">
            {mockAnalyticsData.schoolsViewing.map((school, i) => (
              <li key={i} className="flex items-center justify-between px-5 py-3.5">
                <div className="flex items-center gap-3">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-zinc-800 text-[10px] font-bold text-zinc-500 font-display">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <p className="text-[13px] text-zinc-300">{school.name}</p>
                </div>
                <div className="text-right">
                  <p className="text-[13px] font-semibold text-amber-400">{school.views}×</p>
                  <p className="text-[10px] text-zinc-600">{school.lastSeen}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="font-display text-[11px] font-semibold uppercase tracking-widest text-zinc-600 mb-4">
          Quick Actions
        </h2>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            {
              title: "Build Your Story",
              desc: "Add your bio, stats, and personal narrative.",
              href: "/app/profile",
              cta: "Edit Profile",
            },
            {
              title: "Upload Highlights",
              desc: "Add game film and standout clips to your vault.",
              href: "/app/media",
              cta: "Go to Media",
            },
            {
              title: "View Public Profile",
              desc: "See exactly what coaches and scouts see.",
              href: "/athlete/marcus-thompson",
              cta: "Preview →",
            },
          ].map((action) => (
            <div
              key={action.title}
              className="rounded-xl border border-white/[0.06] bg-zinc-900 p-5 flex flex-col gap-3"
            >
              <div>
                <h3 className="font-display text-[14px] font-bold text-white">{action.title}</h3>
                <p className="mt-1 text-[12px] text-zinc-500">{action.desc}</p>
              </div>
              <Link
                href={action.href}
                className="mt-auto inline-flex self-start rounded-full border border-white/[0.1] px-4 py-1.5 text-[12px] font-medium text-zinc-300 hover:border-amber-400/40 hover:text-amber-400 transition-all"
              >
                {action.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
