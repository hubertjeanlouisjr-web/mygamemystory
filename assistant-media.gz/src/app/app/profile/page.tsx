/**
 * /app/profile — Athlete profile editor page.
 *
 * This is a Server Component. It:
 *  1. Checks whether Supabase is configured.
 *  2. If yes: loads the athlete's profile, social links, and stats from the DB.
 *  3. Renders the client-side <ProfileEditor> with the loaded data.
 *
 * When Supabase is not configured the editor renders in "demo" mode — fully
 * functional UI seeded with mock data, but saves are no-ops.
 */

import type { Metadata } from "next";
import { isSupabaseConfiguredServer } from "@/lib/supabase/server";
import {
  getAthleteProfileAction,
  getSocialLinksAction,
  getAthleteStatsAction,
} from "@/lib/actions/profile";
import ProfileEditor from "@/components/app/ProfileEditor";

export const metadata: Metadata = { title: "My Profile" };

export default async function ProfilePage() {
  const isConfigured = isSupabaseConfiguredServer();

  if (!isConfigured) {
    // Demo mode — no DB, seed with mock data
    return <ProfileEditor mode="demo" />;
  }

  // Load all profile data in parallel
  const [profile, links, stats] = await Promise.all([
    getAthleteProfileAction(),
    getSocialLinksAction(),
    getAthleteStatsAction(),
  ]);

  return (
    <ProfileEditor
      mode="supabase"
      initialProfile={profile}
      initialLinks={links}
      initialStats={stats}
      profileSlug={profile?.slug ?? null}
    />
  );
}
