/**
 * Supabase Auth Callback Route Handler
 *
 * Handles the redirect after:
 *  - Email confirmation (signup verification)
 *  - OAuth provider callbacks (if social login is added)
 *
 * Supabase redirects back to /auth/callback?code=<code> after the user
 * clicks the confirmation link in their email. This handler exchanges the
 * code for a session and sets the auth cookies.
 *
 * Setup in Supabase Dashboard:
 *   Authentication → URL Configuration → Redirect URLs
 *   Add: http://localhost:3000/auth/callback  (dev)
 *   Add: https://yourdomain.com/auth/callback  (prod)
 */

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfiguredServer } from "@/lib/supabase/server";

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/onboarding";

  if (!isSupabaseConfiguredServer()) {
    // Supabase not wired up — redirect to signup with a notice
    return NextResponse.redirect(`${origin}/signup`);
  }

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      // Session is set; redirect to onboarding (or wherever `next` points)
      const redirectUrl = next.startsWith("/") ? `${origin}${next}` : next;
      return NextResponse.redirect(redirectUrl);
    }

    console.error("[auth/callback] exchangeCodeForSession error:", error);
  }

  // Exchange failed or no code present — send to login with error hint
  return NextResponse.redirect(`${origin}/login?error=auth_callback_failed`);
}
