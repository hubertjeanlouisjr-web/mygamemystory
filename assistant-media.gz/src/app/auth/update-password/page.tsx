"use client";

/**
 * Update Password page
 *
 * The user lands here after clicking a password-reset link in their email.
 * Supabase has already verified the token and set a recovery session by the
 * time this page loads.
 */

import { useState } from "react";
import { useRouter } from "next/navigation";
import AuthCard from "@/components/auth/AuthCard";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-4 py-3 text-sm text-white placeholder-zinc-600 transition-colors focus:border-amber-400/50 focus:bg-zinc-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/20";

const labelClass =
  "block text-[11px] font-semibold uppercase tracking-wider text-zinc-500 mb-2";

export default function UpdatePasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "error" | "done">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) {
      setErrorMsg("Password must be at least 6 characters.");
      setStatus("error");
      return;
    }
    if (password !== confirm) {
      setErrorMsg("Passwords don't match.");
      setStatus("error");
      return;
    }

    setStatus("loading");
    setErrorMsg("");

    if (!isSupabaseConfigured) {
      // Mock mode — just redirect
      setTimeout(() => router.push("/login"), 800);
      return;
    }

    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ password });

    if (error) {
      setErrorMsg(error.message);
      setStatus("error");
      return;
    }

    setStatus("done");
    setTimeout(() => router.push("/app"), 1500);
  }

  if (status === "done") {
    return (
      <div className="w-full max-w-md text-center">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full border border-emerald-500/20 bg-emerald-500/[0.06]">
          <svg
            className="h-7 w-7 text-emerald-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.8}
            aria-hidden="true"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
        </div>
        <h1 className="font-display text-2xl font-bold text-white">Password updated</h1>
        <p className="mt-3 text-sm text-zinc-500">
          Taking you to your dashboard…
        </p>
      </div>
    );
  }

  return (
    <AuthCard
      eyebrow="Account security"
      title="Set a new password"
      subtitle="Choose a strong password you haven't used before."
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div>
          <label htmlFor="password" className={labelClass}>
            New password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Min. 6 characters"
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="confirm" className={labelClass}>
            Confirm password
          </label>
          <input
            id="confirm"
            type="password"
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Repeat password"
            className={inputClass}
          />
        </div>

        {status === "error" && (
          <p className="rounded-lg border border-red-500/20 bg-red-500/[0.06] px-4 py-2.5 text-[12px] text-red-400">
            {errorMsg}
          </p>
        )}

        <button
          type="submit"
          disabled={status === "loading" || !password || !confirm}
          className="w-full rounded-full bg-amber-400 py-3 text-[14px] font-bold text-zinc-950 transition-all hover:bg-amber-300 hover:scale-[1.02] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none"
        >
          {status === "loading" ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
              Updating…
            </span>
          ) : (
            "Update Password"
          )}
        </button>
      </form>
    </AuthCard>
  );
}
