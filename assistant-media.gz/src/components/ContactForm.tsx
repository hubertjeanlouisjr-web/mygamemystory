"use client";

import { useState } from "react";
import Link from "next/link";

type FormState = "idle" | "submitting" | "success";

const inquiryTypes = [
  { value: "athlete", label: "I'm an athlete" },
  { value: "school", label: "I represent a school or program" },
  { value: "partner", label: "I'm interested in a brand partnership" },
  { value: "media", label: "Media or press inquiry" },
  { value: "other", label: "Something else" },
];

export default function ContactForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    inquiryType: "",
    message: "",
  });
  const [status, setStatus] = useState<FormState>("idle");

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // Client-side only — wire to backend or form service (e.g. Formspree, Resend) when ready
    setStatus("submitting");
    setTimeout(() => {
      setStatus("success");
    }, 900);
  }

  if (status === "success") {
    return (
      <div className="rounded-3xl border border-amber-400/20 bg-gradient-to-b from-zinc-900 to-zinc-950 p-12 text-center">
        <div className="text-amber-400 text-5xl mb-6">◆</div>
        <h2 className="text-3xl font-black text-white mb-3">
          Message received.
        </h2>
        <p className="text-zinc-400 text-lg mb-8">
          We&apos;ll be in touch within 1–2 business days. If you&apos;re an
          athlete, check out your profile options while you wait.
        </p>
        <Link
          href="/athletes"
          className="inline-flex rounded-full bg-amber-400 px-8 py-3.5 text-sm font-bold text-zinc-950 hover:bg-amber-300 transition-all hover:scale-105"
        >
          Explore For Athletes
        </Link>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-3xl border border-white/5 bg-zinc-900 p-8 sm:p-10 space-y-6"
    >
      <h2 className="text-2xl font-black text-white">Send us a message</h2>

      <div className="grid sm:grid-cols-2 gap-5">
        <div>
          <label
            htmlFor="name"
            className="block text-xs font-semibold uppercase tracking-widest text-zinc-500 mb-2"
          >
            Name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            required
            value={form.name}
            onChange={handleChange}
            placeholder="Your name"
            className="w-full rounded-xl bg-zinc-800 border border-white/[0.08] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-400/50 focus:bg-zinc-700/50 transition-all"
          />
        </div>
        <div>
          <label
            htmlFor="email"
            className="block text-xs font-semibold uppercase tracking-widest text-zinc-500 mb-2"
          >
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            value={form.email}
            onChange={handleChange}
            placeholder="you@example.com"
            className="w-full rounded-xl bg-zinc-800 border border-white/[0.08] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-400/50 focus:bg-zinc-700/50 transition-all"
          />
        </div>
      </div>

      <div>
        <label
          htmlFor="inquiryType"
          className="block text-xs font-semibold uppercase tracking-widest text-zinc-500 mb-2"
        >
          I am...
        </label>
        <select
          id="inquiryType"
          name="inquiryType"
          required
          value={form.inquiryType}
          onChange={handleChange}
          className="w-full rounded-xl bg-zinc-800 border border-white/[0.08] px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-400/50 focus:bg-zinc-700/50 transition-all appearance-none"
        >
          <option value="" disabled>
            Select one...
          </option>
          {inquiryTypes.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label
          htmlFor="message"
          className="block text-xs font-semibold uppercase tracking-widest text-zinc-500 mb-2"
        >
          Message
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={5}
          value={form.message}
          onChange={handleChange}
          placeholder="Tell us what you need..."
          className="w-full rounded-xl bg-zinc-800 border border-white/[0.08] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-400/50 focus:bg-zinc-700/50 transition-all resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={status === "submitting"}
        className="w-full rounded-full bg-amber-400 py-4 text-sm font-bold text-zinc-950 hover:bg-amber-300 transition-all hover:scale-[1.02] shadow-lg shadow-amber-400/20 disabled:opacity-60 disabled:scale-100 disabled:cursor-not-allowed"
      >
        {status === "submitting" ? "Sending..." : "Send Message"}
      </button>

      <p className="text-xs text-zinc-600 text-center">
        We respond within 1–2 business days. No spam, ever.
      </p>
    </form>
  );
}
