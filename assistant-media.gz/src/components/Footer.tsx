import Link from "next/link";

const footerSections = [
  {
    heading: "Platform",
    links: [
      { label: "For Athletes", href: "/athletes" },
      { label: "For Schools", href: "/schools" },
      { label: "For Partners", href: "/partners" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Contact", href: "/contact" },
    ],
  },
  {
    heading: "Legal",
    links: [
      { label: "Privacy Policy", href: "#" },
      { label: "Terms of Service", href: "#" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/[0.05] bg-zinc-950 py-16 px-6">
      {/* Top framing line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-px bg-gradient-to-r from-transparent via-amber-500/20 to-transparent" />

      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-14">
          {/* Brand column */}
          <div className="md:col-span-1">
            <Link
              href="/"
              className="font-display text-[15px] font-bold tracking-tight text-white hover:opacity-85 transition-opacity"
            >
              My<span className="text-amber-400">Game</span>MyStory
            </Link>
            <p className="mt-4 text-sm text-zinc-600 leading-relaxed max-w-xs font-light">
              The platform where student athletes own their identity, control
              their narrative, and get discovered.
            </p>
            <div className="mt-5 flex items-center gap-2">
              <div className="w-3 h-px bg-amber-500/40" />
              <p className="text-[10px] text-zinc-700 uppercase tracking-[0.18em] font-medium">
                Free for Athletes · All Sports
              </p>
            </div>
          </div>

          {/* Link columns */}
          {footerSections.map((section) => (
            <div key={section.heading}>
              <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-zinc-700 mb-5">
                {section.heading}
              </p>
              <ul className="flex flex-col gap-3.5">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-zinc-600 hover:text-zinc-300 transition-colors font-light"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/[0.04] pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-zinc-700">
            &copy; 2026 My Game My Story. All rights reserved.
          </p>
          <p className="text-[11px] text-zinc-700 tracking-wide">
            Built for the next generation of athletes.
          </p>
        </div>
      </div>
    </footer>
  );
}
