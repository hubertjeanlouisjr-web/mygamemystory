"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";

const navLinks = [
  { label: "About", href: "/about" },
  { label: "For Athletes", href: "/athletes" },
  { label: "For Schools", href: "/schools" },
  { label: "For Partners", href: "/partners" },
  { label: "Contact", href: "/contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <nav className="fixed top-0 inset-x-0 z-50">
      {/* Top amber accent line */}
      <div className="h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />

      <div className="border-b border-white/[0.05] bg-zinc-950/88 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-6 flex h-[60px] items-center justify-between">
          {/* Logo */}
          <Link
            href="/"
            className="font-display text-[15px] font-bold tracking-tight text-white hover:opacity-85 transition-opacity"
          >
            My<span className="text-amber-400">Game</span>MyStory
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-7 text-[13px] text-zinc-500">
            {navLinks.map((link) => {
              const active = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`relative py-1.5 transition-colors hover:text-zinc-200 ${
                    active ? "text-white" : ""
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute -bottom-0.5 left-0 right-0 h-px bg-gradient-to-r from-amber-500/0 via-amber-400 to-amber-500/0 rounded-full" />
                  )}
                </Link>
              );
            })}
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/contact"
              className="hidden sm:inline-flex rounded-full bg-amber-400 px-5 py-2 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors"
            >
              Get Early Access
            </Link>
            {/* Mobile menu toggle */}
            <button
              className="md:hidden flex flex-col gap-1.5 p-1 text-zinc-500 hover:text-zinc-200 transition-colors"
              onClick={() => setOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              <span
                className={`block w-5 h-px bg-current transition-all origin-center ${open ? "rotate-45 translate-y-2" : ""}`}
              />
              <span
                className={`block w-5 h-px bg-current transition-all ${open ? "opacity-0" : ""}`}
              />
              <span
                className={`block w-5 h-px bg-current transition-all origin-center ${open ? "-rotate-45 -translate-y-2" : ""}`}
              />
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {open && (
          <div className="md:hidden border-t border-white/[0.05] bg-zinc-950/98 px-6 py-6 flex flex-col gap-5">
            {navLinks.map((link) => {
              const active = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-sm transition-colors ${
                    active ? "text-white font-medium" : "text-zinc-500"
                  } hover:text-zinc-200`}
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </Link>
              );
            })}
            <Link
              href="/contact"
              className="mt-1 inline-flex rounded-full bg-amber-400 px-5 py-2.5 text-sm font-semibold text-zinc-950 hover:bg-amber-300 transition-colors self-start"
              onClick={() => setOpen(false)}
            >
              Get Early Access
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
