"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: string;
}

function IconGrid() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <rect x="1" y="1" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9" />
      <rect x="9" y="1" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9" />
      <rect x="1" y="9" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9" />
      <rect x="9" y="9" width="6" height="6" rx="1.5" fill="currentColor" opacity="0.9" />
    </svg>
  );
}

function IconPerson() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <circle cx="8" cy="5" r="3" fill="currentColor" opacity="0.9" />
      <path d="M2 14c0-3.314 2.686-6 6-6s6 2.686 6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.9" />
    </svg>
  );
}

function IconPlay() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <rect x="1" y="2" width="14" height="12" rx="2.5" stroke="currentColor" strokeWidth="1.5" fill="none" opacity="0.9" />
      <path d="M6.5 5.5l4 2.5-4 2.5V5.5z" fill="currentColor" opacity="0.9" />
    </svg>
  );
}

function IconChart() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <rect x="1" y="9" width="3" height="6" rx="1" fill="currentColor" opacity="0.9" />
      <rect x="6" y="5" width="3" height="10" rx="1" fill="currentColor" opacity="0.9" />
      <rect x="11" y="1" width="3" height="14" rx="1" fill="currentColor" opacity="0.9" />
    </svg>
  );
}

function IconArrow() {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
      <path d="M2 11L11 2M11 2H5M11 2V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const navItems: NavItem[] = [
  { label: "Dashboard", href: "/app", icon: <IconGrid /> },
  { label: "My Profile", href: "/app/profile", icon: <IconPerson /> },
  { label: "Media & Highlights", href: "/app/media", icon: <IconPlay /> },
  { label: "Analytics", href: "/app/analytics", icon: <IconChart /> },
];

interface AppSidebarProps {
  open?: boolean;
  onClose?: () => void;
}

export default function AppSidebar({ open, onClose }: AppSidebarProps) {
  const pathname = usePathname();

  const isActive = (href: string) =>
    href === "/app" ? pathname === "/app" : pathname.startsWith(href);

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-zinc-950/80 backdrop-blur-sm md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed inset-y-0 left-0 z-40 flex w-60 flex-col bg-zinc-900 border-r border-white/[0.06]
          transition-transform duration-300 ease-in-out
          ${open ? "translate-x-0" : "-translate-x-full"}
          md:relative md:translate-x-0 md:z-auto
        `}
      >
        {/* Logo */}
        <div className="flex h-16 items-center border-b border-white/[0.06] px-5">
          <Link
            href="/"
            className="font-display text-[14px] font-bold tracking-tight text-white hover:opacity-80 transition-opacity"
            onClick={onClose}
          >
            My<span className="text-amber-400">Game</span>MyStory
          </Link>
          <div className="ml-2 h-1.5 w-1.5 rounded-full bg-amber-400/70" aria-hidden="true" />
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-5 px-3">
          <p className="mb-3 px-2 text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
            Athlete Hub
          </p>
          <ul className="space-y-0.5">
            {navItems.map((item) => {
              const active = isActive(item.href);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={onClose}
                    className={`
                      group flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-all duration-150
                      ${
                        active
                          ? "bg-amber-400/10 text-amber-400"
                          : "text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-200"
                      }
                    `}
                  >
                    <span
                      className={`transition-colors ${active ? "text-amber-400" : "text-zinc-600 group-hover:text-zinc-400"}`}
                    >
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                    {active && (
                      <span className="ml-auto h-1.5 w-1.5 rounded-full bg-amber-400" />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Bottom section */}
        <div className="border-t border-white/[0.06] p-3 space-y-0.5">
          <Link
            href="/athlete/marcus-thompson"
            onClick={onClose}
            className="flex items-center justify-between rounded-lg px-3 py-2.5 text-[12px] text-zinc-600 hover:bg-white/[0.04] hover:text-zinc-300 transition-all duration-150 group"
          >
            <span>View Public Profile</span>
            <span className="text-zinc-700 group-hover:text-zinc-400 transition-colors">
              <IconArrow />
            </span>
          </Link>

          {/* Athlete info */}
          <div className="flex items-center gap-3 rounded-lg px-3 py-3 mt-1">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-400/20 text-[12px] font-bold text-amber-400 font-display shrink-0">
              MT
            </div>
            <div className="min-w-0">
              <p className="truncate text-[12px] font-semibold text-zinc-300">Marcus Thompson</p>
              <p className="truncate text-[11px] text-zinc-600">Class of 2026 · WR</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
