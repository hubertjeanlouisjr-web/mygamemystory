"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

interface AppTopbarProps {
  onMenuClick: () => void;
}

const pageTitles: Record<string, { title: string; subtitle: string }> = {
  "/app": { title: "Dashboard", subtitle: "Welcome back, Marcus" },
  "/app/profile": { title: "Profile Builder", subtitle: "Control your narrative" },
  "/app/media": { title: "Media & Highlights", subtitle: "Your highlight vault" },
  "/app/analytics": { title: "Analytics", subtitle: "See who's watching" },
};

function IconMenu() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
      <path d="M2 4h14M2 9h14M2 14h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function IconBell() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M8 1a5 5 0 015 5v3l1.5 2H1.5L3 9V6a5 5 0 015-5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" fill="none" />
      <path d="M6.5 13a1.5 1.5 0 003 0" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export default function AppTopbar({ onMenuClick }: AppTopbarProps) {
  const pathname = usePathname();
  const page = pageTitles[pathname] ?? { title: "App", subtitle: "" };

  return (
    <header className="flex h-16 items-center justify-between border-b border-white/[0.06] bg-zinc-950/80 backdrop-blur-sm px-5 shrink-0">
      {/* Left: menu + title */}
      <div className="flex items-center gap-4">
        <button
          className="md:hidden text-zinc-500 hover:text-zinc-200 transition-colors p-1"
          onClick={onMenuClick}
          aria-label="Open navigation"
        >
          <IconMenu />
        </button>
        <div>
          <h1 className="font-display text-[15px] font-bold text-white leading-none">
            {page.title}
          </h1>
          {page.subtitle && (
            <p className="text-[11px] text-zinc-500 mt-0.5">{page.subtitle}</p>
          )}
        </div>
      </div>

      {/* Right: actions */}
      <div className="flex items-center gap-3">
        {/* Profile strength pill */}
        <Link
          href="/app/profile"
          className="hidden sm:flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-400/8 px-3 py-1.5 text-[11px] font-semibold text-amber-400 hover:bg-amber-400/15 transition-colors"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
          91% Profile Strength
        </Link>

        {/* Notification bell */}
        <button
          className="relative flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 hover:bg-white/[0.06] hover:text-zinc-200 transition-all"
          aria-label="Notifications"
        >
          <IconBell />
          <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-amber-400" />
        </button>

        {/* Avatar */}
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-400/20 text-[11px] font-bold text-amber-400 font-display">
          MT
        </div>
      </div>
    </header>
  );
}
