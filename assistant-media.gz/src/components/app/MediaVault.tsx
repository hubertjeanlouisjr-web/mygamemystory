"use client";

/**
 * MediaVault — interactive client component for the /app/media page.
 *
 * Responsibilities:
 *  - Display all of the athlete's media clips (vault + featured).
 *  - Upload new media: file selection → Supabase Storage upload → metadata insert.
 *  - Edit existing records (title, description, type, featured flag).
 *  - Delete records (with best-effort Storage file cleanup via server action).
 *  - Toggle the featured flag per clip.
 *  - Graceful demo-mode when Supabase is not configured.
 *  - Graceful storage-error handling when the "highlights" bucket isn't set up yet.
 *
 * Upload flow (when Supabase is configured):
 *  1. User picks a file and fills out the form.
 *  2. File is uploaded directly from the browser to Supabase Storage using
 *     the browser client (avoids routing large files through server functions).
 *  3. If the upload succeeds, the real storage_path is used.
 *  4. If the upload fails (bucket not configured, permissions error, etc.),
 *     a placeholder path is used and a warning is shown — the metadata record
 *     is still saved so the user doesn't lose their form data.
 *  5. insertAthleteMediaAction() saves the metadata row.
 */

import { useState, useRef } from "react";
import type { AthleteMedia } from "@/lib/supabase/types";
import { isSupabaseConfigured, createClient } from "@/lib/supabase/client";
import {
  insertAthleteMediaAction,
  updateAthleteMediaAction,
  deleteAthleteMediaAction,
  toggleMediaFeaturedAction,
} from "@/lib/actions/media";

// ── Icons ──────────────────────────────────────────────────────────────────

function PlayIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" aria-hidden>
      <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="1.5" />
      <path d="M8 7l6 3-6 3V7z" fill="currentColor" />
    </svg>
  );
}

function PhotoIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" aria-hidden>
      <rect x="2" y="4" width="16" height="12" rx="2" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <circle cx="7" cy="8.5" r="1.5" fill="currentColor" />
      <path d="M2 14l4.5-4 3 3 2.5-2.5L18 14" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  );
}

function UploadIcon({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 22 22" fill="none" aria-hidden>
      <path d="M11 14V3M11 3l-4 4M11 3l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M3 15v3a2 2 0 002 2h12a2 2 0 002-2v-3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function StarIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M7 1l1.6 3.5 3.8.5-2.7 2.7.6 3.8L7 9.8l-3.3 1.7.6-3.8L1.6 5l3.8-.5L7 1z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinejoin="round"
        fill={filled ? "currentColor" : "none"}
      />
    </svg>
  );
}

function PencilIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden>
      <path
        d="M9.5 1.5l2 2-7 7-2.5.5.5-2.5 7-7z"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden>
      <path d="M2 3.5h9M5 3.5V2.5h3v1M4 3.5l.5 7h4l.5-7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
      <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

// ── Helpers ────────────────────────────────────────────────────────────────

function formatViews(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return n.toString();
}

function formatDuration(seconds: number | null) {
  if (!seconds) return null;
  const m = Math.floor(seconds / 60);
  const s = String(seconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

// ── Types ──────────────────────────────────────────────────────────────────

interface UploadForm {
  title: string;
  type: "video" | "image";
  description: string;
  featured: boolean;
  file: File | null;
}

const EMPTY_FORM: UploadForm = {
  title: "",
  type: "video",
  description: "",
  featured: false,
  file: null,
};

export interface MediaVaultProps {
  initialMedia: AthleteMedia[];
  isDemo: boolean;
}

// ── Sub-component: MediaCard ───────────────────────────────────────────────

function MediaCard({
  item,
  isDemo,
  deleting,
  onEdit,
  onDelete,
  onToggleFeatured,
}: {
  item: AthleteMedia;
  isDemo: boolean;
  deleting: boolean;
  onEdit: () => void;
  onDelete: () => void;
  onToggleFeatured: () => void;
}) {
  return (
    <div className="group relative flex flex-col rounded-xl border border-white/[0.06] bg-zinc-900 overflow-hidden hover:border-white/[0.12] transition-all duration-200">
      {/* Thumbnail area */}
      <div className="relative aspect-video bg-zinc-800 overflow-hidden">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
            backgroundSize: "24px 24px",
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-16 w-16 rounded-full bg-amber-400/10 flex items-center justify-center text-zinc-500 group-hover:text-amber-400 transition-colors">
            {item.type === "video" ? <PlayIcon /> : <PhotoIcon />}
          </div>
        </div>

        {/* Duration badge */}
        {item.duration_seconds != null && (
          <span className="absolute bottom-2 right-2 rounded-md bg-zinc-950/80 px-1.5 py-0.5 text-[10px] font-mono text-zinc-300">
            {formatDuration(item.duration_seconds)}
          </span>
        )}

        {/* Type badge */}
        <span
          className={`absolute top-2 left-2 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
            item.type === "video"
              ? "bg-amber-400/20 text-amber-400"
              : "bg-zinc-700/80 text-zinc-400"
          }`}
        >
          {item.type === "video" ? "Video" : "Photo"}
        </span>

        {/* Action buttons — visible on hover (hidden in demo) */}
        {!isDemo && (
          <div className="absolute top-2 right-2 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={onToggleFeatured}
              title={item.featured ? "Remove from public profile" : "Feature on public profile"}
              className={`flex h-7 w-7 items-center justify-center rounded-full border transition-colors ${
                item.featured
                  ? "border-amber-400/40 bg-amber-400/20 text-amber-400"
                  : "border-white/10 bg-zinc-900/80 text-zinc-500 hover:text-amber-400 hover:border-amber-400/30"
              }`}
            >
              <StarIcon filled={item.featured} />
            </button>
            <button
              onClick={onEdit}
              title="Edit clip"
              className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 bg-zinc-900/80 text-zinc-500 hover:text-white hover:border-white/20 transition-colors"
            >
              <PencilIcon />
            </button>
            <button
              onClick={onDelete}
              disabled={deleting}
              title="Delete clip"
              className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 bg-zinc-900/80 text-zinc-500 hover:text-red-400 hover:border-red-400/30 transition-colors disabled:opacity-50"
            >
              {deleting ? (
                <span className="h-3 w-3 animate-spin rounded-full border border-white/20 border-t-red-400" />
              ) : (
                <TrashIcon />
              )}
            </button>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex flex-col gap-1 p-4">
        <div className="flex items-start justify-between gap-2">
          <h4 className="font-display text-[13px] font-bold text-white leading-snug">
            {item.title}
          </h4>
          {item.featured && (
            <span className="shrink-0 rounded-full bg-amber-400/10 border border-amber-400/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-amber-400/80">
              Featured
            </span>
          )}
        </div>
        {item.description && (
          <p className="text-[11px] text-zinc-500 line-clamp-2">{item.description}</p>
        )}
        <div className="mt-2 flex items-center justify-between">
          <span className="text-[11px] text-zinc-600">
            {new Date(item.created_at).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </span>
          <span className="text-[11px] font-semibold text-amber-400">
            {formatViews(item.view_count)} views
          </span>
        </div>
      </div>
    </div>
  );
}

// ── Sub-component: UploadModal ─────────────────────────────────────────────

function UploadModal({
  form,
  setForm,
  editingId,
  uploading,
  uploadWarning,
  fileRef,
  onClose,
  onSubmit,
}: {
  form: UploadForm;
  setForm: React.Dispatch<React.SetStateAction<UploadForm>>;
  editingId: string | null;
  uploading: boolean;
  uploadWarning: string | null;
  fileRef: React.RefObject<HTMLInputElement | null>;
  onClose: () => void;
  onSubmit: () => void;
}) {
  const isEditing = editingId !== null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-sm" />

      {/* Sheet / Dialog */}
      <div className="relative w-full max-w-lg rounded-2xl border border-white/[0.08] bg-zinc-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/[0.06] px-6 py-4">
          <h2 className="font-display text-[15px] font-bold text-white">
            {isEditing ? "Edit Clip" : "Upload Highlight"}
          </h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full text-zinc-500 hover:text-white hover:bg-white/[0.06] transition-colors"
          >
            <XIcon />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-4">

          {/* Upload warning */}
          {uploadWarning && (
            <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.05] px-4 py-3">
              <p className="text-[12px] font-semibold text-amber-400 mb-0.5">File not uploaded</p>
              <p className="text-[11px] text-zinc-400 leading-relaxed">{uploadWarning}</p>
            </div>
          )}

          {/* File picker (new clips only) */}
          {!isEditing && (
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-widest text-zinc-500 mb-2">
                File <span className="normal-case font-normal text-zinc-600">(video or photo)</span>
              </label>
              <div
                className="relative flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-white/[0.08] bg-zinc-800/50 py-8 cursor-pointer hover:border-amber-400/30 hover:bg-amber-400/[0.03] transition-all group"
                onClick={() => fileRef.current?.click()}
              >
                <div className="text-zinc-600 group-hover:text-amber-400 transition-colors">
                  <UploadIcon size={28} />
                </div>
                {form.file ? (
                  <div className="text-center">
                    <p className="text-[13px] font-medium text-white">{form.file.name}</p>
                    <p className="text-[11px] text-zinc-500">
                      {(form.file.size / (1024 * 1024)).toFixed(1)} MB
                    </p>
                  </div>
                ) : (
                  <div className="text-center">
                    <p className="text-[13px] font-medium text-zinc-500 group-hover:text-zinc-300 transition-colors">
                      Click to select a file
                    </p>
                    <p className="text-[11px] text-zinc-700">MP4, MOV, JPG, PNG — up to 500 MB</p>
                  </div>
                )}
                <input
                  ref={fileRef}
                  type="file"
                  accept="video/mp4,video/quicktime,video/mpeg,video/webm,image/jpeg,image/png,image/gif,image/webp"
                  className="sr-only"
                  onChange={(e) => {
                    const file = e.target.files?.[0] ?? null;
                    setForm((f) => ({ ...f, file }));
                    if (file) {
                      const isVideo = file.type.startsWith("video/");
                      setForm((f) => ({
                        ...f,
                        file,
                        type: isVideo ? "video" : "image",
                        title: f.title || file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " "),
                      }));
                    }
                  }}
                />
              </div>
              {!isSupabaseConfigured && (
                <p className="mt-2 text-[11px] text-zinc-600">
                  Storage upload requires a configured Supabase project. Metadata will be saved without the file.
                </p>
              )}
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-widest text-zinc-500 mb-2">
              Title <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              placeholder="e.g. Season Reel 2025"
              maxLength={120}
              className="w-full rounded-lg border border-white/[0.08] bg-zinc-800 px-3 py-2.5 text-[13px] text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-400/40 focus:ring-1 focus:ring-amber-400/20"
            />
          </div>

          {/* Type */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-widest text-zinc-500 mb-2">
              Type
            </label>
            <div className="flex gap-2">
              {(["video", "image"] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, type: t }))}
                  className={`flex-1 rounded-lg border py-2 text-[12px] font-semibold transition-colors ${
                    form.type === t
                      ? "border-amber-400/40 bg-amber-400/10 text-amber-400"
                      : "border-white/[0.08] bg-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-white/[0.14]"
                  }`}
                >
                  {t === "video" ? "Video" : "Photo"}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-[11px] font-semibold uppercase tracking-widest text-zinc-500 mb-2">
              Description <span className="normal-case font-normal text-zinc-600">(optional)</span>
            </label>
            <textarea
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              placeholder="e.g. First game of the season vs. Lincoln High — 4 catches, 82 yards"
              rows={3}
              maxLength={400}
              className="w-full resize-none rounded-lg border border-white/[0.08] bg-zinc-800 px-3 py-2.5 text-[13px] text-white placeholder:text-zinc-600 focus:outline-none focus:border-amber-400/40 focus:ring-1 focus:ring-amber-400/20"
            />
          </div>

          {/* Featured toggle */}
          <div className="flex items-start justify-between gap-4 rounded-xl border border-white/[0.06] bg-zinc-800/60 px-4 py-3">
            <div>
              <p className="text-[13px] font-semibold text-white">Feature on public profile</p>
              <p className="mt-0.5 text-[11px] text-zinc-500">
                Featured clips are visible on your /athlete/[slug] page.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, featured: !f.featured }))}
              className={`relative mt-0.5 h-6 w-10 shrink-0 rounded-full transition-colors ${
                form.featured ? "bg-amber-400" : "bg-zinc-700"
              }`}
            >
              <span
                className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${
                  form.featured ? "translate-x-5" : "translate-x-1"
                }`}
              />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 border-t border-white/[0.06] px-6 py-4">
          <button
            onClick={onClose}
            className="rounded-full border border-white/[0.08] px-5 py-2 text-[13px] font-medium text-zinc-400 hover:text-white hover:border-white/[0.14] transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onSubmit}
            disabled={uploading || !form.title.trim()}
            className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-6 py-2 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading && (
              <span className="h-3.5 w-3.5 animate-spin rounded-full border border-zinc-900/30 border-t-zinc-900" />
            )}
            {uploading
              ? isEditing
                ? "Saving…"
                : "Uploading…"
              : isEditing
              ? "Save Changes"
              : "Add to Vault"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────

export default function MediaVault({ initialMedia, isDemo }: MediaVaultProps) {
  const [media, setMedia] = useState<AthleteMedia[]>(initialMedia);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [uploadWarning, setUploadWarning] = useState<string | null>(null);
  const [form, setForm] = useState<UploadForm>(EMPTY_FORM);
  const fileRef = useRef<HTMLInputElement | null>(null);

  function showToast(msg: string, ok: boolean) {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 4000);
  }

  function openUploadModal() {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setUploadWarning(null);
    setShowModal(true);
  }

  function openEditModal(item: AthleteMedia) {
    setForm({
      title: item.title,
      type: item.type,
      description: item.description ?? "",
      featured: item.featured,
      file: null,
    });
    setEditingId(item.id);
    setUploadWarning(null);
    setShowModal(true);
  }

  function closeModal() {
    setShowModal(false);
    setEditingId(null);
    setUploadWarning(null);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function handleSubmit() {
    if (!form.title.trim()) return;

    setUploading(true);
    setUploadWarning(null);

    if (editingId) {
      // ── Edit existing record ─────────────────────────────────────────────
      const result = await updateAthleteMediaAction(editingId, {
        title: form.title,
        description: form.description || null,
        featured: form.featured,
        type: form.type,
      });

      setUploading(false);

      if (result.ok) {
        setMedia((prev) =>
          prev.map((m) =>
            m.id === editingId
              ? {
                  ...m,
                  title: form.title,
                  description: form.description || null,
                  featured: form.featured,
                  type: form.type,
                }
              : m
          )
        );
        showToast("Clip updated.", true);
        closeModal();
      } else {
        showToast(result.error ?? "Update failed.", false);
      }
      return;
    }

    // ── New upload ───────────────────────────────────────────────────────────

    // Derive a placeholder path used when storage upload is skipped or fails.
    // Format: pending/{sanitized-title}-{timestamp}
    const sanitized = form.title.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-");
    let storagePath = `pending/${sanitized}-${Date.now()}`;
    let storageWarning: string | null = null;

    if (isSupabaseConfigured && form.file) {
      // Upload file directly from browser to Supabase Storage
      try {
        const supabase = createClient();
        const {
          data: { session },
        } = await supabase.auth.getSession();

        const userId = session?.user?.id;
        if (userId) {
          const safeName = form.file.name.replace(/\s+/g, "_");
          const path = `${userId}/${Date.now()}-${safeName}`;

          const { error: uploadError } = await supabase.storage
            .from("highlights")
            .upload(path, form.file, { upsert: false });

          if (uploadError) {
            storageWarning =
              `File not uploaded: ${uploadError.message}. ` +
              `The clip was saved to your vault without a file. ` +
              `Create the "highlights" Storage bucket in your Supabase dashboard ` +
              `and apply the policies in supabase/migrations/20260418000002_rls_policies.sql to enable uploads.`;
          } else {
            storagePath = path;
          }
        } else {
          storageWarning =
            "Session not found — file was not uploaded. Please refresh and try again.";
        }
      } catch {
        storageWarning =
          `Storage upload encountered an error. The clip metadata was saved ` +
          `without a file. Configure the "highlights" Supabase Storage bucket to enable uploads.`;
      }
    } else if (isSupabaseConfigured && !form.file) {
      // Metadata-only save (no file selected)
      storageWarning =
        "No file selected. Clip saved with metadata only. You can attach a file later by re-uploading.";
    }

    // Save metadata record
    const result = await insertAthleteMediaAction({
      type: form.type,
      title: form.title,
      storage_path: storagePath,
      description: form.description || null,
      featured: form.featured,
    });

    setUploading(false);

    if (result.ok && result.data) {
      setMedia((prev) => [result.data!, ...prev]);

      if (storageWarning) {
        // Keep modal open to show the warning — user can dismiss manually
        setUploadWarning(storageWarning);
        showToast("Clip saved (without file — see warning above).", false);
      } else {
        showToast("Clip added to your vault.", true);
        closeModal();
      }
    } else {
      showToast(result.error ?? "Failed to save clip. Please try again.", false);
    }
  }

  async function handleDelete(id: string) {
    if (!window.confirm("Remove this clip from your vault? This cannot be undone.")) return;

    setDeletingId(id);
    const result = await deleteAthleteMediaAction(id);
    setDeletingId(null);

    if (result.ok) {
      setMedia((prev) => prev.filter((m) => m.id !== id));
      showToast("Clip removed.", true);
    } else {
      showToast(result.error ?? "Delete failed.", false);
    }
  }

  async function handleToggleFeatured(item: AthleteMedia) {
    const next = !item.featured;
    // Optimistic update
    setMedia((prev) =>
      prev.map((m) => (m.id === item.id ? { ...m, featured: next } : m))
    );
    const result = await toggleMediaFeaturedAction(item.id, next);
    if (!result.ok) {
      // Revert
      setMedia((prev) =>
        prev.map((m) => (m.id === item.id ? { ...m, featured: !next } : m))
      );
      showToast(result.error ?? "Failed to update.", false);
    } else {
      showToast(
        next ? "Clip featured on your public profile." : "Clip removed from public profile.",
        true
      );
    }
  }

  const totalViews = media.reduce((sum, m) => sum + m.view_count, 0);
  const topViews = media.length > 0 ? Math.max(...media.map((m) => m.view_count)) : 0;

  return (
    <div className="p-6 lg:p-8 space-y-8 max-w-5xl">

      {/* Toast notification */}
      {toast && (
        <div
          className={`fixed top-6 right-6 z-50 flex items-center gap-3 rounded-xl border px-4 py-3 text-[13px] font-medium shadow-2xl transition-all ${
            toast.ok
              ? "border-emerald-500/30 bg-zinc-900 text-emerald-400"
              : "border-amber-500/30 bg-zinc-900 text-amber-400"
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* Demo mode banner */}
      {isDemo && (
        <div className="rounded-xl border border-amber-400/20 bg-amber-400/[0.04] px-5 py-4 flex gap-4">
          <div className="mt-0.5 shrink-0 h-5 w-5 rounded-full border border-amber-400/30 bg-amber-400/10 flex items-center justify-center">
            <span className="text-amber-400 text-[10px] font-black">!</span>
          </div>
          <div>
            <p className="text-[13px] font-semibold text-amber-400">Demo Mode — Media is read-only</p>
            <p className="mt-1 text-[12px] text-zinc-400 leading-relaxed">
              You&apos;re viewing sample highlights. To enable real uploads and storage,
              connect a Supabase project and configure the{" "}
              <code className="rounded bg-zinc-800 px-1 py-0.5 text-[11px] text-zinc-300">
                highlights
              </code>{" "}
              storage bucket.{" "}
              <span className="text-zinc-600">See docs/supabase-setup.md.</span>
            </p>
          </div>
        </div>
      )}

      {/* Header row */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="flex-1">
          <h2 className="font-display text-xl font-bold text-white">Highlight Vault</h2>
          <p className="mt-1 text-sm text-zinc-500">
            {media.length} clip{media.length !== 1 ? "s" : ""} ·{" "}
            {formatViews(totalViews)} total views
          </p>
        </div>
        <button
          onClick={isDemo ? undefined : openUploadModal}
          disabled={isDemo}
          className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-5 py-2.5 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors self-start sm:self-auto disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <UploadIcon />
          Upload Highlight
        </button>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total Views", value: formatViews(totalViews) },
          { label: "Clips", value: media.length.toString() },
          { label: "Top Clip", value: media.length > 0 ? formatViews(topViews) : "—" },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-white/[0.06] bg-zinc-900 px-5 py-4">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
              {s.label}
            </p>
            <p className="mt-1.5 font-display text-2xl font-bold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Media grid */}
      <div>
        <h3 className="font-display text-[11px] font-semibold uppercase tracking-widest text-zinc-600 mb-4">
          All Clips
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {media.map((item) => (
            <MediaCard
              key={item.id}
              item={item}
              isDemo={isDemo}
              deleting={deletingId === item.id}
              onEdit={() => openEditModal(item)}
              onDelete={() => handleDelete(item.id)}
              onToggleFeatured={() => handleToggleFeatured(item)}
            />
          ))}

          {/* Upload placeholder card */}
          {!isDemo && (
            <button
              onClick={openUploadModal}
              className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-white/[0.08] bg-transparent aspect-video sm:aspect-auto min-h-[180px] hover:border-amber-400/30 hover:bg-amber-400/[0.03] transition-all group"
            >
              <div className="text-zinc-700 group-hover:text-amber-400 transition-colors">
                <UploadIcon />
              </div>
              <div className="text-center">
                <p className="text-[13px] font-medium text-zinc-600 group-hover:text-zinc-400 transition-colors">
                  Add highlight
                </p>
                <p className="text-[11px] text-zinc-700">Video or photo</p>
              </div>
            </button>
          )}
        </div>

        {/* Empty state */}
        {media.length === 0 && !isDemo && (
          <div className="mt-6 flex flex-col items-center justify-center gap-4 rounded-2xl border border-dashed border-white/[0.06] py-16 text-center">
            <div className="text-zinc-700">
              <UploadIcon size={36} />
            </div>
            <div>
              <p className="font-display text-[15px] font-bold text-white">
                Your vault is empty
              </p>
              <p className="mt-1.5 text-[13px] text-zinc-500 max-w-xs mx-auto">
                Upload your first highlight clip. Coaches and scouts look at film first.
              </p>
            </div>
            <button
              onClick={openUploadModal}
              className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-5 py-2.5 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors"
            >
              <UploadIcon size={16} />
              Upload Your First Clip
            </button>
          </div>
        )}
      </div>

      {/* Storage setup notice (Supabase connected but bucket may not exist) */}
      {isSupabaseConfigured && !isDemo && (
        <div className="rounded-xl border border-white/[0.06] bg-zinc-900/60 px-5 py-4">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-zinc-600 mb-2">
            Storage Setup
          </p>
          <p className="text-[12px] text-zinc-500 leading-relaxed">
            File uploads require the{" "}
            <code className="rounded bg-zinc-800 px-1 py-0.5 text-[11px] text-zinc-300">
              highlights
            </code>{" "}
            Supabase Storage bucket. Run{" "}
            <code className="rounded bg-zinc-800 px-1 py-0.5 text-[11px] text-zinc-300">
              supabase/migrations/20260420000001_storage_bucket.sql
            </code>{" "}
            in your project&apos;s SQL editor to create it.
            If the bucket already exists, uploads will work automatically.
          </p>
        </div>
      )}

      {/* Tips panel */}
      <div className="rounded-xl border border-white/[0.06] bg-zinc-900/60 px-6 py-5">
        <h3 className="font-display text-[13px] font-bold text-white mb-3">
          Tips for your highlight vault
        </h3>
        <ul className="space-y-2">
          {[
            "Upload a full season reel (3–5 min) as your primary clip.",
            "Add a short skills clip (under 90 seconds) showcasing your best attributes.",
            "Include game film from your most competitive matchups.",
            "Label clips clearly — coaches skim profiles quickly.",
            "Star ★ your best clips to feature them on your public profile.",
          ].map((tip, i) => (
            <li key={i} className="flex gap-2.5 text-[12px] text-zinc-500">
              <span className="text-amber-400/60 shrink-0">◆</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>

      {/* Upload / Edit Modal */}
      {showModal && (
        <UploadModal
          form={form}
          setForm={setForm}
          editingId={editingId}
          uploading={uploading}
          uploadWarning={uploadWarning}
          fileRef={fileRef}
          onClose={closeModal}
          onSubmit={handleSubmit}
        />
      )}
    </div>
  );
}
