"use client";

/**
 * ProfileEditor — interactive form for the athlete profile editor page.
 *
 * Dual-mode:
 *  - mode="supabase"  → initial data comes from the DB (passed as props from
 *                       the server component wrapper); saves write to Supabase.
 *  - mode="demo"      → initial data comes from mock-data; saves are no-ops
 *                       with a toast message explaining demo mode.
 *
 * The server component at /app/app/profile/page.tsx loads the data and
 * renders this component with the correct props.
 */

import { useState } from "react";
import Link from "next/link";
import { currentAthlete, SPORTS, CLASS_YEARS } from "@/lib/mock-data";
import {
  updateAthleteProfileAction,
  upsertSocialLinksAction,
  upsertAthleteStatsAction,
} from "@/lib/actions/profile";
import type { AthleteProfile, SocialLink, AthleteStat } from "@/lib/supabase/types";

// ── Types ─────────────────────────────────────────────────────────────────

type SectionKey =
  | "basics"
  | "story"
  | "stats"
  | "academics"
  | "socials"
  | "optional";

const SECTIONS: { key: SectionKey; label: string; desc: string }[] = [
  { key: "basics", label: "Basic Info", desc: "Name, sport, school" },
  { key: "story", label: "Bio & Story", desc: "Your narrative" },
  { key: "stats", label: "Stats & Measurables", desc: "Physical & performance" },
  { key: "academics", label: "Academics", desc: "GPA, major, honors" },
  { key: "socials", label: "Social & Links", desc: "Hudl, Instagram, Twitter" },
  { key: "optional", label: "Faith / Community / Family", desc: "Optional sections" },
];

export interface ProfileEditorProps {
  mode: "supabase" | "demo";
  initialProfile?: AthleteProfile | null;
  initialLinks?: SocialLink[];
  initialStats?: AthleteStat[];
  /** Slug to use in the "Preview public profile" link */
  profileSlug?: string | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────

/** Convert a numeric DB GPA/score to a display string */
function numToStr(n: number | null | undefined): string {
  if (n == null) return "";
  return String(n);
}

/** Parse a form string to a number, returning null for empty/invalid */
function strToNum(s: string): number | null {
  const v = parseFloat(s);
  return isNaN(v) ? null : v;
}

// ── Sub-components ────────────────────────────────────────────────────────

function SaveToast({
  message,
  onClose,
}: {
  message: string;
  onClose: () => void;
}) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-xl border border-emerald-400/20 bg-zinc-900 px-5 py-3.5 shadow-2xl shadow-black/60">
      <span className="h-2 w-2 rounded-full bg-emerald-400" />
      <p className="text-[13px] font-medium text-zinc-200">{message}</p>
      <button
        onClick={onClose}
        className="ml-2 text-zinc-600 hover:text-zinc-300 text-lg leading-none"
      >
        ×
      </button>
    </div>
  );
}

function ErrorToast({
  message,
  onClose,
}: {
  message: string;
  onClose: () => void;
}) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-xl border border-red-400/20 bg-zinc-900 px-5 py-3.5 shadow-2xl shadow-black/60 max-w-sm">
      <span className="h-2 w-2 rounded-full bg-red-400 shrink-0" />
      <p className="text-[13px] font-medium text-zinc-200 leading-snug">{message}</p>
      <button
        onClick={onClose}
        className="ml-2 text-zinc-600 hover:text-zinc-300 text-lg leading-none shrink-0"
      >
        ×
      </button>
    </div>
  );
}

function SectionLabel({ label, desc }: { label: string; desc: string }) {
  return (
    <div className="mb-6 pb-4 border-b border-white/[0.06]">
      <h2 className="font-display text-base font-bold text-white">{label}</h2>
      <p className="mt-0.5 text-[12px] text-zinc-500">{desc}</p>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-[12px] font-semibold text-zinc-400 uppercase tracking-wide">
        {label}
      </label>
      {hint && <p className="mb-1.5 text-[11px] text-zinc-600">{hint}</p>}
      {children}
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-900 px-4 py-2.5 text-[14px] text-zinc-200 placeholder-zinc-700 focus:border-amber-400/40 focus:outline-none focus:ring-1 focus:ring-amber-400/20 transition-all";

const textareaClass =
  "w-full rounded-lg border border-white/[0.08] bg-zinc-900 px-4 py-3 text-[14px] text-zinc-200 placeholder-zinc-700 focus:border-amber-400/40 focus:outline-none focus:ring-1 focus:ring-amber-400/20 transition-all resize-none";

// ── Main component ────────────────────────────────────────────────────────

export default function ProfileEditor({
  mode,
  initialProfile,
  initialLinks = [],
  initialStats = [],
  profileSlug,
}: ProfileEditorProps) {
  const mock = currentAthlete;

  // ── Seed form state: DB data → form fields, or mock data in demo mode ──
  const [form, setForm] = useState(() => {
    if (mode === "supabase" && initialProfile) {
      const p = initialProfile;
      // Map social links array to named fields
      const link = (platform: string) =>
        initialLinks.find((l) => l.platform === platform)?.url ?? "";

      return {
        firstName: p.first_name,
        lastName: p.last_name,
        sport: p.sport,
        position: p.position ?? "",
        classYear: p.class_year,
        school: p.school,
        city: p.city,
        state: p.state,
        bio: p.bio ?? "",
        story: p.story ?? "",
        gpa: numToStr(p.gpa),
        major: p.major ?? "",
        sat: numToStr(p.sat_score),
        act: numToStr(p.act_score),
        honors: p.honors?.join(", ") ?? "",
        instagram: link("instagram"),
        twitter: link("twitter"),
        hudl: link("hudl"),
        maxpreps: link("maxpreps"),
        youtube: link("youtube"),
        faith: p.faith_statement ?? "",
        community: p.community_involvement ?? "",
        family: p.family_values ?? "",
      };
    }

    // Demo mode (or Supabase configured but no profile row yet — just after onboarding)
    return {
      firstName: initialProfile?.first_name ?? mock.firstName,
      lastName: initialProfile?.last_name ?? mock.lastName,
      sport: initialProfile?.sport ?? mock.sport,
      position: initialProfile?.position ?? mock.position,
      classYear: initialProfile?.class_year ?? mock.classYear,
      school: initialProfile?.school ?? mock.school,
      city: initialProfile?.city ?? mock.city,
      state: initialProfile?.state ?? mock.state,
      bio: initialProfile?.bio ?? mock.bio,
      story: initialProfile?.story ?? mock.story,
      gpa: numToStr(initialProfile?.gpa) || mock.academics.gpa,
      major: initialProfile?.major ?? mock.academics.major,
      sat: numToStr(initialProfile?.sat_score) || (mock.academics.sat ?? ""),
      act: numToStr(initialProfile?.act_score) || (mock.academics.act ?? ""),
      honors: initialProfile?.honors?.join(", ") ?? mock.academics.honors?.join(", ") ?? "",
      instagram: mock.socials.instagram ?? "",
      twitter: mock.socials.twitter ?? "",
      hudl: mock.socials.hudl ?? "",
      maxpreps: mock.socials.maxpreps ?? "",
      youtube: mock.socials.youtube ?? "",
      faith: initialProfile?.faith_statement ?? mock.faith ?? "",
      community: initialProfile?.community_involvement ?? mock.community ?? "",
      family: initialProfile?.family_values ?? mock.family ?? "",
    };
  });

  // Stats rows: from DB or from mock
  const [statsRows, setStatsRows] = useState<{ label: string; value: string }[]>(
    () => {
      if (mode === "supabase" && initialStats.length > 0) {
        return initialStats.map((s) => ({
          label: s.stat_label ?? s.stat_key,
          value: s.stat_value,
        }));
      }
      return mock.stats.map((s) => ({ label: s.label, value: s.value }));
    }
  );

  // Achievements: from DB or from mock
  const [achievements, setAchievements] = useState<string>(() => {
    if (mode === "supabase" && initialProfile?.achievements?.length) {
      return initialProfile.achievements.join("\n");
    }
    return mock.achievements.join("\n");
  });

  const [activeSection, setActiveSection] = useState<SectionKey>("basics");
  const [saving, setSaving] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [errorToast, setErrorToast] = useState<string | null>(null);

  // ── Derived: profile strength ─────────────────────────────────────────

  const sectionComplete: Record<SectionKey, boolean> = {
    basics: !!(form.firstName && form.lastName && form.sport && form.position),
    story: !!(form.bio && form.story),
    stats: statsRows.length > 0,
    academics: !!(form.gpa && form.major),
    socials: !!(form.instagram || form.hudl || form.twitter),
    optional: !!(form.faith || form.community || form.family),
  };

  const completedCount = Object.values(sectionComplete).filter(Boolean).length;
  const strength = Math.round((completedCount / SECTIONS.length) * 100);

  // ── Handlers ──────────────────────────────────────────────────────────

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function handleSave() {
    setSaving(true);
    setSaveToast(null);
    setErrorToast(null);

    if (mode === "demo") {
      // No-op in demo mode
      await new Promise((r) => setTimeout(r, 500));
      setSaving(false);
      setSaveToast(
        "Demo mode — changes are not persisted. Add Supabase credentials to enable real saves."
      );
      return;
    }

    // ── Real Supabase save ─────────────────────────────────────────────
    const achievementLines = achievements
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);

    const [profileResult, linksResult, statsResult] = await Promise.all([
      updateAthleteProfileAction({
        first_name: form.firstName,
        last_name: form.lastName,
        sport: form.sport,
        position: form.position || null,
        class_year: form.classYear,
        school: form.school,
        city: form.city,
        state: form.state,
        bio: form.bio || null,
        story: form.story || null,
        gpa: strToNum(form.gpa),
        major: form.major || null,
        sat_score: strToNum(form.sat),
        act_score: strToNum(form.act),
        honors: form.honors
          ? form.honors.split(",").map((h) => h.trim()).filter(Boolean)
          : [],
        faith_statement: form.faith || null,
        community_involvement: form.community || null,
        family_values: form.family || null,
        achievements: achievementLines,
      }),
      upsertSocialLinksAction([
        { platform: "instagram", url: form.instagram },
        { platform: "twitter", url: form.twitter },
        { platform: "hudl", url: form.hudl },
        { platform: "maxpreps", url: form.maxpreps },
        { platform: "youtube", url: form.youtube },
      ]),
      upsertAthleteStatsAction(statsRows),
    ]);

    setSaving(false);

    const firstFailure = [profileResult, linksResult, statsResult].find(
      (r) => !r.ok
    );
    if (firstFailure) {
      setErrorToast(
        `Some changes could not be saved: ${firstFailure.error}`
      );
    } else {
      setSaveToast("Profile saved successfully");
    }
  }

  // ── Preview URL ───────────────────────────────────────────────────────
  const previewSlug =
    profileSlug ??
    (mode === "demo" ? "marcus-thompson" : null);

  const previewHref = previewSlug ? `/athlete/${previewSlug}` : null;

  // ── Render ────────────────────────────────────────────────────────────

  return (
    <div className="flex h-full">
      {/* Demo mode banner */}
      {mode === "demo" && (
        <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-center gap-2 bg-amber-400/10 border-b border-amber-400/20 px-4 py-2 text-[12px] text-amber-400/80">
          <span className="font-semibold">Demo mode</span>
          <span className="text-amber-400/50">·</span>
          <span>
            Add{" "}
            <code className="rounded bg-amber-400/10 px-1 font-mono text-[11px]">
              NEXT_PUBLIC_SUPABASE_URL
            </code>{" "}
            and{" "}
            <code className="rounded bg-amber-400/10 px-1 font-mono text-[11px]">
              NEXT_PUBLIC_SUPABASE_ANON_KEY
            </code>{" "}
            to enable real saves.
          </span>
        </div>
      )}

      {/* Section nav (desktop) */}
      <aside
        className={`hidden lg:flex w-56 shrink-0 flex-col border-r border-white/[0.06] py-6 px-3 gap-0.5 ${
          mode === "demo" ? "pt-14" : ""
        }`}
      >
        <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-widest text-zinc-600">
          Profile Sections
        </p>
        {SECTIONS.map((s) => (
          <button
            key={s.key}
            onClick={() => setActiveSection(s.key)}
            className={`group flex items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-all ${
              activeSection === s.key
                ? "bg-amber-400/10 text-amber-400"
                : "text-zinc-500 hover:bg-white/[0.04] hover:text-zinc-300"
            }`}
          >
            <span
              className={`mt-1 h-1.5 w-1.5 shrink-0 rounded-full transition-colors ${
                sectionComplete[s.key]
                  ? "bg-emerald-400"
                  : activeSection === s.key
                  ? "bg-amber-400"
                  : "bg-zinc-700"
              }`}
            />
            <div>
              <p className="text-[12px] font-semibold leading-none">{s.label}</p>
              <p
                className={`mt-0.5 text-[11px] ${
                  activeSection === s.key ? "text-amber-400/60" : "text-zinc-600"
                }`}
              >
                {s.desc}
              </p>
            </div>
          </button>
        ))}

        {/* Profile strength */}
        <div className="mt-auto pt-6 px-3">
          <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-600 mb-2">
            Profile Strength
          </p>
          <div className="h-1.5 w-full rounded-full bg-white/[0.06]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-500"
              style={{ width: `${strength}%` }}
            />
          </div>
          <p className="mt-1.5 font-display text-xl font-bold text-amber-400">
            {strength}%
          </p>
        </div>
      </aside>

      {/* Form content */}
      <div className="flex-1 overflow-y-auto">
        {/* Mobile section tabs */}
        <div
          className={`lg:hidden flex overflow-x-auto gap-2 px-5 pb-1 border-b border-white/[0.06] ${
            mode === "demo" ? "pt-14" : "pt-5"
          }`}
        >
          {SECTIONS.map((s) => (
            <button
              key={s.key}
              onClick={() => setActiveSection(s.key)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-[12px] font-medium transition-all ${
                activeSection === s.key
                  ? "bg-amber-400/15 text-amber-400"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="max-w-2xl p-6 lg:p-8">
          {/* ── BASICS ──────────────────────────────────── */}
          {activeSection === "basics" && (
            <div className="space-y-5">
              <SectionLabel
                label="Basic Info"
                desc="Your name, sport, school, and class year."
              />
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="First Name">
                  <input
                    name="firstName"
                    value={form.firstName}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="Marcus"
                  />
                </Field>
                <Field label="Last Name">
                  <input
                    name="lastName"
                    value={form.lastName}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="Thompson"
                  />
                </Field>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Sport">
                  <select
                    name="sport"
                    value={form.sport}
                    onChange={handleChange}
                    className={inputClass}
                  >
                    {SPORTS.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Position">
                  <input
                    name="position"
                    value={form.position}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="Wide Receiver"
                  />
                </Field>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Class Year">
                  <select
                    name="classYear"
                    value={form.classYear}
                    onChange={handleChange}
                    className={inputClass}
                  >
                    {CLASS_YEARS.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="School / Program">
                  <input
                    name="school"
                    value={form.school}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="Westlake Academy"
                  />
                </Field>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="City">
                  <input
                    name="city"
                    value={form.city}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="Atlanta"
                  />
                </Field>
                <Field label="State">
                  <input
                    name="state"
                    value={form.state}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="GA"
                  />
                </Field>
              </div>
            </div>
          )}

          {/* ── STORY ──────────────────────────────────── */}
          {activeSection === "story" && (
            <div className="space-y-5">
              <SectionLabel
                label="Bio & Story"
                desc="Tell coaches and scouts who you are beyond the stats."
              />
              <Field
                label="Short Bio"
                hint="One or two sentences — appears at the top of your public profile."
              >
                <textarea
                  name="bio"
                  value={form.bio}
                  onChange={handleChange}
                  rows={3}
                  maxLength={280}
                  className={textareaClass}
                  placeholder="Elite route runner with reliable hands and a high motor..."
                />
                <p className="mt-1 text-right text-[11px] text-zinc-700">
                  {form.bio.length}/280
                </p>
              </Field>
              <Field
                label="Your Story"
                hint="The full narrative — your background, what drives you, who you are off the field."
              >
                <textarea
                  name="story"
                  value={form.story}
                  onChange={handleChange}
                  rows={10}
                  className={textareaClass}
                  placeholder="Growing up in..."
                />
              </Field>
            </div>
          )}

          {/* ── STATS ──────────────────────────────────── */}
          {activeSection === "stats" && (
            <div className="space-y-5">
              <SectionLabel
                label="Stats & Measurables"
                desc="Physical attributes and performance numbers."
              />
              <div className="space-y-3">
                {statsRows.map((row, i) => (
                  <div key={i} className="flex gap-3 items-center">
                    <input
                      value={row.label}
                      onChange={(e) =>
                        setStatsRows((prev) =>
                          prev.map((r, j) =>
                            j === i ? { ...r, label: e.target.value } : r
                          )
                        )
                      }
                      className={inputClass + " w-1/2"}
                      placeholder="Height"
                    />
                    <input
                      value={row.value}
                      onChange={(e) =>
                        setStatsRows((prev) =>
                          prev.map((r, j) =>
                            j === i ? { ...r, value: e.target.value } : r
                          )
                        )
                      }
                      className={inputClass + " w-1/2"}
                      placeholder={`6'2"`}
                    />
                    <button
                      onClick={() =>
                        setStatsRows((prev) => prev.filter((_, j) => j !== i))
                      }
                      className="shrink-0 text-zinc-700 hover:text-zinc-400 text-xl leading-none transition-colors"
                      aria-label="Remove stat"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
              <button
                onClick={() =>
                  setStatsRows((prev) => [...prev, { label: "", value: "" }])
                }
                className="flex items-center gap-2 rounded-lg border border-dashed border-white/[0.1] px-4 py-2.5 text-[13px] text-zinc-500 hover:border-amber-400/30 hover:text-amber-400 transition-all"
              >
                <span className="text-lg leading-none">+</span> Add stat /
                measurable
              </button>
              <Field
                label="Achievements & Awards"
                hint="One per line — awards, records, honors."
              >
                <textarea
                  value={achievements}
                  onChange={(e) => setAchievements(e.target.value)}
                  rows={6}
                  className={textareaClass}
                  placeholder={"All-State Wide Receiver — 2024\n1,247 receiving yards — school record"}
                />
              </Field>
            </div>
          )}

          {/* ── ACADEMICS ──────────────────────────────── */}
          {activeSection === "academics" && (
            <div className="space-y-5">
              <SectionLabel
                label="Academics"
                desc="GPA, intended major, test scores, and honors."
              />
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="GPA">
                  <input
                    name="gpa"
                    value={form.gpa}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="3.8"
                  />
                </Field>
                <Field label="Class Rank (optional)">
                  <input className={inputClass} placeholder="Top 10%" />
                </Field>
              </div>
              <Field label="Intended Major / Academic Interest">
                <input
                  name="major"
                  value={form.major}
                  onChange={handleChange}
                  className={inputClass}
                  placeholder="Communications / Business"
                />
              </Field>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="SAT Score (optional)">
                  <input
                    name="sat"
                    value={form.sat}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="1290"
                  />
                </Field>
                <Field label="ACT Score (optional)">
                  <input
                    name="act"
                    value={form.act}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder="28"
                  />
                </Field>
              </div>
              <Field
                label="Academic Honors"
                hint="Honor Roll, NHS, Academic All-State, etc. Comma-separated."
              >
                <input
                  name="honors"
                  value={form.honors}
                  onChange={handleChange}
                  className={inputClass}
                  placeholder="Honor Roll, Academic All-State 2024"
                />
              </Field>
            </div>
          )}

          {/* ── SOCIALS ──────────────────────────────── */}
          {activeSection === "socials" && (
            <div className="space-y-5">
              <SectionLabel
                label="Social & Links"
                desc="Recruiting platforms and social handles."
              />
              {[
                {
                  name: "hudl",
                  label: "Hudl Profile URL",
                  placeholder: "hudl.com/profile/marcusthompson",
                },
                {
                  name: "maxpreps",
                  label: "MaxPreps URL",
                  placeholder: "maxpreps.com/athlete/...",
                },
                {
                  name: "instagram",
                  label: "Instagram Handle",
                  placeholder: "@marcus.t_wr",
                },
                {
                  name: "twitter",
                  label: "Twitter / X Handle",
                  placeholder: "@marcusthompson_wr",
                },
                {
                  name: "youtube",
                  label: "YouTube Channel (optional)",
                  placeholder: "youtube.com/@...",
                },
              ].map((field) => (
                <Field key={field.name} label={field.label}>
                  <input
                    name={field.name}
                    value={form[field.name as keyof typeof form]}
                    onChange={handleChange}
                    className={inputClass}
                    placeholder={field.placeholder}
                  />
                </Field>
              ))}
            </div>
          )}

          {/* ── OPTIONAL ─────────────────────────────── */}
          {activeSection === "optional" && (
            <div className="space-y-5">
              <SectionLabel
                label="Faith / Community / Family"
                desc="These optional sections help coaches and programs know the full you."
              />
              <div className="rounded-xl border border-amber-400/10 bg-amber-400/[0.04] px-5 py-4 text-[12px] text-amber-400/70">
                These sections are shown on your public profile only if you fill
                them in. They help programs understand your values and character.
              </div>
              <Field
                label="Faith"
                hint="Your faith background or how it shapes your approach to athletics."
              >
                <textarea
                  name="faith"
                  value={form.faith}
                  onChange={handleChange}
                  rows={3}
                  className={textareaClass}
                  placeholder="Faith is the foundation of everything I do..."
                />
              </Field>
              <Field
                label="Community"
                hint="Volunteer work, mentorship, youth programs, community leadership."
              >
                <textarea
                  name="community"
                  value={form.community}
                  onChange={handleChange}
                  rows={3}
                  className={textareaClass}
                  placeholder="Youth football camp volunteer..."
                />
              </Field>
              <Field
                label="Family"
                hint="Who's in your corner? Share as little or as much as you'd like."
              >
                <textarea
                  name="family"
                  value={form.family}
                  onChange={handleChange}
                  rows={3}
                  className={textareaClass}
                  placeholder="My parents have been at every game since I was 6..."
                />
              </Field>
            </div>
          )}

          {/* ── Save / navigation ─────────────────────── */}
          <div className="mt-8 flex items-center justify-between gap-4 border-t border-white/[0.06] pt-6">
            {previewHref ? (
              <Link
                href={previewHref}
                className="text-[12px] text-zinc-500 hover:text-amber-400 transition-colors"
              >
                Preview public profile →
              </Link>
            ) : (
              <span className="text-[12px] text-zinc-700">
                Public profile visible after first save
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-6 py-2.5 text-[13px] font-semibold text-zinc-950 hover:bg-amber-300 transition-colors disabled:opacity-50 disabled:pointer-events-none"
            >
              {saving ? (
                <>
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-950/20 border-t-zinc-950" />
                  Saving…
                </>
              ) : (
                "Save Profile"
              )}
            </button>
          </div>
        </div>
      </div>

      {saveToast && (
        <SaveToast message={saveToast} onClose={() => setSaveToast(null)} />
      )}
      {errorToast && (
        <ErrorToast message={errorToast} onClose={() => setErrorToast(null)} />
      )}
    </div>
  );
}
