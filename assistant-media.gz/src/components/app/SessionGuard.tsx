"use client";

/**
 * SessionGuard — verifies the user is authenticated before rendering
 * the app shell. Works in both Supabase-configured and mock/demo modes.
 *
 * Supabase mode  : calls supabase.auth.getSession() to read the session
 *                  from the cookie set by the proxy. Falls back to getUser()
 *                  if the session cookie is missing.
 * Mock/demo mode : reads from localStorage via getSession() in lib/session.ts.
 *
 * Route protection is also enforced server-side in proxy.ts when Supabase
 * is configured. This component is the client-side complement that handles
 * the loading state and the mock-mode fallback.
 */

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getSession } from "@/lib/session";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

export default function SessionGuard({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    async function check() {
      if (isSupabaseConfigured) {
        // ── Supabase mode ──────────────────────────────────────────────
        const supabase = createClient();
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (!session) {
          router.replace("/login");
          return;
        }

        const onboardingComplete =
          session.user?.user_metadata?.onboarding_complete === true;

        if (!onboardingComplete) {
          router.replace("/onboarding");
          return;
        }
      } else {
        // ── Mock/demo mode ─────────────────────────────────────────────
        const session = getSession();

        if (!session) {
          router.replace("/login");
          return;
        }

        if (!session.onboardingComplete) {
          router.replace("/onboarding");
          return;
        }
      }

      setChecking(false);
    }

    check();
  }, [router]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950">
        <div className="flex items-center gap-3">
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/10 border-t-amber-400" />
          <span className="text-[13px] text-zinc-600">Loading…</span>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
