/**
 * AuthCard — shared wrapper for login, signup, forgot-password.
 * Pure presentational: no logic, just layout + visual shell.
 */
export default function AuthCard({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="w-full max-w-md">
      {/* Header text */}
      <div className="mb-8 text-center">
        {eyebrow && (
          <p className="mb-3 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-400/80">
            <span className="h-px w-5 bg-amber-500/50" />
            {eyebrow}
            <span className="h-px w-5 bg-amber-500/50" />
          </p>
        )}
        <h1 className="font-display text-3xl font-bold text-white">{title}</h1>
        {subtitle && (
          <p className="mt-2 text-sm text-zinc-500">{subtitle}</p>
        )}
      </div>

      {/* Card */}
      <div className="rounded-2xl border border-white/[0.06] bg-zinc-900/80 p-8 shadow-2xl shadow-black/40 backdrop-blur-sm">
        {children}
      </div>
    </div>
  );
}
