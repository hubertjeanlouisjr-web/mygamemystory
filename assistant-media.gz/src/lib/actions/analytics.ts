"use server";

/**
 * Analytics server actions for My Game My Story.
 *
 * Covers:
 *  - Profile view tracking   → profile_views table
 *  - Generic event tracking  → analytics_events table
 *  - Dashboard data fetch    → aggregated queries for the /app/analytics page
 *  - Public profile counts   → lightweight read for /athlete/[slug]
 *
 * All actions degrade gracefully when Supabase is not configured.
 * Tables: profile_views, analytics_events (see supabase/migrations/20260418000001_initial_schema.sql)
 */

import { headers } from "next/headers";
import { createClient, isSupabaseConfiguredServer } from "@/lib/supabase/server";
import type { ViewerType, AnalyticsEventType } from "@/lib/supabase/types";

// ── Fingerprint ────────────────────────────────────────────────────────────

/**
 * Derives a short, anonymous fingerprint from request IP + User-Agent.
 * Used to detect duplicate views within a time window — not for identification.
 */
async function buildFingerprint(): Promise<string | null> {
  try {
    const hdrs = await headers();
    const ip =
      hdrs.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      hdrs.get("x-real-ip") ??
      null;
    const ua = hdrs.get("user-agent") ?? null;
    if (!ip && !ua) return null;

    const raw = `${ip ?? ""}-${ua ?? ""}`;
    const data = new TextEncoder().encode(raw);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hex = Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    return hex.slice(0, 32);
  } catch {
    return null;
  }
}

// ── Profile view tracking ──────────────────────────────────────────────────

/**
 * Inserts a row into `profile_views` (and mirrors to `analytics_events`) when a
 * visitor lands on a public athlete profile page.
 *
 * Deduplication: if the same fingerprint already produced a view for this
 * athlete within the last hour, the insert is silently skipped.
 *
 * @param athleteUserId  The `user_id` from `athlete_profiles` (not the slug).
 */
export async function trackProfileViewAction(athleteUserId: string): Promise<void> {
  if (!isSupabaseConfiguredServer()) return;

  const supabase = await createClient();
  const fingerprint = await buildFingerprint();

  // Deduplication window: 1 hour per fingerprint per athlete
  if (fingerprint) {
    const oneHourAgo = new Date(Date.now() - 3_600_000).toISOString();
    const { count } = await supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", athleteUserId)
      .eq("viewer_fingerprint", fingerprint)
      .gte("viewed_at", oneHourAgo);

    if ((count ?? 0) > 0) return; // duplicate within window — skip
  }

  // Insert profile_view row (fire and collect errors silently)
  const { error: pvError } = await supabase.from("profile_views").insert({
    athlete_user_id: athleteUserId,
    viewer_type: "public" as ViewerType,
    viewer_fingerprint: fingerprint,
  });

  if (pvError) {
    console.error("[analytics/trackProfileView] profile_views error:", pvError);
    return;
  }

  // Mirror to analytics_events for richer queries later
  const { error: aeError } = await supabase.from("analytics_events").insert({
    athlete_user_id: athleteUserId,
    event_type: "profile_view" as AnalyticsEventType,
    viewer_type: "public" as ViewerType,
    viewer_fingerprint: fingerprint,
  });

  if (aeError) {
    console.error("[analytics/trackProfileView] analytics_events error:", aeError);
  }
}

// ── Generic event tracking ─────────────────────────────────────────────────

/**
 * Inserts a row into `analytics_events` for any event type.
 * Safe to call from both Server Components and Client Components.
 *
 * Examples:
 *   trackAnalyticsEventAction({ athleteUserId: id, eventType: "contact_click" })
 *   trackAnalyticsEventAction({ athleteUserId: id, eventType: "media_view", mediaId: "..." })
 */
export async function trackAnalyticsEventAction(event: {
  athleteUserId: string;
  eventType: AnalyticsEventType;
  viewerType?: ViewerType;
  mediaId?: string | null;
  metadata?: Record<string, unknown> | null;
}): Promise<void> {
  if (!isSupabaseConfiguredServer()) return;

  const supabase = await createClient();
  const fingerprint = await buildFingerprint();

  const { error } = await supabase.from("analytics_events").insert({
    athlete_user_id: event.athleteUserId,
    event_type: event.eventType,
    viewer_type: event.viewerType ?? "public",
    media_id: event.mediaId ?? null,
    metadata: event.metadata ?? null,
    viewer_fingerprint: fingerprint,
  });

  if (error) {
    console.error("[analytics/trackEvent]", event.eventType, error);
  }
}

// ── Public profile analytics (for /athlete/[slug] display) ────────────────

export interface PublicProfileAnalytics {
  profileViews: number;
  weeklyViews: number;
  coachViews: number;
  searchImpressions: number;
}

/**
 * Returns lightweight analytics counts for the public athlete profile page.
 * Uses anon key — relies on RLS policy allowing athletes to read their own
 * profile_views rows. Returns null when Supabase is not configured.
 */
export async function getPublicProfileAnalyticsAction(
  athleteUserId: string
): Promise<PublicProfileAnalytics | null> {
  if (!isSupabaseConfiguredServer()) return null;

  const supabase = await createClient();
  const weekAgo = new Date(Date.now() - 7 * 86_400_000).toISOString();

  const [totalResult, weeklyResult, coachResult] = await Promise.all([
    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", athleteUserId),

    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", athleteUserId)
      .gte("viewed_at", weekAgo),

    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", athleteUserId)
      .in("viewer_type", ["coach", "scout"]),
  ]);

  return {
    profileViews: totalResult.count ?? 0,
    weeklyViews: weeklyResult.count ?? 0,
    coachViews: coachResult.count ?? 0,
    searchImpressions: 0, // requires search_impression events to be tracked
  };
}

// ── Dashboard analytics ────────────────────────────────────────────────────

export interface DashboardAnalytics {
  profileViewsTotal: number;
  profileViewsWeekly: number;
  coachViews: number;
  searchImpressions: number;
  viewsHistory: { week: string; views: number }[];
  schoolsViewing: { name: string; views: number; lastSeen: string }[];
  topSearchTerms: string[];
}

/**
 * Aggregates analytics data for the authenticated athlete's dashboard.
 * Reads the authenticated user from the session — callers do not pass a user id.
 * Returns null when Supabase is not configured or the user is not authenticated.
 */
export async function getDashboardAnalyticsAction(): Promise<DashboardAnalytics | null> {
  if (!isSupabaseConfiguredServer()) return null;

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const userId = user.id;
  const weekAgo = new Date(Date.now() - 7 * 86_400_000).toISOString();
  const sixWeeksAgo = new Date(Date.now() - 42 * 86_400_000).toISOString();
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86_400_000).toISOString();

  const [
    totalResult,
    weeklyResult,
    coachResult,
    historyResult,
    schoolsResult,
    searchResult,
  ] = await Promise.all([
    // All-time profile views
    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", userId),

    // Last 7 days
    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", userId)
      .gte("viewed_at", weekAgo),

    // Coach / scout views (all time)
    supabase
      .from("profile_views")
      .select("id", { count: "exact", head: true })
      .eq("athlete_user_id", userId)
      .in("viewer_type", ["coach", "scout"]),

    // Raw rows for the last 6 weeks (bucketed client-side)
    supabase
      .from("profile_views")
      .select("viewed_at")
      .eq("athlete_user_id", userId)
      .gte("viewed_at", sixWeeksAgo)
      .order("viewed_at", { ascending: true }),

    // Schools viewing in the last 30 days
    supabase
      .from("profile_views")
      .select("viewer_school, viewed_at")
      .eq("athlete_user_id", userId)
      .not("viewer_school", "is", null)
      .gte("viewed_at", thirtyDaysAgo),

    // Search impressions (count + metadata for term extraction)
    supabase
      .from("analytics_events")
      .select("metadata", { count: "exact" })
      .eq("athlete_user_id", userId)
      .eq("event_type", "search_impression"),
  ]);

  // Build 6 weekly buckets from raw rows
  const viewsHistory = buildWeeklyBuckets(historyResult.data ?? []);

  // Aggregate schools
  const schoolMap = new Map<string, { views: number; lastSeen: string }>();
  for (const row of schoolsResult.data ?? []) {
    if (!row.viewer_school) continue;
    const entry = schoolMap.get(row.viewer_school);
    if (!entry) {
      schoolMap.set(row.viewer_school, { views: 1, lastSeen: row.viewed_at });
    } else {
      entry.views += 1;
      if (row.viewed_at > entry.lastSeen) entry.lastSeen = row.viewed_at;
    }
  }
  const schoolsViewing = Array.from(schoolMap.entries())
    .map(([name, v]) => ({
      name,
      views: v.views,
      lastSeen: formatRelativeDate(v.lastSeen),
    }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  // Extract search terms from event metadata
  const termCounts = new Map<string, number>();
  for (const row of searchResult.data ?? []) {
    const term = (row.metadata as Record<string, unknown> | null)?.query;
    if (typeof term === "string" && term) {
      termCounts.set(term, (termCounts.get(term) ?? 0) + 1);
    }
  }
  const topSearchTerms = Array.from(termCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([term]) => term);

  return {
    profileViewsTotal: totalResult.count ?? 0,
    profileViewsWeekly: weeklyResult.count ?? 0,
    coachViews: coachResult.count ?? 0,
    searchImpressions: searchResult.count ?? 0,
    viewsHistory,
    schoolsViewing,
    topSearchTerms,
  };
}

// ── Helpers ────────────────────────────────────────────────────────────────

/** Groups raw profile_view rows into 6 weekly buckets ending now. */
function buildWeeklyBuckets(
  rows: { viewed_at: string }[]
): { week: string; views: number }[] {
  const now = Date.now();
  const buckets: { week: string; views: number }[] = [];

  for (let i = 5; i >= 0; i--) {
    const start = now - (i + 1) * 7 * 86_400_000;
    const end = now - i * 7 * 86_400_000;
    const label = new Date(start).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
    const views = rows.filter((r) => {
      const t = new Date(r.viewed_at).getTime();
      return t >= start && t < end;
    }).length;
    buckets.push({ week: label, views });
  }

  return buckets;
}

/** Turns an ISO timestamp into a human-readable relative string. */
function formatRelativeDate(isoDate: string): string {
  const diffMs = Date.now() - new Date(isoDate).getTime();
  const days = Math.floor(diffMs / 86_400_000);
  if (days === 0) return "today";
  if (days === 1) return "yesterday";
  if (days < 7) return `${days}d ago`;
  if (days < 30) return `${Math.floor(days / 7)}w ago`;
  return `${Math.floor(days / 30)}mo ago`;
}
