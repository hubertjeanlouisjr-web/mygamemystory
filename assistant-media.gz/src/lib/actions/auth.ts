"use server";

/**
 * Auth server actions — wrapping Supabase auth.
 *
 * These run on the server, which means:
 *  - They have access to HttpOnly cookies
 *  - They can safely set/clear Supabase session cookies
 *  - They are the correct place for logout and password reset
 *
 * Sign-up and sign-in are handled client-side (see auth pages) because
 * they need live form state and error feedback. This file handles
 * server-triggered flows: logout, password update, and email confirmation.
 */

import { redirect } from "next/navigation";
import { createClient, isSupabaseConfiguredServer } from "@/lib/supabase/server";
import { getAppUrl } from "@/lib/env";

// ── Sign Out ───────────────────────────────────────────────────────────────

/**
 * Signs the current user out and redirects to /login.
 * Safe to call from a Server Action bound to a form or button.
 */
export async function signOutAction(): Promise<void> {
  if (!isSupabaseConfiguredServer()) {
    // Mock mode: the client will clear localStorage itself
    redirect("/login");
  }

  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

// ── Password Reset (initiate) ─────────────────────────────────────────────

export interface ResetPasswordResult {
  ok: boolean;
  error?: string;
}

/**
 * Sends a password reset email via Supabase Auth.
 * Call from a client component when you need server-side handling,
 * or call supabase.auth.resetPasswordForEmail() directly from client code.
 */
export async function requestPasswordResetAction(
  email: string
): Promise<ResetPasswordResult> {
  if (!isSupabaseConfiguredServer()) {
    // No-op in mock mode — the page simulates the success state
    return { ok: true };
  }

  const supabase = await createClient();
  const redirectTo = getAppUrl() + "/auth/update-password";

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo,
  });

  if (error) {
    return { ok: false, error: error.message };
  }

  return { ok: true };
}

// ── Update Password (after reset email link) ──────────────────────────────

export interface UpdatePasswordResult {
  ok: boolean;
  error?: string;
}

/**
 * Updates the user's password after they've clicked a reset link.
 * The user must be in a "password recovery" session (Supabase sets this).
 */
export async function updatePasswordAction(
  newPassword: string
): Promise<UpdatePasswordResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: newPassword });

  if (error) {
    return { ok: false, error: error.message };
  }

  redirect("/app");
}
