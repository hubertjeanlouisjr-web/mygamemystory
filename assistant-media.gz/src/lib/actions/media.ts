"use server";

/**
 * Athlete media server actions.
 *
 * Covers full CRUD on the `athlete_media` table plus best-effort
 * cleanup of Storage files on delete.
 *
 * Real vs demo paths:
 *  - When Supabase is configured, actions read/write the real DB.
 *  - When not configured, actions return { ok: false } with a
 *    descriptive error so the UI can show demo-mode messaging.
 *
 * File uploads are intentionally handled client-side (browser SDK) so
 * large files don't transit through server functions. These actions
 * only persist metadata after the file has been placed in Storage.
 *
 * Storage bucket: "highlights"
 *   Path structure: {user_id}/{timestamp}-{filename}
 *   Policies:       supabase/migrations/20260418000002_rls_policies.sql
 *   Bucket setup:   supabase/migrations/20260420000001_storage_bucket.sql
 */

import { createClient, isSupabaseConfiguredServer } from "@/lib/supabase/server";
import type { AthleteMedia } from "@/lib/supabase/types";
import type { ActionResult } from "./profile";

// ── Input types ────────────────────────────────────────────────────────────

export interface InsertMediaInput {
  type: "video" | "image";
  title: string;
  /** Path inside the "highlights" bucket, e.g. "{user_id}/file.mp4". */
  storage_path: string;
  description?: string | null;
  thumbnail_url?: string | null;
  duration_seconds?: number | null;
  featured?: boolean;
}

export interface UpdateMediaInput {
  title?: string;
  description?: string | null;
  featured?: boolean;
  type?: "video" | "image";
  thumbnail_url?: string | null;
  duration_seconds?: number | null;
}

// ── Fetch ──────────────────────────────────────────────────────────────────

/**
 * Returns all media records for the authenticated user, newest first.
 * Returns [] in demo mode (no Supabase) or when not authenticated.
 */
export async function getAthleteMediaAction(): Promise<AthleteMedia[]> {
  if (!isSupabaseConfiguredServer()) return [];

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("athlete_media")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[media/getAthleteMedia] error:", error);
    return [];
  }

  return (data ?? []) as AthleteMedia[];
}

// ── Insert ─────────────────────────────────────────────────────────────────

/**
 * Inserts a new media metadata record. Call this after the file has been
 * uploaded to Supabase Storage from the browser (or with a placeholder
 * storage_path when the bucket isn't configured yet).
 */
export async function insertAthleteMediaAction(
  input: InsertMediaInput
): Promise<ActionResult & { data?: AthleteMedia }> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Not authenticated." };

  const { data, error } = await supabase
    .from("athlete_media")
    .insert({
      user_id: user.id,
      type: input.type,
      title: input.title.trim(),
      storage_path: input.storage_path,
      description: input.description?.trim() || null,
      thumbnail_url: input.thumbnail_url ?? null,
      duration_seconds: input.duration_seconds ?? null,
      featured: input.featured ?? false,
    })
    .select()
    .single();

  if (error) {
    console.error("[media/insertAthleteMedia] error:", error);
    return { ok: false, error: error.message };
  }

  return { ok: true, data: data as AthleteMedia };
}

// ── Update ─────────────────────────────────────────────────────────────────

/**
 * Updates editable fields on an existing media record.
 * Scoped to the authenticated user — cannot modify another user's row.
 */
export async function updateAthleteMediaAction(
  id: string,
  fields: UpdateMediaInput
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Not authenticated." };

  const update: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };

  if (fields.title !== undefined) update.title = fields.title.trim();
  if ("description" in fields)
    update.description = fields.description?.trim() || null;
  if (fields.featured !== undefined) update.featured = fields.featured;
  if (fields.type !== undefined) update.type = fields.type;
  if ("thumbnail_url" in fields) update.thumbnail_url = fields.thumbnail_url;
  if ("duration_seconds" in fields)
    update.duration_seconds = fields.duration_seconds;

  const { error } = await supabase
    .from("athlete_media")
    .update(update)
    .eq("id", id)
    .eq("user_id", user.id);

  if (error) {
    console.error("[media/updateAthleteMedia] error:", error);
    return { ok: false, error: error.message };
  }

  return { ok: true };
}

// ── Delete ─────────────────────────────────────────────────────────────────

/**
 * Deletes a media record and best-effort removes the associated Storage file.
 * Storage cleanup failures are non-fatal (bucket may not be configured).
 */
export async function deleteAthleteMediaAction(
  id: string
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Not authenticated." };

  // Fetch storage_path before deleting so we can clean up the file
  const { data: row } = await supabase
    .from("athlete_media")
    .select("storage_path")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  // Delete the database row (owner-scoped for safety)
  const { error } = await supabase
    .from("athlete_media")
    .delete()
    .eq("id", id)
    .eq("user_id", user.id);

  if (error) {
    console.error("[media/deleteAthleteMedia] error:", error);
    return { ok: false, error: error.message };
  }

  // Best-effort Storage cleanup — skip placeholder paths
  if (row?.storage_path && !row.storage_path.startsWith("pending/")) {
    try {
      await supabase.storage.from("highlights").remove([row.storage_path]);
    } catch {
      // Non-fatal — bucket may not exist or file already gone
    }
  }

  return { ok: true };
}

// ── Toggle featured ────────────────────────────────────────────────────────

/**
 * Toggles the featured flag on a media record.
 * featured = true  → shown on the public /athlete/[slug] profile page.
 * featured = false → private to the athlete's vault.
 */
export async function toggleMediaFeaturedAction(
  id: string,
  featured: boolean
): Promise<ActionResult> {
  return updateAthleteMediaAction(id, { featured });
}
