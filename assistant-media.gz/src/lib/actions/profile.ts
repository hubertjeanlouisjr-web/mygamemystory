"use server";

/**
 * Athlete profile server actions.
 *
 * Real vs demo paths are cleanly separated:
 *  - When Supabase is configured, actions read/write the real DB tables.
 *  - When not configured, actions return { ok: false } with a descriptive
 *    error so the UI can show a "demo mode" message instead of crashing.
 *
 * Tables used:
 *   athlete_profiles   — core profile (one row per user)
 *   social_links       — per-platform URLs (one row per platform per user)
 *   athlete_stats      — flexible key-value stats rows
 *
 * Schema reference: supabase/migrations/20260418000001_initial_schema.sql
 *                   supabase/migrations/20260419000001_add_profile_fields.sql
 */

import { createClient, isSupabaseConfiguredServer } from "@/lib/supabase/server";
import type {
  OnboardingData,
  SocialLink,
  SocialPlatform,
  AthleteStat,
  AthleteProfile,
  AthleteMedia,
} from "@/lib/supabase/types";

// ── Result type ────────────────────────────────────────────────────────────

export interface ActionResult {
  ok: boolean;
  error?: string;
}

// ── Public athlete data shape (used by /athlete/[slug] page) ───────────────

export interface PublicAthleteData {
  profile: AthleteProfile;
  links: SocialLink[];
  stats: AthleteStat[];
  media: AthleteMedia[];
}

// ── Save onboarding data ───────────────────────────────────────────────────

/**
 * Persists onboarding answers to `athlete_profiles` and marks onboarding
 * complete in Supabase user metadata.
 *
 * Called at the end of the multi-step onboarding wizard.
 * Gracefully returns an error (rather than throwing) when Supabase is not configured.
 */
export async function saveOnboardingAction(
  data: OnboardingData
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return {
      ok: false,
      error:
        "Supabase is not configured. Profile data was not saved to the database. " +
        "See docs/supabase-setup.md to wire up your project.",
    };
  }

  const supabase = await createClient();

  // Verify session
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return { ok: false, error: "Not authenticated. Please log in again." };
  }

  // Build a URL-safe slug from name (best-effort, deduplication handled by DB unique index)
  const slug = `${data.first_name}-${data.last_name}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

  // Upsert the athlete profile row
  const { error: upsertError } = await supabase
    .from("athlete_profiles")
    .upsert(
      {
        user_id: user.id,
        slug,
        first_name: data.first_name,
        last_name: data.last_name,
        sport: data.sport,
        position: data.position || null,
        class_year: data.class_year,
        school: data.school,
        city: data.city,
        state: data.state,
        goals: data.goals,
        onboarding_complete: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" }
    );

  if (upsertError) {
    console.error("[profile/saveOnboarding] upsert error:", upsertError);
    return { ok: false, error: upsertError.message };
  }

  // Mirror onboarding_complete into user metadata so SessionGuard can
  // check it without a DB query
  await supabase.auth.updateUser({
    data: {
      onboarding_complete: true,
      first_name: data.first_name,
      last_name: data.last_name,
    },
  });

  return { ok: true };
}

// ── Fetch athlete profile ──────────────────────────────────────────────────

/**
 * Fetches the authenticated user's athlete profile.
 * Returns null if not found or Supabase is not configured.
 */
export async function getAthleteProfileAction(): Promise<AthleteProfile | null> {
  if (!isSupabaseConfiguredServer()) return null;

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data, error } = await supabase
    .from("athlete_profiles")
    .select("*")
    .eq("user_id", user.id)
    .single();

  if (error) {
    console.error("[profile/getAthleteProfile] error:", error);
    return null;
  }

  return data as AthleteProfile;
}

// ── Update partial profile fields ─────────────────────────────────────────

/**
 * Updates specific fields on the athlete's profile.
 * Safe to call from a Server Action bound to profile-edit forms.
 */
export async function updateAthleteProfileAction(
  fields: Record<string, unknown>
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, error: "Not authenticated." };

  const { error } = await supabase
    .from("athlete_profiles")
    .update({ ...fields, updated_at: new Date().toISOString() })
    .eq("user_id", user.id);

  if (error) return { ok: false, error: error.message };

  return { ok: true };
}

// ── Social links ───────────────────────────────────────────────────────────

/**
 * Fetches all social links for the authenticated user.
 * Returns [] when Supabase is not configured or user is not authenticated.
 */
export async function getSocialLinksAction(): Promise<SocialLink[]> {
  if (!isSupabaseConfiguredServer()) return [];

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return [];

  const { data, error } = await supabase
    .from("social_links")
    .select("*")
    .eq("user_id", user.id)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("[profile/getSocialLinks] error:", error);
    return [];
  }

  return (data ?? []) as SocialLink[];
}

/**
 * Upserts social links for the authenticated user.
 *
 * - Links with a non-empty url are upserted (inserted or updated).
 * - Links with an empty url delete the existing row for that platform (if any).
 *
 * @param links Array of { platform, url } pairs covering all edited platforms.
 */
export async function upsertSocialLinksAction(
  links: { platform: SocialPlatform; url: string }[]
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, error: "Not authenticated." };

  const toUpsert = links
    .filter((l) => l.url.trim().length > 0)
    .map((l, i) => ({
      user_id: user.id,
      platform: l.platform,
      url: l.url.trim(),
      sort_order: i,
      updated_at: new Date().toISOString(),
    }));

  const toDelete = links
    .filter((l) => l.url.trim().length === 0)
    .map((l) => l.platform);

  if (toUpsert.length > 0) {
    const { error: upsertError } = await supabase
      .from("social_links")
      .upsert(toUpsert, { onConflict: "user_id,platform" });

    if (upsertError) {
      console.error("[profile/upsertSocialLinks] upsert error:", upsertError);
      return { ok: false, error: upsertError.message };
    }
  }

  if (toDelete.length > 0) {
    const { error: deleteError } = await supabase
      .from("social_links")
      .delete()
      .eq("user_id", user.id)
      .in("platform", toDelete);

    if (deleteError) {
      console.error("[profile/upsertSocialLinks] delete error:", deleteError);
      return { ok: false, error: deleteError.message };
    }
  }

  return { ok: true };
}

// ── Athlete stats ──────────────────────────────────────────────────────────

/**
 * Fetches all stats for the authenticated user, ordered by sort_order.
 * Returns [] when Supabase is not configured or user is not authenticated.
 */
export async function getAthleteStatsAction(): Promise<AthleteStat[]> {
  if (!isSupabaseConfiguredServer()) return [];

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return [];

  const { data, error } = await supabase
    .from("athlete_stats")
    .select("*")
    .eq("user_id", user.id)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("[profile/getAthleteStats] error:", error);
    return [];
  }

  return (data ?? []) as AthleteStat[];
}

/**
 * Replaces all stats for the authenticated user.
 *
 * Deletes existing rows then inserts the new set. Rows with empty label
 * and value are skipped. This replace-all approach keeps the implementation
 * simple — stats don't have a natural unique business key.
 *
 * @param stats Array of { label, value } pairs to save.
 */
export async function upsertAthleteStatsAction(
  stats: { label: string; value: string }[]
): Promise<ActionResult> {
  if (!isSupabaseConfiguredServer()) {
    return { ok: false, error: "Supabase is not configured." };
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, error: "Not authenticated." };

  // Delete all existing stats for this user
  const { error: deleteError } = await supabase
    .from("athlete_stats")
    .delete()
    .eq("user_id", user.id);

  if (deleteError) {
    console.error("[profile/upsertAthleteStats] delete error:", deleteError);
    return { ok: false, error: deleteError.message };
  }

  const toInsert = stats
    .filter((s) => s.label.trim() || s.value.trim())
    .map((s, i) => ({
      user_id: user.id,
      stat_key: s.label.trim().toLowerCase().replace(/\s+/g, "-") || `stat-${i}`,
      stat_label: s.label.trim() || null,
      stat_value: s.value.trim(),
      sort_order: i,
    }));

  if (toInsert.length > 0) {
    const { error: insertError } = await supabase
      .from("athlete_stats")
      .insert(toInsert);

    if (insertError) {
      console.error("[profile/upsertAthleteStats] insert error:", insertError);
      return { ok: false, error: insertError.message };
    }
  }

  return { ok: true };
}

// ── Public profile by slug ─────────────────────────────────────────────────

/**
 * Fetches a public athlete profile by slug for the public /athlete/[slug] page.
 *
 * Returns null when:
 *  - Supabase is not configured (demo mode — page falls back to mock data)
 *  - No profile with that slug exists
 *  - The profile has is_public = false
 *
 * This query is intentionally done without auth — it uses the anon key and
 * relies on the RLS policy that allows public read of is_public = true rows.
 */
export async function getPublicAthleteBySlugAction(
  slug: string
): Promise<PublicAthleteData | null> {
  if (!isSupabaseConfiguredServer()) return null;

  const supabase = await createClient();

  // Fetch profile
  const { data: profile, error: profileError } = await supabase
    .from("athlete_profiles")
    .select("*")
    .eq("slug", slug)
    .eq("is_public", true)
    .single();

  if (profileError || !profile) {
    if (profileError?.code !== "PGRST116") {
      // PGRST116 = "no rows" — expected when slug not in DB
      console.error("[profile/getPublicAthleteBySlug] error:", profileError);
    }
    return null;
  }

  // Fetch related data in parallel
  const [linksResult, statsResult, mediaResult] = await Promise.all([
    supabase
      .from("social_links")
      .select("*")
      .eq("user_id", profile.user_id)
      .order("sort_order", { ascending: true }),
    supabase
      .from("athlete_stats")
      .select("*")
      .eq("user_id", profile.user_id)
      .order("sort_order", { ascending: true }),
    supabase
      .from("athlete_media")
      .select("*")
      .eq("user_id", profile.user_id)
      .eq("featured", true)
      .order("created_at", { ascending: false })
      .limit(6),
  ]);

  return {
    profile: profile as AthleteProfile,
    links: (linksResult.data ?? []) as SocialLink[],
    stats: (statsResult.data ?? []) as AthleteStat[],
    media: (mediaResult.data ?? []) as AthleteMedia[],
  };
}
