/**
 * Environment variable helpers for My Game My Story.
 *
 * Centralises access to critical env vars so misconfiguration fails
 * loudly with an actionable message rather than silently producing
 * wrong behaviour (e.g. auth redirect URLs pointing at localhost in
 * production, or OG tags with broken base URLs).
 *
 * Usage:
 *   import { getAppUrl } from '@/lib/env'
 *   const redirectTo = getAppUrl() + '/auth/callback'
 */

/**
 * Returns the canonical app URL (NEXT_PUBLIC_APP_URL).
 *
 * - In production: throws if the variable is missing or still set to
 *   the localhost default, so the misconfiguration is caught at
 *   request time with a clear message.
 * - In development: falls back to http://localhost:3000 with a console
 *   warning so local work is never blocked.
 *
 * Never hard-code localhost in server actions that build redirect URLs —
 * use this function instead.
 */
export function getAppUrl(): string {
  const raw = process.env.NEXT_PUBLIC_APP_URL;

  if (!raw || raw.trim() === "" || raw === "http://localhost:3000") {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "[MGMS] NEXT_PUBLIC_APP_URL is not set or is still pointing at localhost. " +
          "Set it to your production domain (e.g. https://mygamemystory.com) " +
          "in Hostinger's Environment Variables panel before going live. " +
          "See docs/hostinger-deployment.md for the full setup guide."
      );
    }
    // Development fallback — warn once so it's visible in the terminal.
    if (process.env.NODE_ENV !== "test") {
      console.warn(
        "[MGMS] NEXT_PUBLIC_APP_URL is not set. Falling back to http://localhost:3000. " +
          "Copy .env.example to .env.local and set a real value for production."
      );
    }
    return "http://localhost:3000";
  }

  // Strip trailing slash for consistent URL construction.
  return raw.replace(/\/$/, "");
}

/**
 * Returns the app URL as a URL object, suitable for Next.js `metadataBase`.
 * Falls back to the hardcoded production domain when the env var is not set
 * (safe for static metadata generation at build time).
 */
export function getMetadataBaseUrl(): URL {
  const raw = process.env.NEXT_PUBLIC_APP_URL;
  if (raw && raw.trim() !== "" && raw !== "http://localhost:3000") {
    try {
      return new URL(raw.replace(/\/$/, ""));
    } catch {
      // Malformed URL — fall through to default.
    }
  }
  return new URL("https://mygamemystory.com");
}

/**
 * Logs warnings for any missing or placeholder-valued critical env vars.
 * Call this from instrumentation.ts or at the top of a server layout to
 * surface config problems in the server log on startup.
 *
 * This function is intentionally non-throwing so a missing optional var
 * doesn't crash the server — use getAppUrl() when you need a hard failure.
 */
export function warnMissingEnv(): void {
  const checks: Array<{ key: string; placeholder?: string; required: boolean }> =
    [
      {
        key: "NEXT_PUBLIC_SUPABASE_URL",
        placeholder: "https://your-project-ref.supabase.co",
        required: true,
      },
      {
        key: "NEXT_PUBLIC_SUPABASE_ANON_KEY",
        placeholder: "your-anon-key-here",
        required: true,
      },
      {
        key: "NEXT_PUBLIC_APP_URL",
        placeholder: "http://localhost:3000",
        required: process.env.NODE_ENV === "production",
      },
    ];

  for (const { key, placeholder, required } of checks) {
    const val = process.env[key];
    const missing = !val || val.trim() === "" || val === placeholder;
    if (missing && required) {
      console.error(
        `[MGMS] ✗ Required env var ${key} is missing or set to a placeholder value. ` +
          `See docs/hostinger-deployment.md for setup instructions.`
      );
    } else if (missing) {
      console.warn(
        `[MGMS] ⚠ ${key} is not set — running in demo/mock mode. ` +
          `Set it in .env.local (dev) or Hostinger's Environment Variables panel (prod).`
      );
    }
  }
}
