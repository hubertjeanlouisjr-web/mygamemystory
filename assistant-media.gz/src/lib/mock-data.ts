// Mock athlete data — local-only, no backend required.
// Structured for easy swap-in with real auth/database later.

export interface AthleteStats {
  label: string;
  value: string;
}

export interface Highlight {
  id: string;
  title: string;
  type: "video" | "photo";
  views: number;
  date: string;
  duration?: string;
  description?: string;
}

export interface AthleteProfile {
  id: string;
  slug: string;
  name: string;
  firstName: string;
  lastName: string;
  sport: string;
  position: string;
  classYear: string;
  school: string;
  city: string;
  state: string;
  bio: string;
  story: string;
  verified: boolean;
  profileStrength: number;
  stats: AthleteStats[];
  academics: {
    gpa: string;
    major: string;
    sat?: string;
    act?: string;
    honors?: string[];
  };
  achievements: string[];
  socials: {
    instagram?: string;
    twitter?: string;
    hudl?: string;
    maxpreps?: string;
    youtube?: string;
  };
  highlights: Highlight[];
  faith?: string;
  community?: string;
  family?: string;
  analytics: {
    profileViews: number;
    weeklyViews: number;
    coachViews: number;
    searchImpressions: number;
    viewsHistory: { week: string; views: number }[];
  };
}

export interface AnalyticsData {
  topSearchTerms: string[];
  schoolsViewing: { name: string; views: number; lastSeen: string }[];
}

// ─── Athlete Profiles ──────────────────────────────────────────────────────────

export const mockAthletes: AthleteProfile[] = [
  {
    id: "1",
    slug: "marcus-thompson",
    name: "Marcus Thompson",
    firstName: "Marcus",
    lastName: "Thompson",
    sport: "Football",
    position: "Wide Receiver",
    classYear: "2026",
    school: "Westlake Academy",
    city: "Atlanta",
    state: "GA",
    bio: "Elite wide receiver with elite route-running and reliable hands. Committed to the craft both on and off the field — every rep has a purpose.",
    story:
      "Growing up in Atlanta, football was more than a game — it was a language my whole neighborhood spoke. I first touched a football at age 5, but it wasn't until 8th grade that I realized I could make this a future. My father played at the collegiate level and passed down everything he knew. Every rep, every drill, every early morning — that's the story behind the stats. I'm not just a receiver. I'm a student, a son, a leader. And I'm just getting started.",
    verified: true,
    profileStrength: 91,
    stats: [
      { label: "Height", value: '6\'2"' },
      { label: "Weight", value: "195 lbs" },
      { label: "40-Yd Dash", value: "4.42s" },
      { label: "Vertical", value: '38"' },
      { label: "Receptions", value: "74" },
      { label: "Rec Yards", value: "1,247" },
      { label: "Receiving TDs", value: "14" },
      { label: "Avg per catch", value: "16.8 yds" },
    ],
    academics: {
      gpa: "3.8",
      major: "Communications / Business (undecided)",
      sat: "1290",
      honors: ["Honor Roll (3 consecutive years)", "Academic All-State 2024"],
    },
    achievements: [
      "All-State Wide Receiver — 2024",
      "1,247 receiving yards — 2024 season (school record)",
      "Team Offensive MVP — 2024",
      "State Championship Finalist — 2024",
      "Under Armour All-American Nominee — 2025",
      "7-on-7 National Tournament Semifinalist",
    ],
    socials: {
      instagram: "@marcus.t_wr",
      twitter: "@marcusthompson_wr",
      hudl: "hudl.com/profile/marcusthompson",
    },
    highlights: [
      {
        id: "h1",
        title: "2024 Season Highlight Reel",
        type: "video",
        views: 12400,
        date: "2024-12-01",
        duration: "4:32",
        description: "Full season cut — 14 TDs, 1,247 yards, key plays vs. ranked opponents.",
      },
      {
        id: "h2",
        title: "State Championship Game",
        type: "video",
        views: 8700,
        date: "2024-11-20",
        duration: "2:18",
        description: "9 catches, 143 yards, 2 touchdowns in the semifinal.",
      },
      {
        id: "h3",
        title: "7-on-7 National Tournament",
        type: "video",
        views: 3200,
        date: "2024-07-15",
        duration: "3:05",
        description: "Elite competition — showcasing route running and separation.",
      },
      {
        id: "h4",
        title: "Senior Night",
        type: "photo",
        views: 1800,
        date: "2024-10-11",
        description: "Senior recognition ceremony with family.",
      },
      {
        id: "h5",
        title: "One-on-One Drills",
        type: "video",
        views: 2900,
        date: "2024-08-22",
        duration: "1:48",
        description: "Individual WR drills at Nike Camp, Atlanta.",
      },
    ],
    faith:
      "Faith is the foundation of everything I do. I lead with purpose and represent something bigger than football.",
    community:
      "Youth football camp volunteer, coaching 5th–8th grade receivers every summer. Mentor with Big Brothers of Atlanta.",
    family:
      "My mom and dad have been at every single game since I was 6. This journey is ours together. My little sister DeShae is my biggest fan.",
    analytics: {
      profileViews: 3847,
      weeklyViews: 284,
      coachViews: 43,
      searchImpressions: 12900,
      viewsHistory: [
        { week: "Oct 25", views: 210 },
        { week: "Nov 1", views: 195 },
        { week: "Nov 8", views: 340 },
        { week: "Nov 15", views: 420 },
        { week: "Nov 22", views: 390 },
        { week: "Nov 29", views: 284 },
      ],
    },
  },
  {
    id: "2",
    slug: "jordan-hayes",
    name: "Jordan Hayes",
    firstName: "Jordan",
    lastName: "Hayes",
    sport: "Basketball",
    position: "Point Guard",
    classYear: "2025",
    school: "Riverside Prep",
    city: "Charlotte",
    state: "NC",
    bio: "High-IQ floor general with a tireless motor and the vision to run any system. Leads by example — on the court and in the locker room.",
    story:
      "Basketball found me. I didn't find it. Every kid in my school played football, but I spent every hour in the gym. By 10th grade I knew this was my calling. My game is built on the fundamentals and built to last.",
    verified: false,
    profileStrength: 67,
    stats: [
      { label: "Height", value: '6\'1"' },
      { label: "Weight", value: "175 lbs" },
      { label: "PPG", value: "22.4" },
      { label: "APG", value: "8.1" },
      { label: "RPG", value: "4.7" },
      { label: "FG%", value: "48.2%" },
      { label: "3PT%", value: "38.5%" },
    ],
    academics: {
      gpa: "3.5",
      major: "Sports Management (interest)",
    },
    achievements: [
      "All-Conference Point Guard — 2024",
      "Regional Tournament MVP — 2024",
      "Led team to conference title — 2023–24",
    ],
    socials: {
      instagram: "@jordan_hayes_pg",
    },
    highlights: [
      {
        id: "h1",
        title: "2024 Season Highlights",
        type: "video",
        views: 4200,
        date: "2024-03-15",
        duration: "3:10",
      },
      {
        id: "h2",
        title: "Regional Tournament Run",
        type: "video",
        views: 2100,
        date: "2024-02-28",
        duration: "2:05",
      },
    ],
    analytics: {
      profileViews: 1240,
      weeklyViews: 88,
      coachViews: 12,
      searchImpressions: 3800,
      viewsHistory: [
        { week: "Oct 25", views: 55 },
        { week: "Nov 1", views: 70 },
        { week: "Nov 8", views: 88 },
        { week: "Nov 15", views: 105 },
        { week: "Nov 22", views: 92 },
        { week: "Nov 29", views: 88 },
      ],
    },
  },
];

// The "current user" for the dashboard — Marcus Thompson
export const currentAthlete: AthleteProfile = mockAthletes[0];

// ─── Analytics ─────────────────────────────────────────────────────────────────

export const mockAnalyticsData: AnalyticsData = {
  topSearchTerms: [
    "Marcus Thompson wide receiver",
    "Class of 2026 WR Atlanta",
    "Marcus Thompson Westlake",
    "6'2 wide receiver Georgia 2026",
    "Westlake Academy football recruit",
  ],
  schoolsViewing: [
    { name: "University of Georgia", views: 8, lastSeen: "2 days ago" },
    { name: "Auburn University", views: 5, lastSeen: "5 days ago" },
    { name: "Florida State University", views: 4, lastSeen: "1 week ago" },
    { name: "University of Tennessee", views: 3, lastSeen: "1 week ago" },
    { name: "Georgia Tech", views: 2, lastSeen: "2 weeks ago" },
    { name: "Clemson University", views: 2, lastSeen: "2 weeks ago" },
  ],
};

// ─── Profile Builder Defaults ───────────────────────────────────────────────────

export const SPORTS = [
  "Football",
  "Basketball",
  "Baseball",
  "Soccer",
  "Track & Field",
  "Volleyball",
  "Softball",
  "Swimming",
  "Wrestling",
  "Tennis",
  "Golf",
  "Lacrosse",
  "Cross Country",
  "Other",
];

export const CLASS_YEARS = ["2025", "2026", "2027", "2028", "2029"];

export const FOOTBALL_POSITIONS = [
  "Quarterback",
  "Running Back",
  "Wide Receiver",
  "Tight End",
  "Offensive Lineman",
  "Defensive Lineman",
  "Linebacker",
  "Cornerback",
  "Safety",
  "Kicker / Punter",
];

/** Positions keyed by sport — used in onboarding and profile builder. */
export const SPORT_POSITIONS: Record<string, string[]> = {
  Football: FOOTBALL_POSITIONS,
  Basketball: [
    "Point Guard",
    "Shooting Guard",
    "Small Forward",
    "Power Forward",
    "Center",
  ],
  Baseball: [
    "Pitcher",
    "Catcher",
    "First Baseman",
    "Second Baseman",
    "Third Baseman",
    "Shortstop",
    "Left Field",
    "Center Field",
    "Right Field",
    "Designated Hitter",
  ],
  Softball: [
    "Pitcher",
    "Catcher",
    "First Baseman",
    "Second Baseman",
    "Third Baseman",
    "Shortstop",
    "Left Field",
    "Center Field",
    "Right Field",
  ],
  Soccer: ["Goalkeeper", "Defender", "Midfielder", "Forward"],
  "Track & Field": [
    "Sprints",
    "Distance",
    "Hurdles",
    "Jumps",
    "Throws",
    "Combined Events",
  ],
  Volleyball: [
    "Setter",
    "Outside Hitter",
    "Middle Blocker",
    "Opposite Hitter",
    "Libero",
    "Defensive Specialist",
  ],
  Swimming: [
    "Freestyle",
    "Backstroke",
    "Breaststroke",
    "Butterfly",
    "Individual Medley",
  ],
  Wrestling: ["Freestyle", "Greco-Roman"],
  Tennis: ["Singles", "Doubles"],
  Golf: ["Individual"],
  Lacrosse: ["Attack", "Midfield", "Defense", "Goalkeeper"],
  "Cross Country": ["Distance Runner"],
  Other: ["Other"],
};

export const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA",
  "HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
  "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
  "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY",
];

export const RECRUIT_GOALS = [
  "Play at the next level (D1 / D2 / D3 / NAIA / JUCO)",
  "Earn an athletic scholarship",
  "Get discovered by coaches and scouts",
  "Secure NIL opportunities",
  "Build my personal brand",
  "Connect with recruiting programs",
  "Showcase my academic profile",
  "Find the right program fit",
];
