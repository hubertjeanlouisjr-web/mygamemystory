/**
 * Mock session helper — client-side only, localStorage-backed.
 *
 * Replace this module with a real auth provider (Supabase, Auth.js, etc.)
 * without touching any other file. All session access goes through these
 * functions so the swap surface is minimal.
 *
 * Real implementation checklist:
 *  - Replace getSession()   → server: cookies().get() / client: SDK call
 *  - Replace setSession()   → server action that sets HttpOnly cookie
 *  - Replace clearSession() → server action that clears cookie
 *  - Replace signUp()       → call auth provider's signup endpoint
 *  - Replace signIn()       → call auth provider's signin endpoint
 */

export interface MockUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  /** Null until onboarding is saved */
  sport: string | null;
  position: string | null;
  classYear: string | null;
  school: string | null;
  city: string | null;
  state: string | null;
  goals: string[];
  onboardingComplete: boolean;
  createdAt: string;
}

const SESSION_KEY = "mgms_mock_session";

// ─── Read ───────────────────────────────────────────────────────────────────

export function getSession(): MockUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as MockUser) : null;
  } catch {
    return null;
  }
}

export function isAuthenticated(): boolean {
  return getSession() !== null;
}

// ─── Write ──────────────────────────────────────────────────────────────────

export function setSession(user: MockUser): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

export function updateSession(patch: Partial<MockUser>): void {
  const current = getSession();
  if (!current) return;
  setSession({ ...current, ...patch });
}

export function clearSession(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(SESSION_KEY);
}

// ─── Auth actions (mock) ────────────────────────────────────────────────────

export interface AuthResult {
  ok: boolean;
  error?: string;
  user?: MockUser;
}

/** Mock sign-up — accepts any credentials, stores in localStorage. */
export async function mockSignUp(
  email: string,
  _password: string,
  firstName: string,
  lastName: string
): Promise<AuthResult> {
  await delay(600);

  const user: MockUser = {
    id: `mock_${Date.now()}`,
    email: email.trim().toLowerCase(),
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    sport: null,
    position: null,
    classYear: null,
    school: null,
    city: null,
    state: null,
    goals: [],
    onboardingComplete: false,
    createdAt: new Date().toISOString(),
  };

  setSession(user);
  return { ok: true, user };
}

/** Mock sign-in — accepts any credentials, restores session. */
export async function mockSignIn(
  email: string,
  _password: string
): Promise<AuthResult> {
  await delay(600);

  // If there's an existing session for this email, restore it
  const existing = getSession();
  if (existing && existing.email === email.trim().toLowerCase()) {
    return { ok: true, user: existing };
  }

  // Otherwise create a new demo session (in real auth this would fail if not registered)
  const user: MockUser = {
    id: `mock_${Date.now()}`,
    email: email.trim().toLowerCase(),
    firstName: "Athlete",
    lastName: "",
    sport: null,
    position: null,
    classYear: null,
    school: null,
    city: null,
    state: null,
    goals: [],
    onboardingComplete: false,
    createdAt: new Date().toISOString(),
  };

  setSession(user);
  return { ok: true, user };
}

// ─── Util ────────────────────────────────────────────────────────────────────

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
