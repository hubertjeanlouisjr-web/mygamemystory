/**
 * Supabase browser client.
 *
 * Usage in Client Components:
 *   import { createClient, isSupabaseConfigured } from '@/lib/supabase/client'
 *
 *   if (!isSupabaseConfigured) { ... show setup banner ... }
 *   const supabase = createClient()
 */

import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "./types";

/**
 * True when both required Supabase env vars are present.
 * Use this flag to conditionally show "Supabase setup required" UI
 * rather than crashing when credentials haven't been configured yet.
 */
export const isSupabaseConfigured =
  typeof process.env.NEXT_PUBLIC_SUPABASE_URL === "string" &&
  process.env.NEXT_PUBLIC_SUPABASE_URL.length > 0 &&
  process.env.NEXT_PUBLIC_SUPABASE_URL !== "https://your-project-ref.supabase.co" &&
  typeof process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY === "string" &&
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.length > 0 &&
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY !== "your-anon-key-here";

/**
 * Creates a Supabase client for use in browser (Client Component) contexts.
 * Throws a descriptive error if credentials are not configured so the
 * developer gets an actionable message rather than a cryptic SDK failure.
 */
export function createClient() {
  if (!isSupabaseConfigured) {
    throw new Error(
      "[MGMS] Supabase is not configured. " +
        "Copy .env.example to .env.local and fill in " +
        "NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY. " +
        "See docs/supabase-setup.md for full instructions."
    );
  }

  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
