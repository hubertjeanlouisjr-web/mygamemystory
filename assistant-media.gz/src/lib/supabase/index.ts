/**
 * Barrel export for Supabase helpers.
 * Import specific helpers from here or directly from client/server.
 */

export { createClient, isSupabaseConfigured } from "./client";
export { createClient as createServerSupabaseClient, isSupabaseConfiguredServer } from "./server";
export type { Database, AthleteProfile, AthleteProfileInput, OnboardingData, AthleteMedia, ProfileView } from "./types";
