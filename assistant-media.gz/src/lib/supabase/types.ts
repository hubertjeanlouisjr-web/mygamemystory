/**
 * Supabase database types for My Game My Story.
 *
 * These are hand-authored to match the schema in supabase/migrations/.
 * Once you have a live Supabase project, replace with generated types:
 *   npx supabase gen types typescript --project-id <ref> > src/lib/supabase/types.ts
 */

// ── Enums / constants ──────────────────────────────────────────────────────

export type MediaType = "video" | "image";

export type ViewerType = "coach" | "scout" | "athlete" | "public" | "unknown";

export type SocialPlatform =
  | "instagram"
  | "twitter"
  | "tiktok"
  | "youtube"
  | "hudl"
  | "maxpreps"
  | "ncsa"
  | "rivals"
  | "facebook"
  | "linkedin"
  | "other";

export type AnalyticsEventType =
  | "profile_view"
  | "media_view"
  | "search_impression"
  | "contact_click"
  | "share"
  | "profile_strength";

// ── Athlete profile ────────────────────────────────────────────────────────

/**
 * The `athlete_profiles` table row.
 * One row per auth.users entry; created when onboarding completes.
 */
export interface AthleteProfile {
  /** UUID — matches auth.users.id */
  user_id: string;
  /** URL slug for public profile, e.g. "marcus-thompson" */
  slug: string | null;
  /** Short tagline shown on profile cards, e.g. "5-Star QB | Class of 2026" */
  headline: string | null;
  first_name: string;
  last_name: string;

  // Sport
  sport: string;
  position: string | null;

  // Recruiting
  class_year: string;
  goals: string[];

  // Location / school
  school: string;
  city: string;
  state: string;

  // Physical
  height_inches: number | null;
  weight_lbs: number | null;

  // Academic
  gpa: number | null;
  /** Intended major / academic interest — added in migration 20260419 */
  major: string | null;
  sat_score: number | null;
  act_score: number | null;
  /** Academic honors array, e.g. ["Honor Roll", "NHS"] — added in migration 20260419 */
  honors: string[];

  // Bio / story
  bio: string | null;
  /** Long-form athlete narrative — added in migration 20260419 */
  story: string | null;

  // Optional character sections (athlete writes in their own words)
  faith_statement: string | null;
  family_values: string | null;
  community_involvement: string | null;

  // Athletic achievements / awards array — added in migration 20260419
  achievements: string[];

  // Media
  avatar_url: string | null;

  // Contact
  phone: string | null;

  // Visibility & state
  is_public: boolean;
  onboarding_complete: boolean;
  /** 0–100 completeness score, computed server-side */
  profile_strength: number;

  created_at: string;
  updated_at: string;
}

/** Fields accepted when creating or updating an athlete profile. */
export type AthleteProfileInput = Omit<
  AthleteProfile,
  "user_id" | "slug" | "profile_strength" | "created_at" | "updated_at"
>;

/** Minimum data required to complete the onboarding wizard. */
export interface OnboardingData {
  first_name: string;
  last_name: string;
  sport: string;
  position: string;
  class_year: string;
  school: string;
  city: string;
  state: string;
  goals: string[];
}

// ── Social links ───────────────────────────────────────────────────────────

/** The `social_links` table row. One row per platform per athlete. */
export interface SocialLink {
  id: string;
  user_id: string;
  platform: SocialPlatform;
  url: string;
  display_name: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface SocialLinkInsert {
  user_id: string;
  platform: SocialPlatform;
  url: string;
  display_name?: string | null;
  sort_order?: number;
}

// ── Athlete stats ──────────────────────────────────────────────────────────

/**
 * The `athlete_stats` table row.
 * Flexible key-value performance statistics (e.g. "40-yard-dash": "4.52s").
 */
export interface AthleteStat {
  id: string;
  user_id: string;
  /** Machine-readable key, e.g. "40-yard-dash", "touchdowns" */
  stat_key: string;
  /** Human-readable label override, e.g. "40-Yard Dash" */
  stat_label: string | null;
  /** Display value as a string to preserve formatting, e.g. "4.52s", "6'2"" */
  stat_value: string;
  /** Context for the value, e.g. "2024 Season", "Career", "2025 Combine" */
  stat_period: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface AthleteStatInsert {
  user_id: string;
  stat_key: string;
  stat_value: string;
  stat_label?: string | null;
  stat_period?: string | null;
  sort_order?: number;
}

// ── Media ──────────────────────────────────────────────────────────────────

/** The `athlete_media` table row. Metadata only; files live in Storage. */
export interface AthleteMedia {
  id: string;
  user_id: string;
  type: MediaType;
  title: string;
  description: string | null;
  /** Path inside the "highlights" storage bucket, e.g. "{user_id}/clip.mp4" */
  storage_path: string;
  thumbnail_url: string | null;
  duration_seconds: number | null;
  view_count: number;
  featured: boolean;
  created_at: string;
  updated_at: string;
}

export interface AthleteMediaInsert {
  user_id: string;
  type: MediaType;
  title: string;
  storage_path: string;
  description?: string | null;
  thumbnail_url?: string | null;
  duration_seconds?: number | null;
  featured?: boolean;
}

// ── Analytics ─────────────────────────────────────────────────────────────

/** The `profile_views` table row. Append-only; rows are never updated. */
export interface ProfileView {
  id: string;
  athlete_user_id: string;
  viewer_type: ViewerType;
  viewer_school: string | null;
  viewer_fingerprint: string | null;
  viewed_at: string;
}

export interface ProfileViewInsert {
  athlete_user_id: string;
  viewer_type?: ViewerType;
  viewer_school?: string | null;
  viewer_fingerprint?: string | null;
  viewed_at?: string;
}

/**
 * The `analytics_events` table row.
 * General-purpose event log for richer analytics beyond page views.
 * Append-only; rows are never updated.
 */
export interface AnalyticsEvent {
  id: string;
  athlete_user_id: string | null;
  event_type: AnalyticsEventType;
  viewer_type: ViewerType;
  viewer_school: string | null;
  /** References athlete_media.id for media_view events */
  media_id: string | null;
  /** Flexible bag for event-specific data */
  metadata: Record<string, unknown> | null;
  viewer_fingerprint: string | null;
  occurred_at: string;
}

export interface AnalyticsEventInsert {
  event_type: AnalyticsEventType;
  athlete_user_id?: string | null;
  viewer_type?: ViewerType;
  viewer_school?: string | null;
  media_id?: string | null;
  metadata?: Record<string, unknown> | null;
  viewer_fingerprint?: string | null;
  occurred_at?: string;
}

// ── Database shape (for Supabase client generics) ─────────────────────────

export interface Database {
  public: {
    Tables: {
      athlete_profiles: {
        Row: AthleteProfile;
        Insert: AthleteProfileInsert;
        Update: Partial<Omit<AthleteProfile, "user_id" | "created_at">>;
        Relationships: [];
      };
      social_links: {
        Row: SocialLink;
        Insert: SocialLinkInsert;
        Update: Partial<Omit<SocialLink, "id" | "user_id" | "created_at">>;
        Relationships: [
          {
            foreignKeyName: "social_links_user_id_fkey";
            columns: ["user_id"];
            referencedRelation: "users";
            referencedColumns: ["id"];
          },
        ];
      };
      athlete_stats: {
        Row: AthleteStat;
        Insert: AthleteStatInsert;
        Update: Partial<Omit<AthleteStat, "id" | "user_id" | "created_at">>;
        Relationships: [
          {
            foreignKeyName: "athlete_stats_user_id_fkey";
            columns: ["user_id"];
            referencedRelation: "users";
            referencedColumns: ["id"];
          },
        ];
      };
      athlete_media: {
        Row: AthleteMedia;
        Insert: AthleteMediaInsert;
        Update: Partial<Omit<AthleteMedia, "id" | "user_id" | "created_at">>;
        Relationships: [
          {
            foreignKeyName: "athlete_media_user_id_fkey";
            columns: ["user_id"];
            referencedRelation: "users";
            referencedColumns: ["id"];
          },
        ];
      };
      profile_views: {
        Row: ProfileView;
        Insert: ProfileViewInsert;
        Update: Record<string, never>;
        Relationships: [
          {
            foreignKeyName: "profile_views_athlete_user_id_fkey";
            columns: ["athlete_user_id"];
            referencedRelation: "users";
            referencedColumns: ["id"];
          },
        ];
      };
      analytics_events: {
        Row: AnalyticsEvent;
        Insert: AnalyticsEventInsert;
        Update: Record<string, never>;
        Relationships: [
          {
            foreignKeyName: "analytics_events_athlete_user_id_fkey";
            columns: ["athlete_user_id"];
            referencedRelation: "users";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "analytics_events_media_id_fkey";
            columns: ["media_id"];
            referencedRelation: "athlete_media";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
}

// ── Insert type alias (kept for backwards compat) ─────────────────────────

export interface AthleteProfileInsert {
  user_id: string;
  first_name: string;
  last_name: string;
  sport: string;
  class_year: string;
  school: string;
  city: string;
  state: string;
  // optional (have DB defaults or are nullable)
  slug?: string | null;
  headline?: string | null;
  position?: string | null;
  goals?: string[];
  height_inches?: number | null;
  weight_lbs?: number | null;
  gpa?: number | null;
  major?: string | null;
  sat_score?: number | null;
  act_score?: number | null;
  honors?: string[];
  bio?: string | null;
  story?: string | null;
  faith_statement?: string | null;
  family_values?: string | null;
  community_involvement?: string | null;
  achievements?: string[];
  avatar_url?: string | null;
  phone?: string | null;
  is_public?: boolean;
  profile_strength?: number;
  onboarding_complete?: boolean;
  updated_at?: string;
}
