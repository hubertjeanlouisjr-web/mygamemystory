/**
 * Next.js Proxy (formerly Middleware).
 *
 * Runs on the Edge before every matched request. Responsible for:
 *  1. Refreshing the Supabase session token (keeps JWTs from expiring mid-session)
 *  2. Redirecting unauthenticated users away from protected routes
 *  3. Redirecting authenticated users who haven't finished onboarding
 *
 * When Supabase is not configured (no env vars), all checks are skipped
 * and the request passes through — preserving the mock-mode dev experience.
 *
 * Protected route prefix : /app
 * Onboarding gate        : /onboarding (requires auth)
 * Public routes          : everything else
 */

import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

export async function proxy(request: NextRequest) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  // ── Skip when Supabase is not configured ─────────────────────────────────
  if (
    !supabaseUrl ||
    !supabaseAnonKey ||
    supabaseUrl === "https://your-project-ref.supabase.co" ||
    supabaseAnonKey === "your-anon-key-here"
  ) {
    return NextResponse.next();
  }

  // ── Build a mutable response object that carries refreshed cookies ───────
  let response = NextResponse.next({ request });

  const supabase = createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        // Write updated cookies onto the outgoing response
        cookiesToSet.forEach(({ name, value }) =>
          request.cookies.set(name, value)
        );
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) =>
          response.cookies.set(name, value, options)
        );
      },
    },
  });

  // ── Refresh session (IMPORTANT: use getUser, not getSession) ─────────────
  // getUser() validates the JWT with the Supabase Auth server; getSession()
  // only reads from cookies and can serve stale data.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;

  // ── Route protection: /app/* requires authentication ─────────────────────
  if (pathname.startsWith("/app")) {
    if (!user) {
      return NextResponse.redirect(new URL("/login", request.url));
    }
    // Require completed onboarding before accessing the app shell
    if (!user.user_metadata?.onboarding_complete) {
      return NextResponse.redirect(new URL("/onboarding", request.url));
    }
  }

  // ── Onboarding requires authentication ───────────────────────────────────
  if (pathname === "/onboarding" && !user) {
    return NextResponse.redirect(new URL("/signup", request.url));
  }

  // ── Redirect authenticated + onboarded users away from auth pages ─────────
  if (
    user &&
    user.user_metadata?.onboarding_complete &&
    (pathname === "/login" || pathname === "/signup")
  ) {
    return NextResponse.redirect(new URL("/app", request.url));
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths EXCEPT:
     * - _next/static  (Next.js static assets)
     * - _next/image   (Next.js image optimisation)
     * - favicon.ico   (favicon)
     * - public/       (public folder files)
     * - api/          (API routes handle their own auth)
     */
    "/((?!_next/static|_next/image|favicon\\.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
