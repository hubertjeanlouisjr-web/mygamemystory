-- =============================================================================
-- My Game My Story — Initial Schema
-- Migration: 20260418000001_initial_schema.sql
--
-- Table overview:
--   athlete_profiles   Core profile linked 1:1 to auth.users
--   social_links       Per-athlete social/recruiting profile URLs (1:many)
--   athlete_stats      Flexible key-value performance stats (1:many)
--   athlete_media      Highlight videos and photos metadata (1:many)
--   profile_views      Append-only view log (analytics)
--   analytics_events   General-purpose event log for richer analytics
--
-- Apply order: run this file before 20260418000002_rls_policies.sql
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

-- gen_random_uuid() is built into Postgres 13+ (available on all Supabase plans).
-- uuid_generate_v4() requires the uuid-ossp extension; we avoid it here.

-- updated_at trigger function (shared across multiple tables)
create or replace function public.handle_updated_at()
  returns trigger
  language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;


-- ---------------------------------------------------------------------------
-- athlete_profiles
--
-- One row per authenticated user. Created during onboarding step 3.
-- Extends auth.users with all athlete-specific data including:
--   - identity / bio / physical
--   - academic fields
--   - optional character sections (faith, family, community)
--   - onboarding state & profile completeness score
--   - public visibility flag
-- ---------------------------------------------------------------------------

create table if not exists public.athlete_profiles (
  -- Identity ---------------------------------------------------------------
  user_id             uuid        primary key
                                  references auth.users(id) on delete cascade,
  slug                text        unique,
  -- e.g. "5-Star QB | Class of 2026" – shown on profile cards
  headline            text,
  first_name          text        not null,
  last_name           text        not null,

  -- Sport ------------------------------------------------------------------
  sport               text        not null,
  position            text,

  -- Recruiting -------------------------------------------------------------
  class_year          text        not null,  -- e.g. "2026"
  goals               text[]      not null default '{}',

  -- Location / School ------------------------------------------------------
  school              text        not null,
  city                text        not null,
  state               text        not null,

  -- Physical stats ---------------------------------------------------------
  height_inches       int,
  weight_lbs          int,

  -- Academic ---------------------------------------------------------------
  gpa                 numeric(3,2),
  sat_score           int,
  act_score           int,

  -- Bio / story ------------------------------------------------------------
  bio                 text,

  -- Optional character sections (free-text; athlete writes in their own words)
  faith_statement     text,
  family_values       text,
  community_involvement text,

  -- Media ------------------------------------------------------------------
  avatar_url          text,

  -- Contact (visible to coaches on public profile when is_public = true) ---
  phone               text,

  -- Visibility & state -----------------------------------------------------
  -- Controls whether /athlete/[slug] is publicly accessible
  is_public           boolean     not null default true,
  onboarding_complete boolean     not null default false,
  -- 0-100, recomputed server-side when profile fields change
  profile_strength    int         not null default 0,

  -- Timestamps -------------------------------------------------------------
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create trigger athlete_profiles_updated_at
  before update on public.athlete_profiles
  for each row execute procedure public.handle_updated_at();

-- Slug lookups are common (public profile pages)
create index if not exists idx_athlete_profiles_slug
  on public.athlete_profiles (slug)
  where slug is not null;

-- Filtering by sport / class_year for athlete directory pages
create index if not exists idx_athlete_profiles_sport_class_year
  on public.athlete_profiles (sport, class_year)
  where is_public = true;


-- ---------------------------------------------------------------------------
-- social_links
--
-- Athlete social/recruiting profile URLs. Each athlete can have one entry
-- per platform. Displayed on public profile and inside the /app dashboard.
-- ---------------------------------------------------------------------------

create table if not exists public.social_links (
  id          uuid        primary key default gen_random_uuid(),
  user_id     uuid        not null
                          references auth.users(id) on delete cascade,

  -- Platform key (one row per platform per user)
  platform    text        not null,

  -- Full URL, e.g. "https://hudl.com/profile/12345"
  url         text        not null,

  -- Optional display label, e.g. "@marcus_t" or "Marcus Thompson"
  display_name text,

  -- Ordering within the UI
  sort_order  int         not null default 0,

  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),

  constraint social_links_platform_check check (
    platform in (
      'instagram', 'twitter', 'tiktok', 'youtube',
      'hudl', 'maxpreps', 'ncsa', 'rivals',
      'facebook', 'linkedin', 'other'
    )
  ),
  -- One URL per platform per user
  constraint social_links_user_platform_unique unique (user_id, platform)
);

create trigger social_links_updated_at
  before update on public.social_links
  for each row execute procedure public.handle_updated_at();

create index if not exists idx_social_links_user_id
  on public.social_links (user_id);


-- ---------------------------------------------------------------------------
-- athlete_stats
--
-- Flexible key-value performance statistics per athlete.
-- Using text for stat_value allows storing "6'2"", "4.4s", "3.87" etc.
-- without losing display fidelity. Separate from academic fields that live
-- on athlete_profiles.
--
-- Examples:
--   stat_key = "40-yard-dash", stat_value = "4.52", stat_period = "2025"
--   stat_key = "touchdowns",   stat_value = "28",   stat_period = "2024 Season"
--   stat_key = "batting-avg",  stat_value = ".342",  stat_period = "Career"
-- ---------------------------------------------------------------------------

create table if not exists public.athlete_stats (
  id          uuid        primary key default gen_random_uuid(),
  user_id     uuid        not null
                          references auth.users(id) on delete cascade,

  stat_key    text        not null,   -- machine-readable key, e.g. "40-yard-dash"
  stat_label  text,                   -- human label override, e.g. "40-Yard Dash"
  stat_value  text        not null,   -- display value, e.g. "4.52s"
  stat_period text,                   -- e.g. "2024 Season", "Career", "2025 Combine"

  -- Controls order within the profile stats section
  sort_order  int         not null default 0,

  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create trigger athlete_stats_updated_at
  before update on public.athlete_stats
  for each row execute procedure public.handle_updated_at();

create index if not exists idx_athlete_stats_user_id
  on public.athlete_stats (user_id);


-- ---------------------------------------------------------------------------
-- athlete_media
--
-- Metadata for videos and images uploaded by athletes.
-- Actual files live in the "highlights" Supabase Storage bucket.
-- storage_path is the bucket-relative path, e.g. "user-uuid/clip-uuid.mp4"
-- ---------------------------------------------------------------------------

create table if not exists public.athlete_media (
  id               uuid        primary key default gen_random_uuid(),
  user_id          uuid        not null
                               references auth.users(id) on delete cascade,

  type             text        not null
                               check (type in ('video', 'image')),

  title            text        not null,
  description      text,

  -- Path inside the "highlights" storage bucket
  storage_path     text        not null,

  -- Publicly accessible thumbnail (can be a signed URL cached at upload time,
  -- or a separate "thumbnails" bucket path)
  thumbnail_url    text,

  -- Video duration in seconds; null for images
  duration_seconds int,

  -- Incremented server-side whenever the clip is viewed
  view_count       int         not null default 0,

  -- Featured clips appear on the public profile; non-featured are vault-only
  featured         boolean     not null default false,

  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create trigger athlete_media_updated_at
  before update on public.athlete_media
  for each row execute procedure public.handle_updated_at();

create index if not exists idx_athlete_media_user_id
  on public.athlete_media (user_id);

create index if not exists idx_athlete_media_featured
  on public.athlete_media (user_id, featured)
  where featured = true;


-- ---------------------------------------------------------------------------
-- profile_views
--
-- Append-only log of public profile visits. Kept simple and separate from
-- analytics_events so queries like "who viewed me today" are fast without
-- joining through a heterogeneous events table.
--
-- No update or delete policies — rows are immutable once written.
-- ---------------------------------------------------------------------------

create table if not exists public.profile_views (
  id                uuid        primary key default gen_random_uuid(),
  athlete_user_id   uuid        not null
                                references auth.users(id) on delete cascade,

  -- Viewer classification (self-reported via the public profile URL params
  -- or inferred from session; defaults to 'unknown' for unauthenticated)
  viewer_type       text        not null default 'unknown'
                                check (viewer_type in ('coach', 'scout', 'athlete', 'public', 'unknown')),

  -- Optional: school/org the viewer represents
  viewer_school     text,

  -- Hashed IP or session fingerprint for dedup — never store raw IPs
  viewer_fingerprint text,

  viewed_at         timestamptz not null default now()
);

-- Time-range queries: "views in the last 30 days"
create index if not exists idx_profile_views_athlete_viewed
  on public.profile_views (athlete_user_id, viewed_at desc);


-- ---------------------------------------------------------------------------
-- analytics_events
--
-- General-purpose event log for richer analytics beyond page views.
-- Supports: media_view, search_impression, contact_click, share, etc.
-- athlete_user_id is the *subject* (whose profile/media was interacted with).
--
-- This table is append-only — no update policies.
-- Keep it lean: heavy aggregation should happen in materialized views or
-- an external BI tool, not in ad-hoc queries against this table.
-- ---------------------------------------------------------------------------

create table if not exists public.analytics_events (
  id              uuid        primary key default gen_random_uuid(),

  -- The athlete whose content was interacted with (null for non-profile events)
  athlete_user_id uuid        references auth.users(id) on delete cascade,

  -- Event classification
  -- profile_view       : public profile page loaded
  -- media_view         : individual highlight/media item viewed
  -- search_impression  : athlete appeared in directory/search results
  -- contact_click      : visitor clicked a contact/phone/email link
  -- share              : athlete shared their own profile link
  -- profile_strength   : profile_strength score changed (audit log)
  event_type      text        not null,

  -- Who triggered the event
  viewer_type     text        not null default 'unknown'
                              check (viewer_type in ('coach', 'scout', 'athlete', 'public', 'unknown')),

  viewer_school   text,

  -- For media_view events: which clip was viewed
  media_id        uuid        references public.athlete_media(id) on delete set null,

  -- Flexible bag for event-specific data (e.g. search query, share platform)
  metadata        jsonb,

  -- Hashed IP/fingerprint for dedup — never raw PII
  viewer_fingerprint text,

  occurred_at     timestamptz not null default now()
);

-- Lookup by athlete + event type + time window
create index if not exists idx_analytics_events_athlete_type_time
  on public.analytics_events (athlete_user_id, event_type, occurred_at desc)
  where athlete_user_id is not null;

-- JSONB index for metadata queries (e.g. search impressions by query term)
create index if not exists idx_analytics_events_metadata
  on public.analytics_events using gin (metadata)
  where metadata is not null;
