-- =============================================================================
-- My Game My Story — Row Level Security Policies
-- Migration: 20260418000002_rls_policies.sql
--
-- Run AFTER 20260418000001_initial_schema.sql
--
-- Policy design philosophy:
--   - Athletes own their private data (read + write only as auth.uid() = user_id)
--   - Public profile data (is_public = true) is readable by anyone
--   - Featured media is publicly readable (shown on /athlete/[slug])
--   - Analytics/view tables are insert-only for public, read-only for the owner
--   - No row in any table can be modified or deleted by a non-owner
-- =============================================================================


-- ---------------------------------------------------------------------------
-- athlete_profiles
-- ---------------------------------------------------------------------------

alter table public.athlete_profiles enable row level security;

-- Athletes read their own profile (includes private fields like phone, gpa)
create policy "athlete_profiles: owner read"
  on public.athlete_profiles
  for select
  using (auth.uid() = user_id);

-- Public read for profiles with is_public = true
-- Powers the /athlete/[slug] and /athletes directory pages
create policy "athlete_profiles: public read when public"
  on public.athlete_profiles
  for select
  using (is_public = true);

-- Only the owner may create their own row (user_id must match session uid)
create policy "athlete_profiles: owner insert"
  on public.athlete_profiles
  for insert
  with check (auth.uid() = user_id);

-- Only the owner may update their own row
create policy "athlete_profiles: owner update"
  on public.athlete_profiles
  for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- No delete policy: athletes cannot delete their own profile row directly.
-- Account deletion cascades from auth.users → this row automatically.


-- ---------------------------------------------------------------------------
-- social_links
-- ---------------------------------------------------------------------------

alter table public.social_links enable row level security;

-- Owner: full read/write/delete of their own links
create policy "social_links: owner all"
  on public.social_links
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Public: read social links for athletes whose profile is public
-- Join to athlete_profiles to check is_public flag
create policy "social_links: public read via public profile"
  on public.social_links
  for select
  using (
    exists (
      select 1
      from public.athlete_profiles ap
      where ap.user_id = social_links.user_id
        and ap.is_public = true
    )
  );


-- ---------------------------------------------------------------------------
-- athlete_stats
-- ---------------------------------------------------------------------------

alter table public.athlete_stats enable row level security;

-- Owner: full read/write/delete of their own stats
create policy "athlete_stats: owner all"
  on public.athlete_stats
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Public: read stats for athletes whose profile is public
create policy "athlete_stats: public read via public profile"
  on public.athlete_stats
  for select
  using (
    exists (
      select 1
      from public.athlete_profiles ap
      where ap.user_id = athlete_stats.user_id
        and ap.is_public = true
    )
  );


-- ---------------------------------------------------------------------------
-- athlete_media
-- ---------------------------------------------------------------------------

alter table public.athlete_media enable row level security;

-- Owner: full access to all their media (featured and non-featured)
create policy "athlete_media: owner all"
  on public.athlete_media
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Public: read only featured clips (shown on public profile pages)
-- Non-featured clips are private to the owner (highlight vault)
create policy "athlete_media: public read featured"
  on public.athlete_media
  for select
  using (featured = true);


-- ---------------------------------------------------------------------------
-- profile_views
-- ---------------------------------------------------------------------------

alter table public.profile_views enable row level security;

-- Athletes can read view records for their own profile (powers analytics UI)
create policy "profile_views: owner read"
  on public.profile_views
  for select
  using (auth.uid() = athlete_user_id);

-- Anyone (including unauthenticated) can insert a view record.
-- No auth.uid() check: visitors don't need an account to generate a view.
-- Server-side code is responsible for fingerprint deduplication.
create policy "profile_views: public insert"
  on public.profile_views
  for insert
  with check (true);

-- No update or delete policies: rows are immutable once written.


-- ---------------------------------------------------------------------------
-- analytics_events
-- ---------------------------------------------------------------------------

alter table public.analytics_events enable row level security;

-- Athletes can read events where they are the subject
create policy "analytics_events: owner read"
  on public.analytics_events
  for select
  using (auth.uid() = athlete_user_id);

-- Anyone can insert an analytics event (public interactions tracked server-side)
create policy "analytics_events: public insert"
  on public.analytics_events
  for insert
  with check (true);

-- No update or delete policies: events are immutable audit records.


-- ---------------------------------------------------------------------------
-- Storage bucket policies (run in SQL editor — bucket must exist first)
--
-- Create the "highlights" bucket in Dashboard → Storage before running these.
-- Set the bucket to PRIVATE (not public) so files require signed URLs.
-- ---------------------------------------------------------------------------

-- Owner can upload files under their own user-id folder
-- Expected path structure: {user_id}/{filename}
create policy "highlights: owner upload"
  on storage.objects
  for insert
  with check (
    bucket_id = 'highlights'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

-- Owner can read (generate signed URLs for) their own files
create policy "highlights: owner read"
  on storage.objects
  for select
  using (
    bucket_id = 'highlights'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

-- Owner can delete their own files
create policy "highlights: owner delete"
  on storage.objects
  for delete
  using (
    bucket_id = 'highlights'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

-- Public read for files in the "public/" subfolder within the bucket
-- Use this subfolder for thumbnails and featured clip previews
-- e.g. path: public/{user_id}/{filename}
create policy "highlights: public subfolder read"
  on storage.objects
  for select
  using (
    bucket_id = 'highlights'
    and (storage.foldername(name))[1] = 'public'
  );
