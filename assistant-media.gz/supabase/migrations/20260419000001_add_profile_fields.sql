-- =============================================================================
-- My Game My Story — Add story, major, honors, achievements to athlete_profiles
-- Migration: 20260419000001_add_profile_fields.sql
--
-- Adds fields needed by the profile editor that were not in the initial schema:
--   story           — long-form athlete narrative (separate from short bio)
--   major           — intended college major / academic interest
--   honors          — academic honors as an array (Honor Roll, NHS, etc.)
--   achievements    — athletic achievements/awards as an array
-- =============================================================================

alter table public.athlete_profiles
  add column if not exists story            text,
  add column if not exists major            text,
  add column if not exists honors           text[]  not null default '{}',
  add column if not exists achievements     text[]  not null default '{}';
