-- =============================================================================
-- My Game My Story — Create "highlights" Storage Bucket
-- Migration: 20260420000001_storage_bucket.sql
--
-- Creates the private "highlights" bucket used for athlete media uploads.
-- Run this in your Supabase project's SQL editor (Dashboard → SQL Editor).
--
-- The bucket is PRIVATE: files are not accessible by direct URL.
-- Access is governed by the RLS policies in 20260418000002_rls_policies.sql,
-- which allow owners to read/write their own files and the public to read
-- files in the "public/" subfolder.
--
-- File size limit: 500 MB per file
-- Allowed MIME types: common video and image formats
--
-- Upload path structure:
--   Owner uploads:  {user_id}/{timestamp}-{filename}
--   Public thumbs:  public/{user_id}/{filename}   (readable by anyone)
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'highlights',
  'highlights',
  false,                 -- PRIVATE: no direct public URL access
  524288000,             -- 500 MB per file
  array[
    'video/mp4',
    'video/quicktime',
    'video/mpeg',
    'video/webm',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp'
  ]
)
on conflict (id) do nothing;   -- Safe to re-run: no-op if bucket already exists
